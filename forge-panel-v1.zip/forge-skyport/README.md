# ⚒ Forge Panel

A game server management panel — Skyport fork with Wings + Skyportd support,
billing, Discord OAuth, daily rewards, referrals, redeem codes, tickets, and more.

---

## Quick Install

```bash
unzip forge-panel.zip
cd forge-panel
chmod +x install.sh
bash install.sh
```

The installer will ask you everything — DB type, Discord credentials, Stripe/UPI, renewal period, Cloudflare subdomains, etc.

---

## Features

| Feature | Description |
|---|---|
| **Wings + Skyportd** | Both daemons supported, switch per-server |
| **Discord OAuth** | Signup/login with Discord, auto-creates game panel account |
| **Email Auth** | Standard email + password |
| **Coins** | Single currency — earned via daily/referrals/redeem, bought via Stripe/UPI |
| **Billing** | Stripe (card) + UPI QR code with admin confirmation |
| **Shop** | Buy RAM/Disk/CPU/server slots with coins |
| **Daily Rewards** | 1x → 3x streak multiplier (7/14/30 day milestones) |
| **Referrals** | Unique code per user, both parties earn coins |
| **Redeem Codes** | Admin creates codes with coin reward + max uses |
| **Renewals** | Configurable period (daily/weekly/monthly/custom), auto-suspend/delete |
| **Subdomains** | Cloudflare CNAME records per server |
| **Tickets** | Support ticket system with staff replies + notifications |
| **Announcements** | Admin posts banners, shown on dashboard with dismiss |
| **Maintenance Mode** | Per-server lock with custom message |
| **Leaderboard** | Top users by coins, servers, referrals |
| **Public Profile** | User page with stats, servers, badges, Discord |
| **Auto Starter** | Give new users a free server on signup |
| **Admin Gift** | Give coins/RAM/Disk/CPU to any user |
| **Notifications** | Dashboard banner + Discord DM + Email |
| **Dark/Light theme** | Forge dark blue theme (#04108f / #0718d9) |
| **Mobile responsive** | Works on all screen sizes |

---

## Theme

Primary color: `#0718d9` (Forge blue)  
Secondary: `#04108f`  
Logo: Forge Panel logo

---

## Tech Stack

- **Backend**: PHP 8.4 + Laravel 11 + Octane/Swoole
- **Frontend**: React + Inertia.js + TypeScript + Tailwind CSS
- **Database**: SQLite or MySQL
- **Payments**: Stripe Checkout + UPI QR
- **Notifications**: Email (SMTP) + Discord Bot DM + Dashboard
- **Daemon**: Wings (Pterodactyl/Pelican API) + Skyportd API

---

## Post-Install

Edit `/var/www/forge/.env` to update any settings after install.

After editing `.env`:
```bash
cd /var/www/forge
php artisan config:clear
php artisan cache:clear
systemctl restart forge-panel forge-ssr
```

Services:
```bash
systemctl status forge-panel    # Main app (Octane)
systemctl status forge-queue    # Background jobs
systemctl status forge-ssr      # Inertia SSR
systemctl status forge-scheduler # Cron (renewals, etc)
journalctl -u forge-panel -f    # Live logs
```
