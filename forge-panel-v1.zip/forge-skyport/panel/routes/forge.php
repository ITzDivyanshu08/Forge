<?php

use App\Http\Controllers\Admin\AdminAnnouncementController;
use App\Http\Controllers\Admin\AdminBillingController;
use App\Http\Controllers\Admin\AdminMaintenanceController;
use App\Http\Controllers\Admin\AdminRedeemController;
use App\Http\Controllers\Admin\AdminTicketController;
use App\Http\Controllers\Admin\AdminUserForgeController;
use App\Http\Controllers\Forge\BillingController;
use App\Http\Controllers\Forge\DailyController;
use App\Http\Controllers\Forge\DiscordAuthController;
use App\Http\Controllers\Forge\NotificationController;
use App\Http\Controllers\Forge\RedeemController;
use App\Http\Controllers\Forge\ReferralController;
use App\Http\Controllers\Forge\ShopController;
use App\Http\Controllers\Forge\SubdomainController;
use App\Http\Controllers\Forge\TicketController;
use Illuminate\Support\Facades\Route;


// ── Public API (authenticated) ────────────────────────────────
Route::middleware(['auth'])->prefix('api')->group(function () {
    Route::get('/announcements', function () {
        return \App\Models\Announcement::active()
            ->latest()->get(['id','title','content','type']);
    });
    Route::get('/daily/info', [\App\Http\Controllers\Forge\DailyController::class, 'show'])
        ->name('api.daily.info');
});

// ── Discord OAuth (public) ─────────────────────────────────────
Route::get('/auth/discord', [DiscordAuthController::class, 'redirect'])->name('auth.discord');
Route::get('/auth/discord/callback', [DiscordAuthController::class, 'callback'])->name('auth.discord.callback');

// ── Stripe webhook (public, raw body) ─────────────────────────
Route::post('/webhooks/stripe', [BillingController::class, 'stripeWebhook'])->name('forge.webhook.stripe');

// ── Authenticated user routes ──────────────────────────────────
Route::middleware(['auth', 'verified'])->prefix('')->name('forge.')->group(function () {

    // Daily
    Route::get('/daily', [DailyController::class, 'show'])->name('daily');
    Route::post('/daily/claim', [DailyController::class, 'claim'])->name('daily.claim');

    // Billing
    Route::get('/billing', [BillingController::class, 'show'])->name('billing');
    Route::post('/billing/stripe', [BillingController::class, 'stripeCheckout'])->name('billing.stripe');
    Route::get('/billing/success', [BillingController::class, 'stripeSuccess'])->name('billing.success');
    Route::post('/billing/upi', [BillingController::class, 'upiCreate'])->name('billing.upi');
    Route::post('/billing/upi/submit', [BillingController::class, 'upiSubmitRef'])->name('billing.upi.submit');

    // Shop
    Route::get('/shop', [ShopController::class, 'show'])->name('shop');
    Route::post('/shop/buy', [ShopController::class, 'buy'])->name('shop.buy');

    // Referral
    Route::get('/referral', [ReferralController::class, 'show'])->name('referral');

    // Redeem
    Route::get('/redeem', [RedeemController::class, 'show'])->name('redeem');
    Route::post('/redeem', [RedeemController::class, 'redeem'])->name('redeem.submit');

    // Tickets
    Route::get('/tickets', [TicketController::class, 'index'])->name('tickets');
    Route::post('/tickets', [TicketController::class, 'store'])->name('tickets.store');
    Route::get('/tickets/{uuid}', [TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{uuid}/reply', [TicketController::class, 'reply'])->name('tickets.reply');

    // Subdomains
    Route::get('/subdomains', [SubdomainController::class, 'index'])->name('subdomains');
    Route::post('/subdomains', [SubdomainController::class, 'store'])->name('subdomains.store');
    Route::delete('/subdomains/{id}', [SubdomainController::class, 'destroy'])->name('subdomains.destroy');

    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications');
    Route::patch('/notifications/{id}/read', [NotificationController::class, 'markRead'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'markAllRead'])->name('notifications.read-all');

    // Leaderboard + profile (public-ish)
    Route::get('/leaderboard', [AdminUserForgeController::class, 'leaderboard'])->name('leaderboard');
    Route::get('/profile/{id}', [AdminUserForgeController::class, 'profile'])->name('profile');
});

// ── Admin routes ───────────────────────────────────────────────
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.forge.')->group(function () {

    // Billing / UPI
    Route::get('/billing', [AdminBillingController::class, 'index'])->name('billing');
    Route::post('/billing/{uuid}/confirm-upi', [AdminBillingController::class, 'confirmUpi'])->name('billing.confirm-upi');
    Route::post('/billing/{uuid}/reject-upi', [AdminBillingController::class, 'rejectUpi'])->name('billing.reject-upi');

    // Redeem codes
    Route::get('/redeem-codes', [AdminRedeemController::class, 'index'])->name('redeem-codes');
    Route::post('/redeem-codes', [AdminRedeemController::class, 'store'])->name('redeem-codes.store');
    Route::patch('/redeem-codes/{id}/toggle', [AdminRedeemController::class, 'toggle'])->name('redeem-codes.toggle');
    Route::delete('/redeem-codes/{id}', [AdminRedeemController::class, 'destroy'])->name('redeem-codes.destroy');

    // Announcements
    Route::get('/announcements', [AdminAnnouncementController::class, 'index'])->name('announcements');
    Route::post('/announcements', [AdminAnnouncementController::class, 'store'])->name('announcements.store');
    Route::patch('/announcements/{id}/toggle', [AdminAnnouncementController::class, 'toggle'])->name('announcements.toggle');
    Route::delete('/announcements/{id}', [AdminAnnouncementController::class, 'destroy'])->name('announcements.destroy');

    // Tickets (staff)
    Route::get('/tickets', [AdminTicketController::class, 'index'])->name('tickets');
    Route::get('/tickets/{id}', [AdminTicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{id}/reply', [AdminTicketController::class, 'reply'])->name('tickets.reply');
    Route::patch('/tickets/{id}/status', [AdminTicketController::class, 'updateStatus'])->name('tickets.status');

    // Gift to users
    Route::post('/users/{id}/gift', [AdminUserForgeController::class, 'gift'])->name('users.gift');

    // Maintenance
    Route::post('/servers/{id}/maintenance', [AdminMaintenanceController::class, 'toggle'])->name('servers.maintenance');
});
