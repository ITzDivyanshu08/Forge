<?php

return [

    'logo_url' => env('FORGE_LOGO_URL', 'https://i.postimg.cc/K8ZkkhM9/file-000000001d5c72089d1c7d0792db739d.png'),

    'discord' => [
        'client_id'     => env('DISCORD_CLIENT_ID'),
        'client_secret' => env('DISCORD_CLIENT_SECRET'),
        'bot_token'     => env('DISCORD_BOT_TOKEN'),
        'redirect_uri'  => env('DISCORD_REDIRECT_URI'),
        'signup_bonus'  => (int) env('DISCORD_SIGNUP_BONUS', 100),
        'log_webhook'   => env('DISCORD_LOG_WEBHOOK'),
    ],

    'stripe' => [
        'key'            => env('STRIPE_KEY'),
        'secret'         => env('STRIPE_SECRET'),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
    ],

    'upi' => [
        'vpa'  => env('UPI_VPA', 'abcd@fam'),
        'name' => env('UPI_NAME', 'Forge Panel'),
    ],

    'coins_per_inr' => (int) env('COINS_PER_INR', 10),
    'coins_per_usd' => (int) env('COINS_PER_USD', 100),

    'daily' => [
        'base_coins'     => (int) env('DAILY_BASE_COINS', 25),
        'streak_7_mult'  => (float) env('DAILY_STREAK_7_MULT', 1.5),
        'streak_14_mult' => (float) env('DAILY_STREAK_14_MULT', 2.0),
        'streak_30_mult' => (float) env('DAILY_STREAK_30_MULT', 3.0),
    ],

    'renewal' => [
        'enabled'     => env('RENEWAL_ENABLED', true),
        'period'      => env('RENEWAL_PERIOD', 'monthly'), // daily|weekly|monthly|custom
        'custom_days' => (int) env('RENEWAL_CUSTOM_DAYS', 30),
        'warning_days'=> (int) env('RENEWAL_WARNING_DAYS', 3),
        'grace_days'  => (int) env('RENEWAL_GRACE_DAYS', 7),
    ],

    'referral' => [
        'enabled'        => env('REFERRAL_ENABLED', true),
        'referrer_coins' => (int) env('REFERRAL_REFERRER_COINS', 200),
        'referee_coins'  => (int) env('REFERRAL_REFEREE_COINS', 100),
    ],

    'shop' => [
        'ram_cost'    => (int) env('SHOP_RAM_COIN_COST', 10),
        'disk_cost'   => (int) env('SHOP_DISK_COIN_COST', 5),
        'cpu_cost'    => (int) env('SHOP_CPU_COIN_COST', 20),
        'server_cost' => (int) env('SHOP_SERVER_COIN_COST', 500),
    ],

    'cf' => [
        'enabled'   => env('CF_ENABLED', false),
        'api_token' => env('CF_API_TOKEN'),
        'zone_id'   => env('CF_ZONE_ID'),
        'domain'    => env('CF_DOMAIN'),
    ],

    'wings'   => ['enabled' => env('WINGS_ENABLED', true)],
    'skyport' => [
        'enabled' => env('SKYPORT_ENABLED', false),
        'url'     => env('SKYPORT_URL'),
        'key'     => env('SKYPORT_KEY'),
    ],

    'starter_server' => [
        'enabled' => env('STARTER_SERVER_ENABLED', false),
        'ram'     => (int) env('STARTER_SERVER_RAM', 512),
        'disk'    => (int) env('STARTER_SERVER_DISK', 2048),
        'cpu'     => (int) env('STARTER_SERVER_CPU', 50),
    ],

    'packages' => [
        'default' => [
            'ram'     => (int) env('DEFAULT_RAM', 2048),
            'disk'    => (int) env('DEFAULT_DISK', 5120),
            'cpu'     => (int) env('DEFAULT_CPU', 100),
            'servers' => (int) env('DEFAULT_SERVERS', 1),
        ],
    ],
];
