import type { SVGProps } from 'react';

export default function TicketIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5" {...props}>
            <path d="M21 15C21 15 19.5 14 19.5 12.5C19.5 11 21 10 21 10V5C21 3.89543 20.1046 3 19 3H5C3.89543 3 3 3.89543 3 5V10C3 10 4.5 11 4.5 12.5C4.5 14 3 15 3 15V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 21 20.1046 21 19V15Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M9 3V21" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="2 3"/>
        </svg>
    );
}
