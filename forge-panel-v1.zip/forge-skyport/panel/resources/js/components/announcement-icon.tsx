import type { SVGProps } from 'react';

export default function AnnouncementIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5" {...props}>
            <path d="M22 3L2 9L8 12M22 3L16 21L8 12M22 3L8 12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
}
