import type { SVGProps } from 'react';

export default function RedeemIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5" {...props}>
            <path d="M20 12V22H4V12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M22 7H2V12H22V7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 22V7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 7H7.5C6.11929 7 5 5.88071 5 4.5C5 3.11929 6.11929 2 7.5 2C10 2 12 7 12 7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 7H16.5C17.8807 7 19 5.88071 19 4.5C19 3.11929 17.8807 2 16.5 2C14 2 12 7 12 7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
}
