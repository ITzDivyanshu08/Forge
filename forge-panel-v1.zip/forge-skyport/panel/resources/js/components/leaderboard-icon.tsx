import type { SVGProps } from 'react';

export default function LeaderboardIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5" {...props}>
            <path d="M18 20V10" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 20V4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6 20V14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
}
