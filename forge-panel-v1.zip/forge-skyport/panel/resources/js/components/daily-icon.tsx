import type { SVGProps } from 'react';

export default function DailyIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5" {...props}>
            <path d="M12 2C12 2 8 6 8 10C8 12.2091 9.79086 14 12 14C14.2091 14 16 12.2091 16 10C16 6 12 2 12 2Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 14V22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M8 18H16" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6 22H18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
}
