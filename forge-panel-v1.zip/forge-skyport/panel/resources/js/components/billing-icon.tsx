import type { SVGProps } from 'react';

export default function BillingIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5" {...props}>
            <path d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 6V8M12 16V18M9 9.5C9 8.67157 9.67157 8 10.5 8H13.5C14.3284 8 15 8.67157 15 9.5C15 10.3284 14.3284 11 13.5 11H10.5C9.67157 11 9 11.6716 9 12.5C9 13.3284 9.67157 14 10.5 14H13.5C14.3284 14 15 13.3284 15 12.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
}
