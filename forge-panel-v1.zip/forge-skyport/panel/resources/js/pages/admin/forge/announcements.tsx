import { Head } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface Announcement { id: number; title: string; content: string; type: string; active: boolean; expires_at: string | null; created_at: string; creator: { name: string }; }

const typeStyles: Record<string, string> = {
    info: 'border-blue-500/30 bg-blue-500/5 text-blue-500',
    warning: 'border-yellow-500/30 bg-yellow-500/5 text-yellow-500',
    danger: 'border-red-500/30 bg-red-500/5 text-red-500',
    success: 'border-green-500/30 bg-green-500/5 text-green-500',
};

export default function AdminAnnouncements({ announcements }: { announcements: Announcement[] }) {
    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';
    const [showForm, setShowForm] = useState(false);
    const [form, setForm] = useState({ title: '', content: '', type: 'info', expires_at: '' });
    const [msg, setMsg] = useState('');

    const create = async (e: React.FormEvent) => {
        e.preventDefault();
        const res = await fetch('/admin/forge/announcements', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify(form),
        });
        const data = await res.json();
        if (data.success) { setMsg('✅ Announcement created'); setShowForm(false); window.location.reload(); }
        else setMsg(data.error ?? 'Failed');
    };

    const toggle = async (id: number) => {
        await fetch(`/admin/forge/announcements/${id}/toggle`, { method: 'PATCH', headers: { 'X-CSRF-TOKEN': csrf() } });
        window.location.reload();
    };

    const del = async (id: number) => {
        if (!confirm('Delete this announcement?')) return;
        await fetch(`/admin/forge/announcements/${id}`, { method: 'DELETE', headers: { 'X-CSRF-TOKEN': csrf() } });
        window.location.reload();
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Admin' }, { title: 'Announcements', href: '/admin/forge/announcements' }]}>
            <Head title="Announcements" />
            <div className="flex flex-col gap-6 p-6 max-w-3xl">
                <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Announcements</h1>
                    <button onClick={() => setShowForm(s => !s)}
                        className="flex items-center gap-2 rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90">
                        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4">
                            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        New Announcement
                    </button>
                </div>

                {msg && <div className="rounded-lg border border-green-500/30 bg-green-500/5 p-3 text-sm text-green-500">{msg}</div>}

                {showForm && (
                    <form onSubmit={create} className="rounded-xl border border-border bg-card p-4 space-y-3">
                        <h2 className="font-semibold">New Announcement</h2>
                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className="text-xs font-medium text-muted-foreground block mb-1">Title</label>
                                <input className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                    value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-muted-foreground block mb-1">Type</label>
                                <select className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                    value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                                    {['info', 'warning', 'danger', 'success'].map(t => (
                                        <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="text-xs font-medium text-muted-foreground block mb-1">Content</label>
                            <textarea rows={3} className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm resize-none"
                                value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} required />
                        </div>
                        <div>
                            <label className="text-xs font-medium text-muted-foreground block mb-1">Expires At (optional)</label>
                            <input type="datetime-local" className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                value={form.expires_at} onChange={e => setForm(f => ({ ...f, expires_at: e.target.value }))} />
                        </div>
                        <div className="flex gap-2">
                            <button type="button" onClick={() => setShowForm(false)} className="rounded-lg border border-border px-4 py-2 text-sm hover:opacity-80">Cancel</button>
                            <button type="submit" className="rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90">Post</button>
                        </div>
                    </form>
                )}

                <div className="space-y-3">
                    {announcements.map(a => (
                        <div key={a.id} className={`rounded-xl border p-4 space-y-2 ${typeStyles[a.type] ?? typeStyles.info} ${!a.active ? 'opacity-50' : ''}`}>
                            <div className="flex items-start justify-between gap-3">
                                <div>
                                    <p className="font-semibold">{a.title}</p>
                                    <p className="text-sm mt-0.5 opacity-80">{a.content}</p>
                                    <p className="text-xs mt-1 opacity-60">
                                        By {a.creator.name} · {new Date(a.created_at).toLocaleDateString()}
                                        {a.expires_at && ` · Expires ${new Date(a.expires_at).toLocaleDateString()}`}
                                    </p>
                                </div>
                                <div className="flex gap-1 shrink-0">
                                    <button onClick={() => toggle(a.id)}
                                        className="rounded px-2 py-1 text-xs border border-current opacity-60 hover:opacity-100">
                                        {a.active ? 'Hide' : 'Show'}
                                    </button>
                                    <button onClick={() => del(a.id)}
                                        className="rounded px-2 py-1 text-xs border border-current opacity-60 hover:opacity-100">
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                    {announcements.length === 0 && (
                        <div className="rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
                            No announcements yet
                        </div>
                    )}
                </div>
            </div>
        </AppLayout>
    );
}
