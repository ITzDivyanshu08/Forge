import { Head, useForm } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface Message { id: number; message: string; is_staff: boolean; user: { name: string }; created_at: string; }
interface Ticket { id: number; uuid: string; subject: string; status: string; priority: string; messages: Message[]; user: { id: number; name: string; email: string }; created_at: string; updated_at: string; }

const statusColor = (s: string) => ({
    open: 'bg-blue-500/10 text-blue-500',
    in_progress: 'bg-yellow-500/10 text-yellow-500',
    closed: 'bg-zinc-500/10 text-zinc-400',
}[s] ?? 'bg-zinc-500/10 text-zinc-400');

// Admin ticket list
export default function AdminTickets({ tickets }: { tickets: { data: Ticket[] } }) {
    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';

    return (
        <AppLayout breadcrumbs={[{ title: 'Admin' }, { title: 'Support Tickets', href: '/admin/forge/tickets' }]}>
            <Head title="Support Tickets" />
            <div className="flex flex-col gap-4 p-6 max-w-4xl">
                <h1 className="text-2xl font-bold">Support Tickets</h1>
                <div className="space-y-2">
                    {tickets.data.map(t => (
                        <a key={t.id} href={`/admin/forge/tickets/${t.id}`}
                            className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 hover:border-brand/30 transition">
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-medium truncate">{t.subject}</span>
                                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(t.status)}`}>
                                        {t.status.replace('_', ' ')}
                                    </span>
                                    <span className={`text-xs font-medium ${
                                        t.priority === 'urgent' ? 'text-red-400' :
                                        t.priority === 'high' ? 'text-orange-400' :
                                        t.priority === 'normal' ? 'text-blue-400' : 'text-zinc-400'
                                    }`}>{t.priority}</span>
                                </div>
                                <p className="text-xs text-muted-foreground mt-0.5">
                                    #{t.id} · {t.user.name} ({t.user.email}) · {new Date(t.updated_at).toLocaleString()}
                                </p>
                            </div>
                            <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4 shrink-0 text-muted-foreground">
                                <path d="M9 18L15 12L9 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                        </a>
                    ))}
                    {tickets.data.length === 0 && (
                        <div className="rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">No tickets</div>
                    )}
                </div>
            </div>
        </AppLayout>
    );
}
