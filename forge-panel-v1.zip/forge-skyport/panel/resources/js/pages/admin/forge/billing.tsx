// admin/forge/billing.tsx
import { Head } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Transaction { uuid: string; amount: number; coins_given: number; status: string; gateway: string; upi_ref?: string; description: string; created_at: string; user: { name: string; email: string }; }

export default function AdminBilling({ transactions, pendingUpi, totalRevenue }: { transactions: { data: Transaction[] }; pendingUpi: number; totalRevenue: number; }) {
    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';

    const confirm = async (uuid: string) => {
        const res = await fetch(`/admin/forge/billing/${uuid}/confirm-upi`, { method: 'POST', headers: { 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' } });
        const data = await res.json();
        if (data.success) window.location.reload();
        else alert(data.error);
    };

    const reject = async (uuid: string) => {
        if (!confirm('Reject this UPI payment?')) return;
        await fetch(`/admin/forge/billing/${uuid}/reject-upi`, { method: 'POST', headers: { 'X-CSRF-TOKEN': csrf() } });
        window.location.reload();
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Admin' }, { title: 'Billing', href: '/admin/forge/billing' }]}>
            <Head title="Admin Billing" />
            <div className="flex flex-col gap-6 p-6 max-w-5xl">
                <h1 className="text-2xl font-bold">Billing</h1>

                <div className="grid grid-cols-3 gap-3">
                    {[
                        { label: 'Total Revenue', value: `₹${totalRevenue.toFixed(0)}`, color: 'text-green-500' },
                        { label: 'Pending UPI', value: pendingUpi, color: 'text-yellow-500' },
                        { label: 'Total Transactions', value: transactions.data.length, color: 'text-brand' },
                    ].map(s => (
                        <div key={s.label} className="rounded-xl border border-border bg-card p-4 text-center">
                            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                        </div>
                    ))}
                </div>

                {pendingUpi > 0 && (
                    <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/5 p-3 text-sm text-yellow-600 dark:text-yellow-400">
                        ⚠️ {pendingUpi} UPI payment(s) awaiting verification
                    </div>
                )}

                <div className="rounded-xl border border-border overflow-hidden">
                    <table className="w-full text-sm">
                        <thead className="bg-sidebar border-b border-border">
                            <tr>
                                {['User', 'Amount', 'Coins', 'Gateway', 'UPI Ref', 'Status', 'Date', 'Actions'].map(h => (
                                    <th key={h} className="px-3 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {transactions.data.map(tx => (
                                <tr key={tx.uuid} className="bg-card">
                                    <td className="px-3 py-3">
                                        <p className="font-medium">{tx.user.name}</p>
                                        <p className="text-xs text-muted-foreground">{tx.user.email}</p>
                                    </td>
                                    <td className="px-3 py-3 font-semibold">₹{tx.amount}</td>
                                    <td className="px-3 py-3 text-brand font-semibold">+{tx.coins_given} 🪙</td>
                                    <td className="px-3 py-3 capitalize">{tx.gateway}</td>
                                    <td className="px-3 py-3 font-mono text-xs">{tx.upi_ref ?? '—'}</td>
                                    <td className="px-3 py-3">
                                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                                            tx.status === 'completed' ? 'bg-green-500/10 text-green-500' :
                                            tx.status === 'verifying' ? 'bg-yellow-500/10 text-yellow-500' :
                                            tx.status === 'failed'   ? 'bg-red-500/10 text-red-500' :
                                            'bg-blue-500/10 text-blue-500'
                                        }`}>{tx.status}</span>
                                    </td>
                                    <td className="px-3 py-3 text-xs text-muted-foreground">{new Date(tx.created_at).toLocaleDateString()}</td>
                                    <td className="px-3 py-3">
                                        {tx.status === 'verifying' && (
                                            <div className="flex gap-1">
                                                <button onClick={() => confirm(tx.uuid)} className="rounded px-2 py-1 text-xs bg-green-500/10 text-green-500 hover:opacity-70">Confirm</button>
                                                <button onClick={() => reject(tx.uuid)} className="rounded px-2 py-1 text-xs bg-red-500/10 text-red-500 hover:opacity-70">Reject</button>
                                            </div>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {transactions.data.length === 0 && <p className="text-center text-sm text-muted-foreground py-8">No transactions</p>}
                </div>
            </div>
        </AppLayout>
    );
}
