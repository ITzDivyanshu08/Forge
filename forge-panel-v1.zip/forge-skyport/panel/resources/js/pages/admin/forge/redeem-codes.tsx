// admin/forge/redeem-codes.tsx
import { Head, useForm } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface RedeemCode { id: number; code: string; coins: number; max_uses: number; uses: number; active: boolean; description: string; expires_at: string | null; created_at: string; }

export default function AdminRedeemCodes({ codes }: { codes: { data: RedeemCode[] } }) {
    const [showForm, setShowForm] = useState(false);
    const [msg, setMsg] = useState('');
    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';
    const { data, setData, reset } = useForm({ code: '', coins: 100, max_uses: 100, description: '', expires_at: '' });

    const create = async (e: React.FormEvent) => {
        e.preventDefault();
        const res = await fetch('/admin/forge/redeem-codes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify(data),
        });
        const json = await res.json();
        if (json.success) { setMsg(`✅ Code created: ${json.code}`); setShowForm(false); reset(); window.location.reload(); }
        else setMsg(json.error ?? 'Failed');
    };

    const toggle = async (id: number) => {
        await fetch(`/admin/forge/redeem-codes/${id}/toggle`, { method: 'PATCH', headers: { 'X-CSRF-TOKEN': csrf() } });
        window.location.reload();
    };

    const del = async (id: number) => {
        if (!confirm('Delete this code?')) return;
        await fetch(`/admin/forge/redeem-codes/${id}`, { method: 'DELETE', headers: { 'X-CSRF-TOKEN': csrf() } });
        window.location.reload();
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Admin' }, { title: 'Redeem Codes', href: '/admin/forge/redeem-codes' }]}>
            <Head title="Redeem Codes" />
            <div className="flex flex-col gap-6 p-6 max-w-4xl">
                <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Redeem Codes</h1>
                    <button onClick={() => setShowForm(s => !s)}
                        className="flex items-center gap-2 rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90">
                        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4">
                            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        Create Code
                    </button>
                </div>

                {msg && <div className={`rounded-lg border p-3 text-sm ${msg.startsWith('✅') ? 'border-green-500/30 text-green-500' : 'border-red-500/30 text-red-500'}`}>{msg}</div>}

                {showForm && (
                    <form onSubmit={create} className="rounded-xl border border-border bg-card p-4 space-y-4">
                        <h2 className="font-semibold">New Redeem Code</h2>
                        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                            <div>
                                <label className="text-xs font-medium text-muted-foreground block mb-1">Code (leave blank to auto-generate)</label>
                                <input className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm font-mono uppercase"
                                    placeholder="AUTO" value={data.code} onChange={e => setData('code', e.target.value.toUpperCase())} />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-muted-foreground block mb-1">Coins</label>
                                <input type="number" min={1} className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                    value={data.coins} onChange={e => setData('coins', +e.target.value)} />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-muted-foreground block mb-1">Max Uses</label>
                                <input type="number" min={1} className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                    value={data.max_uses} onChange={e => setData('max_uses', +e.target.value)} />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-muted-foreground block mb-1">Expires At</label>
                                <input type="datetime-local" className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                    value={data.expires_at} onChange={e => setData('expires_at', e.target.value)} />
                            </div>
                        </div>
                        <div>
                            <label className="text-xs font-medium text-muted-foreground block mb-1">Description (optional)</label>
                            <input className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                placeholder="e.g. Giveaway April 2026" value={data.description} onChange={e => setData('description', e.target.value)} />
                        </div>
                        <div className="flex gap-2">
                            <button type="button" onClick={() => setShowForm(false)} className="rounded-lg border border-border px-4 py-2 text-sm hover:opacity-80">Cancel</button>
                            <button type="submit" className="rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90">Create</button>
                        </div>
                    </form>
                )}

                <div className="rounded-xl border border-border overflow-hidden">
                    <table className="w-full text-sm">
                        <thead className="bg-sidebar border-b border-border">
                            <tr>
                                {['Code', 'Coins', 'Uses', 'Expires', 'Status', 'Actions'].map(h => (
                                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {codes.data.map(c => (
                                <tr key={c.id} className="bg-card">
                                    <td className="px-4 py-3 font-mono font-bold">{c.code}</td>
                                    <td className="px-4 py-3 text-brand font-semibold">{c.coins} 🪙</td>
                                    <td className="px-4 py-3">{c.uses}/{c.max_uses}</td>
                                    <td className="px-4 py-3 text-muted-foreground">{c.expires_at ? new Date(c.expires_at).toLocaleDateString() : '—'}</td>
                                    <td className="px-4 py-3">
                                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${c.active ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                                            {c.active ? 'Active' : 'Disabled'}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3">
                                        <div className="flex gap-2">
                                            <button onClick={() => toggle(c.id)} className="text-xs rounded px-2 py-1 border border-border hover:opacity-70">
                                                {c.active ? 'Disable' : 'Enable'}
                                            </button>
                                            <button onClick={() => del(c.id)} className="text-xs rounded px-2 py-1 border border-red-500/30 text-red-500 hover:opacity-70">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {codes.data.length === 0 && <p className="text-center text-sm text-muted-foreground py-8">No redeem codes yet</p>}
                </div>
            </div>
        </AppLayout>
    );
}
