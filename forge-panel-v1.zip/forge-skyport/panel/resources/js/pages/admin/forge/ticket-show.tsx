import { Head, useForm } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Message { id: number; message: string; is_staff: boolean; user: { name: string }; created_at: string; }
interface Ticket { id: number; uuid: string; subject: string; status: string; priority: string; messages: Message[]; user: { id: number; name: string; email: string }; }

export default function AdminTicketShow({ ticket }: { ticket: Ticket }) {
    const { data, setData, post, processing } = useForm({ message: '' });
    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';

    const submit = (e: React.FormEvent) => {
        e.preventDefault();
        post(`/admin/forge/tickets/${ticket.id}/reply`, {
            preserveScroll: true,
            onSuccess: () => setData('message', ''),
        });
    };

    const setStatus = async (status: string) => {
        await fetch(`/admin/forge/tickets/${ticket.id}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify({ status }),
        });
        window.location.reload();
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Admin' }, { title: 'Tickets', href: '/admin/forge/tickets' }, { title: `#${ticket.id}`, href: '#' }]}>
            <Head title={`Ticket #${ticket.id}`} />
            <div className="flex flex-col gap-4 p-6 max-w-3xl">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                        <h1 className="text-xl font-bold">{ticket.subject}</h1>
                        <p className="text-sm text-muted-foreground mt-0.5">
                            #{ticket.id} · {ticket.user.name} ({ticket.user.email}) ·
                            <span className={`ml-1 font-medium ${
                                ticket.status === 'open' ? 'text-blue-500' :
                                ticket.status === 'in_progress' ? 'text-yellow-500' : 'text-zinc-400'
                            }`}>{ticket.status.replace('_', ' ')}</span>
                        </p>
                    </div>
                    <div className="flex gap-2">
                        {['open', 'in_progress', 'closed'].map(s => (
                            <button key={s} onClick={() => setStatus(s)}
                                disabled={ticket.status === s}
                                className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition disabled:opacity-40 ${
                                    ticket.status === s ? 'bg-brand text-white border-brand' : 'border-border hover:opacity-80'
                                }`}>
                                {s.replace('_', ' ')}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="space-y-3">
                    {ticket.messages.map(msg => (
                        <div key={msg.id} className={`flex gap-3 ${msg.is_staff ? 'flex-row-reverse' : ''}`}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${msg.is_staff ? 'bg-brand text-white' : 'bg-sidebar border border-border'}`}>
                                {msg.user.name[0].toUpperCase()}
                            </div>
                            <div className={`flex-1 rounded-xl border p-3 ${msg.is_staff ? 'border-brand/30 bg-brand/5' : 'border-border bg-card'}`}>
                                <div className="flex items-center justify-between gap-2 mb-1">
                                    <span className="text-xs font-semibold">{msg.is_staff ? '🛡 Staff' : msg.user.name}</span>
                                    <span className="text-xs text-muted-foreground">{new Date(msg.created_at).toLocaleString()}</span>
                                </div>
                                <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                            </div>
                        </div>
                    ))}
                </div>

                <form onSubmit={submit} className="space-y-3 rounded-xl border border-border bg-card p-4">
                    <h2 className="font-semibold text-sm">Staff Reply</h2>
                    <textarea
                        value={data.message}
                        onChange={e => setData('message', e.target.value)}
                        rows={4}
                        placeholder="Type your reply..."
                        className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand resize-none"
                        required
                    />
                    <button type="submit" disabled={processing}
                        className="rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90 disabled:opacity-50">
                        {processing ? 'Sending...' : 'Send Reply'}
                    </button>
                </form>
            </div>
        </AppLayout>
    );
}
