import { Form, Head } from '@inertiajs/react';
import { KeyRound } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import {
    create as passkeyOptions,
    store as passkeyLogin,
} from '@/routes/passkeys/authentication';
import { toast } from '@/components/ui/sonner';
import PasswordInput from '@/components/password-input';
import TextLink from '@/components/text-link';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import AuthLayout from '@/layouts/auth-layout';
import {
    authenticateWithPasskey,
    conditionalMediationAvailable,
    passkeyAutocomplete,
    passkeysAreSupported,
} from '@/lib/passkeys';
import { register } from '@/routes';
import { store } from '@/routes/login';
import { request } from '@/routes/password/index';

type Props = {
    status?: string;
    canResetPassword: boolean;
    canRegister: boolean;
    canUsePasskeys: boolean;
};

export default function Login({
    status,
    canResetPassword,
    canRegister,
    canUsePasskeys,
}: Props) {
    const [passkeyProcessing, setPasskeyProcessing] = useState(false);
    const abortController = useRef<AbortController | null>(null);

    useEffect(() => {
        if (status) {
            toast.success(status);
        }
    }, [status]);

    useEffect(() => {
        if (!canUsePasskeys || !passkeysAreSupported()) {
            return;
        }

        let active = true;

        void (async () => {
            if (!(await conditionalMediationAvailable())) {
                return;
            }

            abortController.current = new AbortController();

            try {
                const redirect = await authenticateWithPasskey(
                    passkeyOptions.url(),
                    passkeyLogin.url(),
                    false,
                    true,
                    abortController.current.signal,
                );

                if (active && redirect) {
                    window.location.assign(redirect);
                }
            } catch (error) {
                if (
                    error instanceof DOMException &&
                    (error.name === 'AbortError' ||
                        error.name === 'NotAllowedError')
                ) {
                    return;
                }
            }
        })();

        return () => {
            active = false;
            abortController.current?.abort();
        };
    }, [canUsePasskeys]);

    const handlePasskeyLogin = async (): Promise<void> => {
        if (!canUsePasskeys || !passkeysAreSupported()) {
            toast.error('This browser does not support passkeys.');

            return;
        }

        abortController.current?.abort();
        setPasskeyProcessing(true);

        try {
            const redirect = await authenticateWithPasskey(
                passkeyOptions.url(),
                passkeyLogin.url(),
                false,
                false,
            );

            if (redirect) {
                window.location.assign(redirect);
            }
        } catch (error) {
            const message =
                error instanceof Error
                    ? error.message
                    : 'Unable to sign in with a passkey.';
            toast.error(message);
        } finally {
            setPasskeyProcessing(false);
        }
    };

    return (
        <AuthLayout
            title="Log in to your account"
            description="Enter your email and password below to log in, or use a saved passkey"
        >
            <Head title="Log in" />

            <Form
                {...store()}
                resetOnSuccess={['password']}
                onStart={() => {
                    abortController.current?.abort();
                }}
                onError={(errors) => {
                    Object.values(errors).forEach((message) =>
                        toast.error(message),
                    );
                }}
                className="flex flex-col gap-6"
            >
                {({ processing }) => (
                    <>
                        <div className="grid gap-6">

                {/* Discord OAuth */}
                <a
                    href="/auth/discord"
                    className="flex w-full items-center justify-center gap-2 rounded-lg border border-[#5865F2]/30 bg-[#5865F2]/10 px-4 py-2.5 text-sm font-medium text-[#5865F2] transition hover:bg-[#5865F2]/20"
                >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.101 18.08.114 18.102.132 18.116a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
                    </svg>
                    Sign in with Discord
                </a>

                <div className="relative flex items-center">
                    <div className="flex-grow border-t border-border" />
                    <span className="mx-3 shrink text-xs text-muted-foreground">or with email</span>
                    <div className="flex-grow border-t border-border" />
                </div>

                            <div className="grid gap-2">
                                <Label htmlFor="email">Email address</Label>
                                <Input
                                    id="email"
                                    type="email"
                                    name="email"
                                    required
                                    autoFocus
                                    tabIndex={1}
                                    autoComplete={passkeyAutocomplete()}
                                    placeholder="email@example.com"
                                />
                            </div>

                            <div className="grid gap-2">
                                <div className="flex items-center">
                                    <Label htmlFor="password">Password</Label>
                                    {canResetPassword && (
                                        <TextLink
                                            href={request()}
                                            className="ml-auto text-sm"
                                            tabIndex={5}
                                        >
                                            Forgot password?
                                        </TextLink>
                                    )}
                                </div>
                                <PasswordInput
                                    id="password"
                                    name="password"
                                    required
                                    tabIndex={2}
                                    autoComplete="current-password"
                                    placeholder="Password"
                                />
                            </div>

                            <div className="flex items-center space-x-3">
                                <Checkbox
                                    id="remember"
                                    name="remember"
                                    tabIndex={3}
                                />
                                <Label htmlFor="remember">Remember me</Label>
                            </div>

                            <Button
                                type="submit"
                                className="mt-4 w-full"
                                tabIndex={4}
                                disabled={processing}
                                data-test="login-button"
                            >
                                {processing && <Spinner />}
                                Log in
                            </Button>

                            {canUsePasskeys && (
                                <Button
                                    type="button"
                                    variant="outline"
                                    className="w-full"
                                    onClick={handlePasskeyLogin}
                                    disabled={processing || passkeyProcessing}
                                >
                                    {passkeyProcessing && <Spinner />}
                                    <KeyRound />
                                    Use a passkey
                                </Button>
                            )}
                        </div>

                        {canRegister && (
                            <div className="text-center text-sm text-muted-foreground">
                                Don't have an account?{' '}
                                <TextLink href={register()} tabIndex={5}>
                                    Sign up
                                </TextLink>
                            </div>
                        )}
                    </>
                )}
            </Form>
        </AuthLayout>
    );
}
