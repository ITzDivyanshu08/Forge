import { Head, usePage } from '@inertiajs/react';
import { CheckCircle, Clock, AlertCircle, XCircle, CreditCard, Smartphone, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

const PACKAGES = [
    { inr: 50,  coins: 500 },
    { inr: 100, coins: 1100, badge: '+100 bonus' },
    { inr: 250, coins: 3000, badge: '+500 bonus' },
    { inr: 500, coins: 6500, badge: '+1000 bonus' },
];

type Tab = 'stripe' | 'upi';

interface Transaction {
    uuid: string;
    gateway: string;
    amount: number;
    coins_given: number;
    status: string;
    description: string;
    created_at: string;
    upi_ref?: string;
}

export default function Billing({ transactions }: { transactions: Transaction[] }) {
    const { auth } = usePage<{ auth: { user: { coins: number } } }>().props;
    const [tab, setTab] = useState<Tab>('upi');
    const [upiData, setUpiData] = useState<any>(null);
    const [upiRef, setUpiRef] = useState('');
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState('');

    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';

    const buyUpi = async (inr: number) => {
        setLoading(true); setMsg('');
        const res = await fetch('/billing/upi', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify({ amount: inr }),
        });
        const data = await res.json();
        setLoading(false);
        if (data.tx_id) setUpiData(data);
        else setMsg(data.error ?? 'Failed');
    };

    const buyStripe = async (inr: number) => {
        setLoading(true); setMsg('');
        const res = await fetch('/billing/stripe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify({ amount: inr }),
        });
        const data = await res.json();
        setLoading(false);
        if (data.url) window.location.href = data.url;
        else setMsg(data.error ?? 'Failed');
    };

    const submitUpiRef = async () => {
        if (!upiRef.trim()) return setMsg('Enter UPI reference number');
        setLoading(true); setMsg('');
        const res = await fetch('/billing/upi/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify({ tx_id: upiData.tx_id, upi_ref: upiRef }),
        });
        const data = await res.json();
        setLoading(false);
        if (data.success) { setMsg('✅ Submitted! Admin will confirm shortly.'); setUpiData(null); setUpiRef(''); }
        else setMsg(data.error ?? 'Failed');
    };

    const statusBadge = (s: string) => {
        if (s === 'completed') return <span className="flex items-center gap-1 text-green-500 text-xs"><CheckCircle size={10} /> Completed</span>;
        if (s === 'verifying') return <span className="flex items-center gap-1 text-yellow-500 text-xs"><AlertCircle size={10} /> Verifying</span>;
        if (s === 'failed')    return <span className="flex items-center gap-1 text-red-500 text-xs"><XCircle size={10} /> Failed</span>;
        return <span className="flex items-center gap-1 text-blue-500 text-xs"><Clock size={10} /> Pending</span>;
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Billing', href: '/billing' }]}>
            <Head title="Billing" />
            <div className="flex flex-col gap-6 p-6 max-w-3xl">
                <div>
                    <h1 className="text-2xl font-bold">Billing</h1>
                    <p className="text-muted-foreground text-sm mt-1">Purchase coins to use on servers and resources</p>
                </div>

                {/* Balance */}
                <div className="rounded-xl border border-brand/30 bg-brand/5 p-4 text-center">
                    <p className="text-muted-foreground text-sm">Your Balance</p>
                    <p className="text-4xl font-bold text-brand mt-1">{auth?.user?.coins?.toLocaleString() ?? 0} 🪙</p>
                </div>

                {msg && (
                    <div className={`rounded-lg border p-3 text-sm text-center ${msg.startsWith('✅') ? 'border-green-500/30 bg-green-500/5 text-green-500' : 'border-red-500/30 bg-red-500/5 text-red-500'}`}>
                        {msg}
                    </div>
                )}

                {/* Tabs */}
                <div className="flex gap-2">
                    {(['upi', 'stripe'] as Tab[]).map(t => (
                        <button key={t} onClick={() => setTab(t)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition ${tab === t ? 'bg-brand text-white' : 'border border-border hover:opacity-80'}`}>
                            {t === 'upi' ? <Smartphone size={14} /> : <CreditCard size={14} />}
                            {t === 'upi' ? 'UPI (India)' : 'Card (Stripe)'}
                        </button>
                    ))}
                </div>

                {/* UPI */}
                {tab === 'upi' && !upiData && (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                        {PACKAGES.map(p => (
                            <button key={p.inr} onClick={() => buyUpi(p.inr)} disabled={loading}
                                className="rounded-xl border border-border bg-card p-4 text-center hover:border-brand/50 transition disabled:opacity-50">
                                <p className="text-2xl font-bold text-brand">₹{p.inr}</p>
                                <p className="text-sm mt-1">{p.coins.toLocaleString()} coins</p>
                                {p.badge && <span className="mt-2 inline-block rounded-full bg-green-500/10 px-2 py-0.5 text-xs text-green-600">{p.badge}</span>}
                            </button>
                        ))}
                    </div>
                )}

                {tab === 'upi' && upiData && (
                    <div className="rounded-xl border border-border bg-card p-6 max-w-xs mx-auto text-center space-y-4">
                        <h2 className="font-bold text-lg">Scan to Pay</h2>
                        <img src={upiData.qr_code} alt="UPI QR" className="w-48 h-48 mx-auto rounded-lg" />
                        <div>
                            <p className="text-sm text-muted-foreground">Pay to</p>
                            <p className="font-mono font-bold text-brand">{upiData.vpa}</p>
                            <p className="font-bold text-2xl mt-1">₹{upiData.amount}</p>
                            <p className="text-sm text-muted-foreground">= {upiData.coins} coins</p>
                        </div>
                        <div className="rounded-lg bg-yellow-500/10 border border-yellow-500/30 p-2 text-xs text-yellow-700 dark:text-yellow-400">
                            After paying, enter your UPI transaction reference below
                        </div>
                        <input
                            className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm text-center outline-none focus:ring-2 focus:ring-brand"
                            placeholder="UTR / Reference number"
                            value={upiRef}
                            onChange={e => setUpiRef(e.target.value)}
                        />
                        <div className="flex gap-2">
                            <button onClick={() => setUpiData(null)} className="flex-1 rounded-lg border border-border py-2 text-sm hover:opacity-80">Cancel</button>
                            <button onClick={submitUpiRef} disabled={loading} className="flex-1 rounded-lg bg-brand text-white py-2 text-sm font-semibold hover:opacity-90 disabled:opacity-50">
                                {loading ? 'Submitting...' : 'Submit'}
                            </button>
                        </div>
                    </div>
                )}

                {/* Stripe */}
                {tab === 'stripe' && (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                        {PACKAGES.map(p => (
                            <button key={p.inr} onClick={() => buyStripe(p.inr)} disabled={loading}
                                className="rounded-xl border border-border bg-card p-4 text-center hover:border-brand/50 transition disabled:opacity-50">
                                <p className="text-2xl font-bold text-brand">₹{p.inr}</p>
                                <p className="text-sm mt-1">{p.coins.toLocaleString()} coins</p>
                                {p.badge && <span className="mt-2 inline-block rounded-full bg-green-500/10 px-2 py-0.5 text-xs text-green-600">{p.badge}</span>}
                            </button>
                        ))}
                    </div>
                )}

                {/* Transaction history */}
                <div>
                    <h2 className="font-semibold mb-3">Transaction History</h2>
                    {transactions.length === 0 ? (
                        <div className="rounded-xl border border-border bg-card p-8 text-center text-muted-foreground text-sm">No transactions yet</div>
                    ) : (
                        <div className="space-y-2">
                            {transactions.map(tx => (
                                <div key={tx.uuid} className="flex items-center justify-between rounded-lg border border-border bg-card p-3">
                                    <div>
                                        <p className="text-sm font-medium">{tx.description}</p>
                                        <p className="text-xs text-muted-foreground">{new Date(tx.created_at).toLocaleString()}</p>
                                    </div>
                                    <div className="text-right">
                                        {statusBadge(tx.status)}
                                        {tx.coins_given > 0 && <p className="text-sm font-bold text-brand mt-0.5">+{tx.coins_given} 🪙</p>}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </AppLayout>
    );
}
