import { Head, useForm } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Message { id: number; message: string; is_staff: boolean; user: { name: string }; created_at: string; }
interface Ticket { id: number; uuid: string; subject: string; status: string; priority: string; messages: Message[]; user: { name: string }; }

export default function TicketShow({ ticket }: { ticket: Ticket }) {
    const { data, setData, post, processing } = useForm({ message: '' });

    const submit = (e: React.FormEvent) => {
        e.preventDefault();
        post(`/tickets/${ticket.uuid}/reply`, { preserveScroll: true, onSuccess: () => setData('message', '') });
    };

    const statusColor = ticket.status === 'open' ? 'text-blue-500' : ticket.status === 'in_progress' ? 'text-yellow-500' : 'text-zinc-400';

    return (
        <AppLayout breadcrumbs={[{ title: 'Tickets', href: '/tickets' }, { title: ticket.subject, href: `/tickets/${ticket.uuid}` }]}>
            <Head title={ticket.subject} />
            <div className="flex flex-col gap-4 p-6 max-w-3xl">
                <div className="flex items-start justify-between gap-3">
                    <div>
                        <h1 className="text-xl font-bold">{ticket.subject}</h1>
                        <p className="text-sm text-muted-foreground mt-0.5">
                            Ticket #{ticket.id} ·
                            <span className={`ml-1 font-medium ${statusColor}`}>{ticket.status.replace('_',' ')}</span>
                            <span className="ml-2">· Priority: {ticket.priority}</span>
                        </p>
                    </div>
                </div>

                {/* Messages */}
                <div className="space-y-3">
                    {ticket.messages.map(msg => (
                        <div key={msg.id} className={`flex gap-3 ${msg.is_staff ? 'flex-row-reverse' : ''}`}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${msg.is_staff ? 'bg-brand text-white' : 'bg-sidebar border border-border'}`}>
                                {msg.user.name[0].toUpperCase()}
                            </div>
                            <div className={`flex-1 rounded-xl border p-3 ${msg.is_staff ? 'border-brand/30 bg-brand/5' : 'border-border bg-card'}`}>
                                <div className="flex items-center justify-between gap-2 mb-1">
                                    <span className="text-xs font-semibold">{msg.is_staff ? '🛡 Staff' : msg.user.name}</span>
                                    <span className="text-xs text-muted-foreground">{new Date(msg.created_at).toLocaleString()}</span>
                                </div>
                                <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Reply */}
                {ticket.status !== 'closed' && (
                    <form onSubmit={submit} className="space-y-3 rounded-xl border border-border bg-card p-4">
                        <h2 className="font-semibold text-sm">Reply</h2>
                        <textarea
                            value={data.message}
                            onChange={e => setData('message', e.target.value)}
                            rows={4}
                            placeholder="Type your reply..."
                            className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand resize-none"
                            required
                        />
                        <button type="submit" disabled={processing}
                            className="rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90 disabled:opacity-50">
                            {processing ? 'Sending...' : 'Send Reply'}
                        </button>
                    </form>
                )}
                {ticket.status === 'closed' && (
                    <div className="rounded-lg border border-border bg-sidebar p-3 text-sm text-center text-muted-foreground">
                        This ticket is closed.
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
