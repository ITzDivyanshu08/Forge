import { Head, Link, useForm } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Ticket {
    id: number; uuid: string; subject: string;
    status: string; priority: string; created_at: string;
    messages: { message: string; created_at: string }[];
}

const statusColor = (s: string) => ({
    open: 'bg-blue-500/10 text-blue-500',
    in_progress: 'bg-yellow-500/10 text-yellow-600',
    closed: 'bg-zinc-500/10 text-zinc-500',
}[s] ?? 'bg-zinc-500/10 text-zinc-500');

const priorityColor = (p: string) => ({
    low: 'text-zinc-400', normal: 'text-blue-400',
    high: 'text-orange-400', urgent: 'text-red-400',
}[p] ?? 'text-zinc-400');

export default function Tickets({ tickets }: { tickets: Ticket[] }) {
    const { data, setData, post, processing, reset } = useForm({
        subject: '', message: '', priority: 'normal',
    });

    const [showForm, setShowForm] = (typeof useState !== 'undefined' ? [false, () => {}] : [false, () => {}]) as any;

    return (
        <AppLayout breadcrumbs={[{ title: 'Support Tickets', href: '/tickets' }]}>
            <Head title="Support Tickets" />
            <div className="flex flex-col gap-6 p-6 max-w-3xl">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold">Support Tickets</h1>
                        <p className="text-muted-foreground text-sm mt-1">Get help from our support team</p>
                    </div>
                    <Link href="/tickets/create"
                        className="flex items-center gap-2 rounded-lg bg-brand px-4 py-2 text-sm text-white font-semibold hover:opacity-90">
                        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4">
                            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        New Ticket
                    </Link>
                </div>

                {tickets.length === 0 ? (
                    <div className="rounded-xl border border-border bg-card p-12 text-center">
                        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-40">
                            <path d="M21 15C21 15 19.5 14 19.5 12.5C19.5 11 21 10 21 10V5C21 3.89543 20.1046 3 19 3H5C3.89543 3 3 3.89543 3 5V10C3 10 4.5 11 4.5 12.5C4.5 14 3 15 3 15V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 21 20.1046 21 19V15Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        <p className="font-semibold">No tickets yet</p>
                        <p className="text-sm text-muted-foreground mt-1">Create a ticket if you need help</p>
                    </div>
                ) : (
                    <div className="space-y-2">
                        {tickets.map(t => (
                            <Link key={t.uuid} href={`/tickets/${t.uuid}`}
                                className="flex items-center justify-between rounded-xl border border-border bg-card p-4 hover:border-brand/30 transition">
                                <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <p className="font-medium truncate">{t.subject}</p>
                                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(t.status)}`}>
                                            {t.status.replace('_', ' ')}
                                        </span>
                                    </div>
                                    <p className="text-xs text-muted-foreground mt-0.5">
                                        #{t.id} · {new Date(t.created_at).toLocaleDateString()}
                                        <span className={`ml-2 font-medium ${priorityColor(t.priority)}`}>{t.priority}</span>
                                    </p>
                                    {t.messages[0] && (
                                        <p className="text-xs text-muted-foreground mt-1 truncate">{t.messages[0].message}</p>
                                    )}
                                </div>
                                <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4 shrink-0 ml-2 text-muted-foreground">
                                    <path d="M9 18L15 12L9 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                                </svg>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
