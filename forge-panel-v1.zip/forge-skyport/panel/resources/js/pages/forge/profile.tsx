import { Head, Link } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Server { id: number; name: string; status: string; created_at: string; }
interface User { id: number; name: string; coins: number; badge: string | null; discord_username: string | null; discord_id: string | null; discord_avatar: string | null; servers_count: number; referrals_count: number; tickets_count: number; created_at: string; }

const statusDot = (s: string) => ({
    running: 'bg-green-500',
    offline: 'bg-red-500',
    starting: 'bg-yellow-500',
}[s] ?? 'bg-zinc-400');

export default function Profile({ user, servers }: { user: User; servers: Server[] }) {
    const avatar = user.discord_id && user.discord_avatar
        ? `https://cdn.discordapp.com/avatars/${user.discord_id}/${user.discord_avatar}.png?size=128`
        : `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=0718d9&color=fff&size=128`;

    return (
        <AppLayout breadcrumbs={[{ title: 'Leaderboard', href: '/leaderboard' }, { title: user.name, href: '#' }]}>
            <Head title={`${user.name}'s Profile`} />
            <div className="flex flex-col gap-6 p-6 max-w-2xl">
                {/* Profile card */}
                <div className="rounded-xl border border-border bg-card p-6 flex items-center gap-5">
                    <img src={avatar} alt={user.name} className="w-20 h-20 rounded-full object-cover border-2 border-brand/30" />
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                            <h1 className="text-xl font-bold truncate">{user.name}</h1>
                            {user.badge && (
                                <span className="rounded-full bg-brand/10 px-3 py-0.5 text-xs font-semibold text-brand">{user.badge}</span>
                            )}
                            {user.discord_username && (
                                <span className="flex items-center gap-1 rounded-full bg-[#5865F2]/10 px-2 py-0.5 text-xs text-[#5865F2]">
                                    <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                                        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.101 18.08.114 18.102.132 18.116a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
                                    </svg>
                                    {user.discord_username}
                                </span>
                            )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                            Member since {new Date(user.created_at).toLocaleDateString()}
                        </p>
                    </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3">
                    {[
                        { label: 'Coins', value: user.coins.toLocaleString() + ' 🪙', color: 'text-brand' },
                        { label: 'Servers', value: user.servers_count, color: 'text-blue-500' },
                        { label: 'Referrals', value: user.referrals_count, color: 'text-green-500' },
                    ].map(s => (
                        <div key={s.label} className="rounded-xl border border-border bg-card p-4 text-center">
                            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                        </div>
                    ))}
                </div>

                {/* Servers */}
                {servers.length > 0 && (
                    <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                        <h2 className="font-semibold">Servers</h2>
                        <div className="space-y-2">
                            {servers.map(s => (
                                <div key={s.id} className="flex items-center gap-3 text-sm">
                                    <span className={`w-2 h-2 rounded-full shrink-0 ${statusDot(s.status)}`} />
                                    <span className="flex-1 font-medium truncate">{s.name}</span>
                                    <span className="text-xs text-muted-foreground">{s.status}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <Link href="/leaderboard" className="text-sm text-brand hover:underline">← Back to Leaderboard</Link>
            </div>
        </AppLayout>
    );
}
