import { Head, router, usePage } from '@inertiajs/react';
import { Flame, Gift, Star } from 'lucide-react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface DailyInfo {
    streak: number;
    can: boolean;
    next_in: number | null;
    next_reward: number;
    multiplier: number;
}

interface DailyReward {
    id: number;
    streak: number;
    coins_earned: number;
    multiplier: number;
    created_at: string;
}

interface Props {
    info: DailyInfo;
    history: DailyReward[];
}

export default function Daily({ info, history }: Props) {
    const [claiming, setClaiming] = useState(false);
    const [msg, setMsg] = useState('');

    const claim = async () => {
        setClaiming(true);
        setMsg('');
        try {
            const res = await fetch('/daily/claim', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '',
                    'Accept': 'application/json',
                },
            });
            const data = await res.json();
            if (data.success) {
                setMsg(`🎉 Claimed ${data.coins_earned} coins! ${data.streak}-day streak!`);
                router.reload({ only: ['info'] });
            } else {
                setMsg(data.error ?? 'Failed');
            }
        } catch {
            setMsg('Request failed');
        } finally {
            setClaiming(false);
        }
    };

    const formatTime = (mins: number) => {
        const h = Math.floor(mins / 60);
        const m = mins % 60;
        return h > 0 ? `${h}h ${m}m` : `${m}m`;
    };

    const milestones = [
        { days: 7,  mult: '1.5x', coins: Math.floor(25 * 1.5) },
        { days: 14, mult: '2x',   coins: Math.floor(25 * 2) },
        { days: 30, mult: '3x',   coins: Math.floor(25 * 3) },
    ];

    return (
        <AppLayout breadcrumbs={[{ title: 'Daily Reward', href: '/daily' }]}>
            <Head title="Daily Reward" />
            <div className="flex flex-col gap-6 p-6 max-w-lg">
                <div>
                    <h1 className="text-2xl font-bold">Daily Reward</h1>
                    <p className="text-muted-foreground text-sm mt-1">Claim every day to build your streak</p>
                </div>

                {/* Main claim card */}
                <div className="rounded-xl border border-border bg-card p-6 text-center space-y-4">
                    <div className="flex items-center justify-center gap-2 text-5xl font-bold">
                        <Flame className="text-brand" size={40} />
                        <span>{info.streak}</span>
                    </div>
                    <p className="text-muted-foreground">Day Streak</p>

                    {info.multiplier > 1 && (
                        <span className="inline-block rounded-full bg-yellow-500/10 px-3 py-1 text-sm font-semibold text-yellow-600 dark:text-yellow-400">
                            {info.multiplier}x bonus active!
                        </span>
                    )}

                    <p className="text-lg font-semibold">
                        Next reward: <span className="text-brand">{info.next_reward} 🪙</span>
                    </p>

                    {info.can ? (
                        <button
                            onClick={claim}
                            disabled={claiming}
                            className="w-full flex items-center justify-center gap-2 rounded-lg bg-brand px-4 py-3 text-white font-semibold hover:opacity-90 disabled:opacity-50 transition"
                        >
                            <Gift size={18} />
                            {claiming ? 'Claiming...' : 'Claim Daily Reward'}
                        </button>
                    ) : (
                        <div className="rounded-lg bg-sidebar border border-border p-4">
                            <p className="text-sm text-muted-foreground">Next claim in</p>
                            <p className="text-2xl font-bold text-brand">{formatTime(info.next_in ?? 0)}</p>
                        </div>
                    )}

                    {msg && (
                        <p className={`text-sm ${msg.startsWith('🎉') ? 'text-green-500' : 'text-red-500'}`}>{msg}</p>
                    )}
                </div>

                {/* Milestones */}
                <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                    <h2 className="font-semibold">Streak Milestones</h2>
                    {milestones.map(m => {
                        const reached = info.streak >= m.days;
                        return (
                            <div
                                key={m.days}
                                className={`flex items-center justify-between rounded-lg border p-3 ${reached ? 'border-brand/30 bg-brand/5' : 'border-border'}`}
                            >
                                <div className="flex items-center gap-2">
                                    <Star size={16} className={reached ? 'text-brand' : 'text-muted-foreground'} />
                                    <span className="text-sm font-medium">{m.days}-day streak</span>
                                </div>
                                <div className="text-right">
                                    <span className="rounded-full bg-yellow-500/10 px-2 py-0.5 text-xs font-semibold text-yellow-600 dark:text-yellow-400">{m.mult} bonus</span>
                                    <p className="text-xs text-muted-foreground mt-0.5">{m.coins} coins/day</p>
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* History */}
                {history.length > 0 && (
                    <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                        <h2 className="font-semibold">Claim History</h2>
                        <div className="space-y-2">
                            {history.map(r => (
                                <div key={r.id} className="flex items-center justify-between text-sm">
                                    <div>
                                        <span className="font-medium">Day {r.streak}</span>
                                        <span className="ml-2 text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</span>
                                    </div>
                                    <span className="font-semibold text-brand">+{r.coins_earned} 🪙</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
