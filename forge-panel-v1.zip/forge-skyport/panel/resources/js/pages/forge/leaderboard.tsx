import { Head, Link } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface LeaderUser { id: number; name: string; coins?: number; badge?: string; servers_count?: number; referrals_count?: number; }

type Tab = 'coins' | 'servers' | 'referrals';

export default function Leaderboard({ byCoins, byServers, byReferrals }: { byCoins: LeaderUser[]; byServers: LeaderUser[]; byReferrals: LeaderUser[]; }) {
    const [tab, setTab] = useState<Tab>('coins');

    const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
        { id: 'coins', label: 'Coins', icon: (
            <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12 6V8M12 16V18M9 9.5C9 8.67 9.67 8 10.5 8H13.5C14.33 8 15 8.67 15 9.5C15 10.33 14.33 11 13.5 11H10.5C9.67 11 9 11.67 9 12.5C9 13.33 9.67 14 10.5 14H13.5C14.33 14 15 13.33 15 12.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
        )},
        { id: 'servers', label: 'Servers', icon: (
            <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4">
                <rect x="2" y="3" width="20" height="5" rx="1" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                <rect x="2" y="10" width="20" height="5" rx="1" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                <rect x="2" y="17" width="20" height="5" rx="1" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
        )},
        { id: 'referrals', label: 'Referrals', icon: (
            <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4">
                <path d="M17 20H22V18C22 16.34 20.66 15 19 15C18.04 15 17.19 15.45 16.64 16.14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M7 20H2V18C2 16.34 3.34 15 5 15C5.96 15 6.81 15.45 7.36 16.14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="10" r="4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12 14V20" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
        )},
    ];

    const data = { coins: byCoins, servers: byServers, referrals: byReferrals }[tab];
    const getValue = (u: LeaderUser) => {
        if (tab === 'coins') return `${u.coins?.toLocaleString()} 🪙`;
        if (tab === 'servers') return `${u.servers_count} servers`;
        return `${u.referrals_count} referrals`;
    };

    const medals = ['🥇', '🥈', '🥉'];

    return (
        <AppLayout breadcrumbs={[{ title: 'Leaderboard', href: '/leaderboard' }]}>
            <Head title="Leaderboard" />
            <div className="flex flex-col gap-6 p-6 max-w-2xl">
                <div>
                    <h1 className="text-2xl font-bold">Leaderboard</h1>
                    <p className="text-muted-foreground text-sm mt-1">Top players in the community</p>
                </div>

                {/* Tabs */}
                <div className="flex gap-2">
                    {tabs.map(t => (
                        <button key={t.id} onClick={() => setTab(t.id)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition ${tab === t.id ? 'bg-brand text-white' : 'border border-border hover:opacity-80'}`}>
                            {t.icon} {t.label}
                        </button>
                    ))}
                </div>

                <div className="space-y-2">
                    {data.map((user, i) => (
                        <Link key={user.id} href={`/profile/${user.id}`}
                            className={`flex items-center gap-4 rounded-xl border p-4 hover:border-brand/30 transition ${i === 0 ? 'border-yellow-500/30 bg-yellow-500/5' : 'border-border bg-card'}`}>
                            <span className="text-2xl w-8 text-center">{medals[i] ?? `#${i + 1}`}</span>
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                    <span className="font-semibold truncate">{user.name}</span>
                                    {user.badge && (
                                        <span className="rounded-full bg-brand/10 px-2 py-0.5 text-xs font-medium text-brand">{user.badge}</span>
                                    )}
                                </div>
                            </div>
                            <span className="font-bold text-sm text-brand">{getValue(user)}</span>
                        </Link>
                    ))}
                </div>
            </div>
        </AppLayout>
    );
}
