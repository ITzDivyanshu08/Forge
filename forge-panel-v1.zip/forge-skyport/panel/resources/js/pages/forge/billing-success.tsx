// forge/billing-success.tsx
import { Head, Link } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Transaction { coins_given: number; amount: number; status: string; }

export default function BillingSuccess({ transaction }: { transaction: Transaction | null }) {
    const ok = transaction?.status === 'completed';
    return (
        <AppLayout breadcrumbs={[{ title: 'Billing', href: '/billing' }, { title: ok ? 'Payment Success' : 'Payment Status', href: '#' }]}>
            <Head title={ok ? 'Payment Successful' : 'Payment Status'} />
            <div className="flex flex-col items-center justify-center p-12 text-center max-w-md mx-auto gap-6">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center ${ok ? 'bg-green-500/10' : 'bg-yellow-500/10'}`}>
                    {ok ? (
                        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-10 h-10 text-green-500">
                            <path d="M20 6L9 17L4 12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    ) : (
                        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-10 h-10 text-yellow-500">
                            <path d="M12 9V13M12 17H12.01M10.29 3.86L1.82 18C1.64 18.3 1.55 18.65 1.56 19C1.56 19.35 1.66 19.7 1.85 20C2.04 20.3 2.31 20.55 2.63 20.72C2.95 20.89 3.31 20.98 3.67 21H20.33C20.69 21 21.05 20.89 21.37 20.72C21.69 20.55 21.96 20.3 22.15 20C22.34 19.7 22.44 19.35 22.44 19C22.45 18.65 22.36 18.3 22.18 18L13.71 3.86C13.53 3.57 13.27 3.33 12.96 3.16C12.65 3 12.32 2.91 11.99 2.91C11.66 2.91 11.33 3 11.02 3.16C10.71 3.33 10.45 3.57 10.27 3.86H10.29Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    )}
                </div>
                <div>
                    <h1 className="text-2xl font-bold">{ok ? 'Payment Successful!' : 'Payment Pending'}</h1>
                    <p className="text-muted-foreground mt-2 text-sm">
                        {ok
                            ? `${transaction!.coins_given.toLocaleString()} coins have been added to your account!`
                            : 'Your payment is being processed. Coins will be added once confirmed.'}
                    </p>
                </div>
                <Link href="/billing" className="rounded-lg bg-brand px-6 py-2.5 text-sm text-white font-semibold hover:opacity-90">
                    Back to Billing
                </Link>
            </div>
        </AppLayout>
    );
}
