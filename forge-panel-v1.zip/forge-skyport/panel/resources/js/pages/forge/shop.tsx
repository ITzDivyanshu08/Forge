// forge/shop.tsx
import { Head, usePage } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface ShopItem { id: string; label: string; unit: string; amount: number; cost: number; }
interface Props { items: ShopItem[]; user: { coins: number; ram_limit: number; disk_limit: number; cpu_limit: number; server_limit: number; }; }

export default function Shop({ items, user }: Props) {
    const [qty, setQty] = useState<Record<string, number>>({});
    const [msg, setMsg] = useState('');
    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';

    const buy = async (item: ShopItem) => {
        const amount = qty[item.id] || 1;
        const total = item.cost * amount;
        if (user.coins < total) return setMsg(`Not enough coins (need ${total})`);
        const res = await fetch('/shop/buy', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify({ item: item.id, amount }),
        });
        const data = await res.json();
        if (data.success) { setMsg(`✅ Bought ${amount}x ${item.label} for ${total} coins!`); setTimeout(() => window.location.reload(), 1000); }
        else setMsg(data.error ?? 'Failed');
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Shop', href: '/shop' }]}>
            <Head title="Shop" />
            <div className="flex flex-col gap-6 p-6 max-w-2xl">
                <div>
                    <h1 className="text-2xl font-bold">Resource Shop</h1>
                    <p className="text-muted-foreground text-sm mt-1">Spend coins to upgrade your resource limits</p>
                </div>
                <div className="rounded-xl border border-brand/30 bg-brand/5 p-3 text-center">
                    <p className="text-2xl font-bold text-brand">{user.coins.toLocaleString()} 🪙</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Available coins</p>
                </div>
                {msg && <div className={`rounded-lg border p-3 text-sm text-center ${msg.startsWith('✅') ? 'border-green-500/30 text-green-500' : 'border-red-500/30 text-red-500'}`}>{msg}</div>}
                <div className="grid gap-3 sm:grid-cols-2">
                    {items.map(item => {
                        const amount = qty[item.id] || 1;
                        return (
                            <div key={item.id} className="rounded-xl border border-border bg-card p-4 space-y-3">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <p className="font-semibold">{item.label}</p>
                                        <p className="text-sm text-muted-foreground">+{item.unit} per purchase</p>
                                    </div>
                                    <p className="font-bold text-brand">{item.cost} 🪙 each</p>
                                </div>
                                <div className="flex gap-2 items-center">
                                    <input type="number" min={1} max={100} value={amount}
                                        onChange={e => setQty(q => ({ ...q, [item.id]: Math.max(1, +e.target.value) }))}
                                        className="w-16 rounded-lg border border-border bg-sidebar px-2 py-1 text-sm text-center" />
                                    <span className="text-sm text-muted-foreground flex-1">= {item.cost * amount} coins</span>
                                    <button onClick={() => buy(item)} disabled={user.coins < item.cost * amount}
                                        className="rounded-lg bg-brand px-3 py-1.5 text-sm text-white font-semibold hover:opacity-90 disabled:opacity-40">Buy</button>
                                </div>
                            </div>
                        );
                    })}
                </div>
                <div className="rounded-xl border border-border bg-card p-4 grid grid-cols-2 gap-3 text-center text-sm">
                    {[['RAM', `${user.ram_limit} MB`], ['Disk', `${user.disk_limit} MB`], ['CPU', `${user.cpu_limit}%`], ['Servers', user.server_limit]].map(([k, v]) => (
                        <div key={String(k)}><p className="text-muted-foreground">{k}</p><p className="font-bold">{v}</p></div>
                    ))}
                </div>
            </div>
        </AppLayout>
    );
}
