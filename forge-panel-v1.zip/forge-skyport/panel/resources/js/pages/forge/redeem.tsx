import { Head } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

export default function Redeem() {
    const [code, setCode] = useState('');
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState('');

    const csrf = () => document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';

    const submit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!code.trim()) return;
        setLoading(true); setMsg('');
        const res = await fetch('/redeem', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },
            body: JSON.stringify({ code: code.trim().toUpperCase() }),
        });
        const data = await res.json();
        setLoading(false);
        if (data.success) {
            setMsg(`🎉 Code redeemed! You got +${data.coins} coins!`);
            setCode('');
        } else {
            setMsg(data.error ?? 'Invalid or already used code');
        }
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Redeem Code', href: '/redeem' }]}>
            <Head title="Redeem Code" />
            <div className="flex flex-col gap-6 p-6 max-w-md">
                <div>
                    <h1 className="text-2xl font-bold">Redeem Code</h1>
                    <p className="text-muted-foreground text-sm mt-1">
                        Enter a redeem code to claim free coins
                    </p>
                </div>

                <div className="rounded-xl border border-border bg-card p-6 space-y-4">
                    <div className="flex items-center justify-center">
                        {/* Gift SVG icon */}
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" strokeWidth="1.5"
                            className="w-16 h-16 text-brand">
                            <path d="M20 12V22H4V12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M22 7H2V12H22V7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M12 22V7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M12 7H7.5C6.11929 7 5 5.88071 5 4.5C5 3.11929 6.11929 2 7.5 2C10 2 12 7 12 7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M12 7H16.5C17.8807 7 19 5.88071 19 4.5C19 3.11929 17.8807 2 16.5 2C14 2 12 7 12 7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    </div>

                    <form onSubmit={submit} className="space-y-3">
                        <input
                            type="text"
                            value={code}
                            onChange={e => setCode(e.target.value.toUpperCase())}
                            placeholder="ENTER CODE HERE"
                            maxLength={30}
                            className="w-full rounded-lg border border-border bg-sidebar px-4 py-3 text-center font-mono text-lg font-bold uppercase tracking-widest outline-none focus:ring-2 focus:ring-brand"
                        />
                        <button
                            type="submit"
                            disabled={loading || !code.trim()}
                            className="w-full rounded-lg bg-brand py-3 text-white font-semibold hover:opacity-90 disabled:opacity-50 transition"
                        >
                            {loading ? 'Checking...' : 'Redeem'}
                        </button>
                    </form>

                    {msg && (
                        <div className={`rounded-lg border p-3 text-sm text-center ${
                            msg.startsWith('🎉')
                                ? 'border-green-500/30 bg-green-500/5 text-green-500'
                                : 'border-red-500/30 bg-red-500/5 text-red-500'
                        }`}>
                            {msg}
                        </div>
                    )}
                </div>

                <div className="rounded-xl border border-border bg-card p-4 space-y-2">
                    <h2 className="font-semibold text-sm">How it works</h2>
                    <ul className="space-y-1.5 text-sm text-muted-foreground">
                        {[
                            'Each code can only be used once per account',
                            'Codes are first-come, first-served',
                            'Coins are added instantly on redemption',
                            'Codes may expire — use them while they last!',
                        ].map((t, i) => (
                            <li key={i} className="flex items-start gap-2">
                                <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5" className="w-4 h-4 shrink-0 mt-0.5 text-brand">
                                    <path d="M20 6L9 17L4 12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                                </svg>
                                {t}
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </AppLayout>
    );
}
