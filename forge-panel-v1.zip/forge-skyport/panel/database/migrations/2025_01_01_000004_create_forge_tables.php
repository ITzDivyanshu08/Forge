<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Server renewals
        Schema::create('renewals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('server_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('coin_cost')->default(0);
            $table->timestamp('expires_at')->nullable();
            $table->string('period')->default('monthly'); // daily|weekly|monthly|custom
            $table->unsignedInteger('custom_days')->nullable();
            $table->boolean('suspended')->default(false);
            $table->timestamps();
        });

        // Referrals
        Schema::create('referrals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('referrer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('referee_id')->constrained('users')->cascadeOnDelete();
            $table->unsignedInteger('coins_given')->default(0);
            $table->timestamps();
            $table->unique('referee_id');
        });

        // Redeem codes
        Schema::create('redeem_codes', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();
            $table->unsignedInteger('coins')->default(0);
            $table->unsignedInteger('max_uses')->default(1);
            $table->unsignedInteger('uses')->default(0);
            $table->boolean('active')->default(true);
            $table->text('description')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
        });

        // Redeem code usage log
        Schema::create('redeem_code_uses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('redeem_code_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('coins_given')->default(0);
            $table->timestamps();
            $table->unique(['redeem_code_id', 'user_id']);
        });

        // Cloudflare subdomains
        Schema::create('subdomains', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('server_id')->constrained()->cascadeOnDelete();
            $table->string('subdomain');
            $table->string('domain');
            $table->string('cf_record_id')->nullable();
            $table->string('target');
            $table->timestamps();
        });

        // Support tickets
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('subject');
            $table->string('status')->default('open'); // open|in_progress|closed
            $table->string('priority')->default('normal'); // low|normal|high|urgent
            $table->timestamps();
        });

        Schema::create('ticket_messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ticket_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->text('message');
            $table->boolean('is_staff')->default(false);
            $table->timestamps();
        });

        // Announcements
        Schema::create('announcements', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('content');
            $table->string('type')->default('info'); // info|warning|danger|success
            $table->boolean('active')->default(true);
            $table->timestamp('expires_at')->nullable();
            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
        });

        // Server maintenance mode
        Schema::table('servers', function (Blueprint $table) {
            $table->boolean('maintenance_mode')->default(false)->after('status');
            $table->text('maintenance_message')->nullable()->after('maintenance_mode');
            $table->timestamp('expires_at')->nullable()->after('maintenance_message');
        });

        // Notifications
        Schema::create('forge_notifications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('type'); // renewal_warning|payment|ticket|announcement|gift
            $table->string('title');
            $table->text('message');
            $table->boolean('read')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('forge_notifications');
        Schema::table('servers', fn($t) => $t->dropColumn(['maintenance_mode', 'maintenance_message', 'expires_at']));
        Schema::dropIfExists('announcements');
        Schema::dropIfExists('ticket_messages');
        Schema::dropIfExists('tickets');
        Schema::dropIfExists('subdomains');
        Schema::dropIfExists('redeem_code_uses');
        Schema::dropIfExists('redeem_codes');
        Schema::dropIfExists('referrals');
        Schema::dropIfExists('renewals');
    }
};
