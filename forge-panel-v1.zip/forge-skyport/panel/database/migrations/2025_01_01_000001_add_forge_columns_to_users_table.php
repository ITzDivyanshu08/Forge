<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->unsignedBigInteger('coins')->default(0)->after('email');
            $table->string('discord_id')->nullable()->unique()->after('coins');
            $table->string('discord_username')->nullable()->after('discord_id');
            $table->string('discord_avatar')->nullable()->after('discord_username');
            $table->string('referral_code')->nullable()->unique()->after('discord_avatar');
            $table->unsignedBigInteger('referred_by')->nullable()->after('referral_code');
            $table->string('daemon_preference')->default('wings')->after('referred_by'); // wings | skyport
            $table->unsignedInteger('ram_limit')->default(2048)->after('daemon_preference');
            $table->unsignedInteger('disk_limit')->default(5120)->after('ram_limit');
            $table->unsignedInteger('cpu_limit')->default(100)->after('disk_limit');
            $table->unsignedInteger('server_limit')->default(1)->after('cpu_limit');
            $table->string('badge')->nullable()->after('server_limit');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'coins', 'discord_id', 'discord_username', 'discord_avatar',
                'referral_code', 'referred_by', 'daemon_preference',
                'ram_limit', 'disk_limit', 'cpu_limit', 'server_limit', 'badge',
            ]);
        });
    }
};
