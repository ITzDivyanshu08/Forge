<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('type'); // topup | shop | renewal | gift | redeem | daily | referral
            $table->string('gateway')->nullable(); // stripe | upi | coins | system
            $table->decimal('amount', 10, 2)->default(0);
            $table->string('currency', 10)->default('INR');
            $table->unsignedInteger('coins_given')->default(0);
            $table->string('status')->default('pending'); // pending | verifying | completed | failed
            $table->string('gateway_ref')->nullable();
            $table->string('upi_ref')->nullable();
            $table->string('stripe_session_id')->nullable();
            $table->text('description')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};
