<?php

namespace App\Services;

use App\Models\DailyReward;
use App\Models\User;

class DailyRewardService
{
    public function canClaim(User $user): array
    {
        $last = DailyReward::where('user_id', $user->id)->latest()->first();

        if (! $last) {
            return ['can' => true, 'streak' => 0, 'next_in' => null];
        }

        $hoursSince = $last->created_at->diffInHours(now());

        if ($hoursSince < 20) {
            $nextIn = (int) ceil((20 - $hoursSince) * 60);
            return ['can' => false, 'streak' => $last->streak, 'next_in' => $nextIn];
        }

        $streakBroken = $hoursSince > 48;
        return ['can' => true, 'streak' => $streakBroken ? 0 : $last->streak, 'next_in' => null];
    }

    public function claim(User $user): array
    {
        $info = $this->canClaim($user);
        if (! $info['can']) throw new \Exception('Already claimed today');

        $newStreak  = $info['streak'] + 1;
        $base       = (int) config('forge.daily.base_coins', 25);
        $multiplier = $this->getMultiplier($newStreak);
        $coins      = (int) floor($base * $multiplier);

        DailyReward::create([
            'user_id'      => $user->id,
            'streak'       => $newStreak,
            'coins_earned' => $coins,
            'multiplier'   => $multiplier,
        ]);

        $user->increment('coins', $coins);

        app(NotificationService::class)->notifyDashboard(
            $user,
            'daily',
            'Daily Reward Claimed!',
            "You earned {$coins} coins. {$newStreak}-day streak!"
        );

        return ['coins_earned' => $coins, 'streak' => $newStreak, 'multiplier' => $multiplier];
    }

    public function getInfo(User $user): array
    {
        $info       = $this->canClaim($user);
        $streak     = $info['streak'];
        $multiplier = $this->getMultiplier($streak + 1);
        $base       = (int) config('forge.daily.base_coins', 25);
        $nextReward = (int) floor($base * $multiplier);

        return [
            'streak'      => $streak,
            'can'         => $info['can'],
            'next_in'     => $info['next_in'],
            'next_reward' => $nextReward,
            'multiplier'  => $multiplier,
        ];
    }

    private function getMultiplier(int $streak): float
    {
        if ($streak >= 30) return (float) config('forge.daily.streak_30_mult', 3.0);
        if ($streak >= 14) return (float) config('forge.daily.streak_14_mult', 2.0);
        if ($streak >= 7)  return (float) config('forge.daily.streak_7_mult', 1.5);
        return 1.0;
    }
}
