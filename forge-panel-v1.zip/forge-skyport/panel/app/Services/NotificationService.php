<?php

namespace App\Services;

use App\Models\ForgeNotification;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;

class NotificationService
{
    public function notifyDashboard(User $user, string $type, string $title, string $message): void
    {
        ForgeNotification::create([
            'user_id' => $user->id,
            'type'    => $type,
            'title'   => $title,
            'message' => $message,
            'read'    => false,
        ]);
    }

    public function notifyAll(User $user, string $type, string $title, string $message): void
    {
        $this->notifyDashboard($user, $type, $title, $message);
        $this->notifyEmail($user, $title, $message);
        $this->notifyDiscord($user, $title, $message);
    }

    public function notifyEmail(User $user, string $title, string $message): void
    {
        try {
            Mail::raw($message, function ($mail) use ($user, $title) {
                $mail->to($user->email)
                     ->subject("[Forge Panel] {$title}");
            });
        } catch (\Throwable) {}
    }

    public function notifyDiscord(User $user, string $title, string $message): void
    {
        $token = config('forge.discord.bot_token');
        if (! $token || ! $user->discord_id) return;

        try {
            // Open DM channel
            $dmRes = Http::withToken($token, 'Bot')
                ->post('https://discord.com/api/v10/users/@me/channels', [
                    'recipient_id' => $user->discord_id,
                ]);

            if (! $dmRes->successful()) return;

            $channelId = $dmRes->json('id');

            Http::withToken($token, 'Bot')
                ->post("https://discord.com/api/v10/channels/{$channelId}/messages", [
                    'embeds' => [[
                        'title'       => $title,
                        'description' => $message,
                        'color'       => 0x0718d9,
                        'footer'      => ['text' => 'Forge Panel'],
                        'timestamp'   => now()->toIso8601String(),
                    ]],
                ]);
        } catch (\Throwable) {}
    }

    public function logWebhook(string $action, string $details, int $color = 0x0718d9): void
    {
        $webhook = config('forge.discord.log_webhook');
        if (! $webhook) return;

        try {
            Http::post($webhook, [
                'embeds' => [[
                    'title'       => strtoupper(str_replace('_', ' ', $action)),
                    'description' => $details,
                    'color'       => $color,
                    'footer'      => ['text' => 'Forge Panel'],
                    'timestamp'   => now()->toIso8601String(),
                ]],
            ]);
        } catch (\Throwable) {}
    }
}
