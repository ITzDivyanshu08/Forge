<?php

namespace App\Services;

use App\Models\Referral;
use App\Models\RedeemCode;
use App\Models\RedeemCodeUse;
use App\Models\Renewal;
use App\Models\Server;
use App\Models\User;
use Illuminate\Support\Str;

// ── Referral ──────────────────────────────────────────────────

class ReferralService
{
    public static function generateCode(): string
    {
        do {
            $code = strtoupper(Str::random(8));
        } while (User::where('referral_code', $code)->exists());
        return $code;
    }

    public function apply(User $newUser, string $code): bool
    {
        if (! config('forge.referral.enabled', true)) return false;

        $referrer = User::where('referral_code', $code)->first();
        if (! $referrer || $referrer->id === $newUser->id) return false;
        if (Referral::where('referee_id', $newUser->id)->exists()) return false;

        $referrerCoins = (int) config('forge.referral.referrer_coins', 200);
        $refereeCoins  = (int) config('forge.referral.referee_coins', 100);

        Referral::create([
            'referrer_id' => $referrer->id,
            'referee_id'  => $newUser->id,
            'coins_given' => $referrerCoins,
        ]);

        $referrer->increment('coins', $referrerCoins);
        $newUser->increment('coins', $refereeCoins);
        $newUser->update(['referred_by' => $referrer->id]);

        app(NotificationService::class)->notifyDashboard(
            $referrer, 'referral',
            'Referral Bonus!',
            "You earned {$referrerCoins} coins — {$newUser->name} joined using your code!"
        );

        return true;
    }

    public function getStats(User $user): array
    {
        $referrals   = Referral::with('referee:id,name,created_at')
            ->where('referrer_id', $user->id)->latest()->get();
        $totalCoins  = $referrals->sum('coins_given');
        return ['code' => $user->referral_code, 'referrals' => $referrals, 'total_coins' => $totalCoins];
    }
}

// ── Redeem ────────────────────────────────────────────────────

class RedeemService
{
    public function redeem(User $user, string $code): array
    {
        $redeemCode = RedeemCode::where('code', strtoupper(trim($code)))->first();

        if (! $redeemCode)           throw new \Exception('Invalid redeem code');
        if (! $redeemCode->isValid()) throw new \Exception('This code has expired or is no longer available');

        if (RedeemCodeUse::where('redeem_code_id', $redeemCode->id)->where('user_id', $user->id)->exists()) {
            throw new \Exception('You have already used this code');
        }

        RedeemCodeUse::create([
            'redeem_code_id' => $redeemCode->id,
            'user_id'        => $user->id,
            'coins_given'    => $redeemCode->coins,
        ]);

        $redeemCode->increment('uses');
        $user->increment('coins', $redeemCode->coins);

        app(NotificationService::class)->notifyDashboard(
            $user, 'redeem',
            'Code Redeemed!',
            "You redeemed code {$redeemCode->code} and got +{$redeemCode->coins} coins!"
        );

        return ['coins' => $redeemCode->coins, 'code' => $redeemCode->code];
    }
}

// ── Renewal ───────────────────────────────────────────────────

class RenewalService
{
    public function getRenewalCost(Server $server): int
    {
        $ramCost  = (int) floor($server->memory_mib / 512);
        $diskCost = (int) floor($server->disk_mib / 1024);
        $cpuCost  = (int) floor($server->cpu_limit / 50);
        return max(1, $ramCost + $diskCost + $cpuCost);
    }

    public function getPeriodDays(): int
    {
        $period = config('forge.renewal.period', 'monthly');
        return match ($period) {
            'daily'   => 1,
            'weekly'  => 7,
            'monthly' => 30,
            'custom'  => (int) config('forge.renewal.custom_days', 30),
            default   => 30,
        };
    }

    public function renew(User $user, int $serverId, string $payWith = 'coins'): array
    {
        $server  = Server::findOrFail($serverId);
        $renewal = Renewal::firstOrNew(['server_id' => $server->id, 'user_id' => $user->id]);
        $cost    = $this->getRenewalCost($server);
        $days    = $this->getPeriodDays();

        if ($user->coins < $cost) throw new \Exception("Not enough coins (need {$cost})");

        $user->decrement('coins', $cost);

        $newExpiry = ($renewal->expires_at && $renewal->expires_at->isFuture())
            ? $renewal->expires_at->addDays($days)
            : now()->addDays($days);

        $renewal->fill([
            'coin_cost'  => $cost,
            'expires_at' => $newExpiry,
            'period'     => config('forge.renewal.period', 'monthly'),
            'suspended'  => false,
        ])->save();

        // Unsuspend if needed
        if ($server->status === 'suspended') {
            $server->update(['status' => 'installing']); // triggers daemon unsuspend
        }

        app(NotificationService::class)->notifyDashboard(
            $user, 'renewal',
            'Server Renewed!',
            "Server '{$server->name}' renewed for {$cost} coins (+{$days} days)."
        );

        return ['cost' => $cost, 'days' => $days, 'expires_at' => $newExpiry];
    }

    public function processExpired(): void
    {
        if (! config('forge.renewal.enabled', true)) return;

        $warningDays = (int) config('forge.renewal.warning_days', 3);
        $graceDays   = (int) config('forge.renewal.grace_days', 7);

        Renewal::with(['server', 'user'])->whereNotNull('expires_at')->each(function (Renewal $renewal) use ($warningDays, $graceDays) {
            $daysLeft = $renewal->daysLeft();

            if ($daysLeft <= $warningDays && $daysLeft > 0 && ! $renewal->suspended) {
                app(NotificationService::class)->notifyAll(
                    $renewal->user,
                    'renewal_warning',
                    'Server Expiring Soon!',
                    "'{$renewal->server->name}' expires in {$daysLeft} day(s). Renew now to avoid suspension!"
                );
            }

            if ($daysLeft <= 0 && ! $renewal->suspended) {
                $renewal->update(['suspended' => true]);
                $renewal->server->update(['status' => 'suspended']);
                app(NotificationService::class)->notifyAll(
                    $renewal->user,
                    'renewal_warning',
                    'Server Suspended',
                    "'{$renewal->server->name}' has been suspended due to non-renewal."
                );
            }

            if ($daysLeft <= -$graceDays) {
                // Delete server after grace period
                $renewal->server->delete();
                $renewal->delete();
            }
        });
    }
}
