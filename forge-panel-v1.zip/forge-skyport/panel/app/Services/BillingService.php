<?php

namespace App\Services;

use App\Models\Transaction;
use App\Models\User;
use Stripe\StripeClient;

class BillingService
{
    private function stripe(): StripeClient
    {
        return new StripeClient(config('forge.stripe.secret'));
    }

    // ── Stripe ────────────────────────────────────────────────

    public function createStripeSession(User $user, float $amountINR): array
    {
        // Convert INR to USD for Stripe (approximate)
        $amountUSD  = round($amountINR / 83, 2);
        $coinsToGive = (int) floor($amountINR * config('forge.coins_per_inr', 10));

        $session = $this->stripe()->checkout->sessions->create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency'     => 'usd',
                    'product_data' => ['name' => "{$coinsToGive} Coins — Forge Panel"],
                    'unit_amount'  => (int) ($amountUSD * 100),
                ],
                'quantity' => 1,
            ]],
            'mode'         => 'payment',
            'success_url'  => route('forge.billing.success') . '?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url'   => route('forge.billing'),
            'customer_email' => $user->email,
            'metadata' => [
                'user_id'      => (string) $user->id,
                'coins'        => (string) $coinsToGive,
                'amount_inr'   => (string) $amountINR,
            ],
        ]);

        Transaction::create([
            'user_id'          => $user->id,
            'type'             => 'topup',
            'gateway'          => 'stripe',
            'amount'           => $amountINR,
            'currency'         => 'INR',
            'coins_given'      => $coinsToGive,
            'status'           => 'pending',
            'stripe_session_id'=> $session->id,
            'description'      => "{$coinsToGive} Coins via Stripe",
        ]);

        return ['url' => $session->url, 'coins' => $coinsToGive];
    }

    public function handleStripeWebhook(string $payload, string $sig): void
    {
        $event = \Stripe\Webhook::constructEvent(
            $payload, $sig, config('forge.stripe.webhook_secret')
        );

        if ($event->type !== 'checkout.session.completed') return;

        $session = $event->data->object;
        $tx      = Transaction::where('stripe_session_id', $session->id)->first();

        if (! $tx || $tx->status === 'completed') return;

        $tx->update(['status' => 'completed', 'completed_at' => now()]);
        $user = $tx->user;
        $user->increment('coins', $tx->coins_given);

        app(NotificationService::class)->notifyAll(
            $user,
            'payment',
            'Payment Confirmed!',
            "Your Stripe payment of ₹{$tx->amount} was confirmed. +{$tx->coins_given} coins added!"
        );
    }

    public function verifyStripeSession(string $sessionId, User $user): ?Transaction
    {
        $tx = Transaction::where('stripe_session_id', $sessionId)
            ->where('user_id', $user->id)->first();

        if (! $tx) return null;
        if ($tx->status === 'completed') return $tx;

        $session = $this->stripe()->checkout->sessions->retrieve($sessionId);
        if ($session->payment_status === 'paid') {
            $tx->update(['status' => 'completed', 'completed_at' => now()]);
            $user->increment('coins', $tx->coins_given);
        }

        return $tx->fresh();
    }

    // ── UPI ───────────────────────────────────────────────────

    public function createUpiPayment(User $user, float $amountINR): array
    {
        $coins = (int) floor($amountINR * config('forge.coins_per_inr', 10));
        $vpa   = config('forge.upi.vpa', 'abcd@fam');
        $name  = config('forge.upi.name', 'Forge Panel');

        $tx = Transaction::create([
            'user_id'     => $user->id,
            'type'        => 'topup',
            'gateway'     => 'upi',
            'amount'      => $amountINR,
            'currency'    => 'INR',
            'coins_given' => $coins,
            'status'      => 'pending',
            'description' => "{$coins} Coins via UPI",
        ]);

        $upiString = "upi://pay?pa={$vpa}&pn=" . urlencode($name)
            . "&am={$amountINR}&cu=INR&tn=" . urlencode("Forge-{$tx->uuid}");

        $qr = base64_encode(\QrCode::format('png')->size(300)->generate($upiString));

        return [
            'tx_id'      => $tx->uuid,
            'upi_string' => $upiString,
            'qr_code'    => "data:image/png;base64,{$qr}",
            'coins'      => $coins,
            'amount'     => $amountINR,
            'vpa'        => $vpa,
        ];
    }

    public function submitUpiRef(string $txUuid, User $user, string $upiRef): Transaction
    {
        $tx = Transaction::where('uuid', $txUuid)->where('user_id', $user->id)->firstOrFail();
        if ($tx->status !== 'pending') throw new \Exception('Transaction already processed');

        $tx->update(['upi_ref' => $upiRef, 'status' => 'verifying']);
        return $tx;
    }

    public function confirmUpi(string $txUuid): Transaction
    {
        $tx = Transaction::where('uuid', $txUuid)->firstOrFail();
        if ($tx->status === 'completed') throw new \Exception('Already completed');

        $tx->update(['status' => 'completed', 'completed_at' => now()]);
        $tx->user->increment('coins', $tx->coins_given);

        app(NotificationService::class)->notifyAll(
            $tx->user,
            'payment',
            'UPI Payment Confirmed!',
            "Your payment of ₹{$tx->amount} was confirmed. +{$tx->coins_given} coins added!"
        );

        return $tx;
    }
}
