<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RedeemCodeUse extends Model {
    protected $fillable = ['redeem_code_id','user_id','coins_given'];
    public function code(): BelongsTo { return $this->belongsTo(RedeemCode::class,'redeem_code_id'); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
