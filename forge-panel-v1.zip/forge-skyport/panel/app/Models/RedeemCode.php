<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class RedeemCode extends Model
{
    protected $fillable = [
        'code', 'coins', 'max_uses', 'uses', 'active',
        'description', 'expires_at', 'created_by',
    ];

    protected $casts = [
        'active'     => 'boolean',
        'expires_at' => 'datetime',
    ];

    public function creator(): BelongsTo { return $this->belongsTo(User::class, 'created_by'); }
    public function uses(): HasMany      { return $this->hasMany(RedeemCodeUse::class); }

    public function isValid(): bool
    {
        return $this->active
            && $this->uses < $this->max_uses
            && (!$this->expires_at || now()->isBefore($this->expires_at));
    }

    public function usesRemaining(): int
    {
        return max(0, $this->max_uses - $this->uses);
    }
}
