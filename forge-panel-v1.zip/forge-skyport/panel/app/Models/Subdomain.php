<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Subdomain extends Model
{
    protected $fillable = ['user_id', 'server_id', 'subdomain', 'domain', 'cf_record_id', 'target'];

    public function user(): BelongsTo   { return $this->belongsTo(User::class); }
    public function server(): BelongsTo { return $this->belongsTo(Server::class); }

    public function getFqdnAttribute(): string
    {
        return "{$this->subdomain}.{$this->domain}";
    }
}
