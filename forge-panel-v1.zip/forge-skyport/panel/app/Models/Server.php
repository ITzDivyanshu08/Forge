<?php

namespace App\Models;

use Database\Factories\ServerFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

#[
    Fillable([
        'user_id',
        'node_id',
        'cargo_id',
        'allocation_id',
        'name',
        'docker_image',
        'startup_command_override',
        'docker_image_override',
        'memory_mib',
        'cpu_limit',
        'disk_mib',
        'backup_limit',
        'allocation_limit',
        'status',
        'last_error',
    ]),
]
class Server extends Model
{
    /** @use HasFactory<ServerFactory> */
    use HasFactory;

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function node(): BelongsTo
    {
        return $this->belongsTo(Node::class);
    }

    public function cargo(): BelongsTo
    {
        return $this->belongsTo(Cargo::class);
    }

    public function allocation(): BelongsTo
    {
        return $this->belongsTo(Allocation::class);
    }

    public function allocations(): HasMany
    {
        return $this->hasMany(Allocation::class);
    }

    public function firewallRules(): HasMany
    {
        return $this->hasMany(FirewallRule::class);
    }

    public function interconnects(): BelongsToMany
    {
        return $this->belongsToMany(Interconnect::class)->withTimestamps();
    }

    public function backups(): HasMany
    {
        return $this->hasMany(Backup::class);
    }

    public function workflows(): HasMany
    {
        return $this->hasMany(Workflow::class);
    }

    public function activeTransfer(): HasOne
    {
        return $this->hasOne(ServerTransfer::class)
            ->whereIn('status', ['archiving', 'transferring', 'extracting', 'completing'])
            ->latest();
    }

    public function serverUsers(): HasMany
    {
        return $this->hasMany(ServerUser::class);
    }

    protected function casts(): array
    {
        return [
            'memory_mib' => 'integer',
            'cpu_limit' => 'integer',
            'disk_mib' => 'integer',
            'backup_limit' => 'integer',
            'allocation_limit' => 'integer',
        ];
    }
}
