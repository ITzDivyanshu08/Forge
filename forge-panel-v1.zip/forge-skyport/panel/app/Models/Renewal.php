<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Renewal extends Model {
    protected $fillable = ['server_id','user_id','coin_cost','expires_at','period','custom_days','suspended'];
    protected $casts = ['expires_at' => 'datetime', 'suspended' => 'boolean'];
    public function server(): BelongsTo { return $this->belongsTo(Server::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function daysLeft(): int {
        if (!$this->expires_at) return 9999;
        return max(0, (int) now()->diffInDays($this->expires_at, false));
    }
    public function isExpired(): bool { return $this->expires_at && now()->isAfter($this->expires_at); }
}
