<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class Transaction extends Model
{
    protected $fillable = [
        'uuid', 'user_id', 'type', 'gateway', 'amount', 'currency',
        'coins_given', 'status', 'gateway_ref', 'upi_ref',
        'stripe_session_id', 'description', 'completed_at',
    ];

    protected $casts = ['completed_at' => 'datetime'];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn ($m) => $m->uuid = (string) Str::uuid());
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
