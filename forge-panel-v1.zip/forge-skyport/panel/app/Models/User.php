<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;

#[Fillable(['name', 'email', 'password', 'is_admin', 'suspended_at', 'coins', 'discord_id', 'discord_username', 'discord_avatar', 'referral_code', 'referred_by', 'daemon_preference', 'ram_limit', 'disk_limit', 'cpu_limit', 'server_limit', 'badge'])]
#[
    Hidden([
        'password',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'remember_token',
    ]),
]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable, TwoFactorAuthenticatable;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'is_admin' => 'boolean',
            'password' => 'hashed',
            'suspended_at' => 'datetime',
            'two_factor_confirmed_at' => 'datetime',
        ];
    }

    public function isSuspended(): bool
    {
        return $this->suspended_at !== null;
    }

    public function activities(): HasMany
    {
        return $this->hasMany(UserActivity::class);
    }

    public function passkeys(): HasMany
    {
        return $this->hasMany(Passkey::class);
    }

    public function servers(): HasMany
    {
        return $this->hasMany(Server::class);
    }
    // ── Forge relationships ───────────────────────────────────────

    public function transactions(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Transaction::class);
    }

    public function dailyRewards(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(DailyReward::class);
    }

    public function referrals(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Referral::class, 'referrer_id');
    }

    public function renewals(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Renewal::class);
    }

    public function tickets(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    public function subdomains(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Subdomain::class);
    }

    public function forgeNotifications(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(ForgeNotification::class);
    }

    public function unreadNotificationsCount(): int
    {
        return $this->forgeNotifications()->where('read', false)->count();
    }

    public function getDiscordAvatarUrlAttribute(): string
    {
        if ($this->discord_id && $this->discord_avatar) {
            return "https://cdn.discordapp.com/avatars/{$this->discord_id}/{$this->discord_avatar}.png?size=64";
        }
        return "https://ui-avatars.com/api/?name=" . urlencode($this->name) . "&background=0718d9&color=fff&size=64";
    }

}
