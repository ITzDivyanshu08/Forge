<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Ticket extends Model
{
    protected $fillable = ['uuid', 'user_id', 'subject', 'status', 'priority'];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn ($m) => $m->uuid ??= (string) Str::uuid());
    }

    public function user(): BelongsTo    { return $this->belongsTo(User::class); }
    public function messages(): HasMany  { return $this->hasMany(TicketMessage::class); }
    public function latestMessage(): HasMany {
        return $this->hasMany(TicketMessage::class)->latest()->limit(1);
    }
}
