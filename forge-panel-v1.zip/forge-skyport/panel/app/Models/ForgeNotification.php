<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ForgeNotification extends Model
{
    protected $table = 'forge_notifications';
    protected $fillable = ['user_id', 'type', 'title', 'message', 'read'];
    protected $casts = ['read' => 'boolean'];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public static function send(int $userId, string $type, string $title, string $message): self
    {
        return static::create(compact('userId', 'type', 'title', 'message') + ['user_id' => $userId]);
    }
}
