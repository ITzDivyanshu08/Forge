<?php

namespace App\Http\Controllers\Forge;

use App\Http\Controllers\Controller;
use App\Services\DiscordService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class DiscordAuthController extends Controller
{
    public function redirect(): RedirectResponse
    {
        if (! config('forge.discord.client_id')) {
            return redirect()->route('login')->withErrors(['Discord OAuth is not configured.']);
        }
        return redirect(app(DiscordService::class)->getAuthUrl());
    }

    public function callback(Request $request): RedirectResponse
    {
        if ($request->has('error')) {
            return redirect()->route('login')->withErrors(['Discord authorization was denied.']);
        }

        try {
            $discordUser = app(DiscordService::class)->handleCallback($request->get('code'));
            $user        = app(DiscordService::class)->findOrCreateUser(
                $discordUser,
                session('referral_code')
            );

            if ($user->isSuspended()) {
                return redirect()->route('login')->withErrors(['Your account has been suspended.']);
            }

            auth()->login($user, true);
            return redirect()->route('home');
        } catch (\Throwable $e) {
            return redirect()->route('login')->withErrors(['Discord login failed: ' . $e->getMessage()]);
        }
    }
}
