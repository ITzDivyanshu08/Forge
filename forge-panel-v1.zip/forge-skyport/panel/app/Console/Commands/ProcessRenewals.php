<?php

namespace App\Console\Commands;

use App\Services\RenewalService;
use Illuminate\Console\Command;

class ProcessRenewals extends Command
{
    protected $signature   = 'forge:renewals';
    protected $description = 'Process server renewals — suspend expired, warn soon-to-expire';

    public function handle(): void
    {
        if (! config('forge.renewal.enabled', true)) {
            $this->info('Renewal system is disabled.');
            return;
        }

        $this->info('Processing renewals...');
        app(RenewalService::class)->processExpired();
        $this->info('Done.');
    }
}
