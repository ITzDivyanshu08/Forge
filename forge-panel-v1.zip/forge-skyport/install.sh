#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════
#                  Forge Panel Installer v1.0.0
#   Skyport fork with Wings + Skyportd, billing, Discord OAuth,
#   daily rewards, referrals, redeem codes, tickets + more
# ═══════════════════════════════════════════════════════════════

INSTALL_DIR="/var/www/forge"
LOG_FILE="/tmp/forge-install.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_DIR="$SCRIPT_DIR/panel"

# ── Colours ───────────────────────────────────────────────────
BLUE='\033[38;2;7;24;217m'
BLUE_DARK='\033[38;2;4;16;143m'
GRAY='\033[38;2;120;120;120m'
GRAY_DARK='\033[38;2;55;55;55m'
WHITE='\033[1;37m'
DIM='\033[2m'
RESET='\033[0m'
RED='\033[38;2;220;50;50m'
GREEN='\033[38;2;80;200;120m'

banner() {
    clear 2>/dev/null || true
    echo ""
    echo -e "  ${BLUE}⚒  Forge Panel${RESET} ${GRAY}— ${DIM}$1${RESET}"
    echo ""
}
info()    { echo -e "  ${GRAY}›${RESET} $1"; }
success() { echo -e "  ${GREEN}✓${RESET} $1"; }
warn()    { echo -e "  ${BLUE_DARK}!${RESET} ${BLUE_DARK}$1${RESET}"; }
error()   { echo -e "  ${RED}✗${RESET} ${RED}$1${RESET}"; }
step()    { echo ""; echo -e "  ${BLUE}─── ${WHITE}$1${RESET}"; echo ""; }

ask() {
    local prompt="$1" default="${2:-}" r
    if [[ -n "$default" ]]; then
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${BLUE_DARK}${default}${GRAY_DARK}]${RESET}: " >&2
    else
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET}: " >&2
    fi
    read -r r || true
    echo "${r:-$default}"
}

ask_secret() {
    echo -ne "  ${BLUE}›${RESET} ${GRAY}$1${RESET}: " >&2
    read -rs r || true
    echo "" >&2
    echo "$r"
}

ask_yn() {
    local prompt="$1" default="${2:-y}" r
    if [[ "$default" == "y" ]]; then
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${BLUE_DARK}Y/n${GRAY_DARK}]${RESET}: " >&2
    else
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${BLUE_DARK}y/N${GRAY_DARK}]${RESET}: " >&2
    fi
    read -r r || true
    [[ "${r:-$default}" =~ ^[Yy] ]]
}

ask_choice() {
    local prompt="$1"; shift; local opts=("$@") i=1 r
    echo -e "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET}" >&2
    for o in "${opts[@]}"; do echo -e "    ${BLUE_DARK}${i})${RESET} ${GRAY}${o}${RESET}" >&2; ((i++)); done
    echo -ne "  ${BLUE}›${RESET} ${GRAY}Choice${RESET}: " >&2
    read -r r || true
    if [[ "$r" -ge 1 && "$r" -le "${#opts[@]}" ]] 2>/dev/null; then echo "$r"; else echo "1"; fi
}

spinner() {
    local pid=$1 label="$2" frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏') i=0
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r  ${BLUE}%s${RESET} ${GRAY}%s${RESET}  " "${frames[$i]}" "$label" >&2
        i=$(( (i+1) % 10 )); sleep 0.1
    done
    wait "$pid"; local code=$?
    printf "\r"
    [[ $code -eq 0 ]] && success "$label" || error "$label — check $LOG_FILE"
    return $code
}

run_step() {
    local label="$1"; shift
    echo "=== [$(date '+%H:%M:%S')] $label ===" >> "$LOG_FILE"
    "$@" >> "$LOG_FILE" 2>&1 &
    spinner $! "$label"
}

abort() {
    echo ""
    error "$1"
    info "See $LOG_FILE for details."
    tail -10 "$LOG_FILE" 2>/dev/null | while IFS= read -r l; do echo -e "  ${GRAY_DARK}│${RESET} ${DIM}${l}${RESET}"; done
    exit 1
}

trap 'abort "Installation failed at line $LINENO"' ERR
> "$LOG_FILE"
[[ $EUID -ne 0 ]] && { error "Run as root"; exit 1; }

# ── Gather configuration ──────────────────────────────────────
banner "Installer v1.0.0"

step "Panel configuration"

APP_URL=$(ask "Panel domain" "https://panel.example.com")
APP_PORT=$(ask "Nginx listen port" "80")
APP_SECRET=$(openssl rand -hex 32)

step "Database"
DB_CHOICE=$(ask_choice "Database engine" "SQLite (recommended, zero setup)" "MySQL / MariaDB")
if [[ "$DB_CHOICE" == "2" ]]; then
    DB_CONN="mysql"
    DB_HOST=$(ask "DB host" "127.0.0.1")
    DB_PORT=$(ask "DB port" "3306")
    DB_NAME=$(ask "DB name" "forge")
    DB_USER=$(ask "DB username" "forge")
    DB_PASS=$(ask_secret "DB password")
else
    DB_CONN="sqlite"
    DB_HOST=""; DB_PORT=""; DB_NAME="database/forge.db"; DB_USER=""; DB_PASS=""
fi

step "Admin account"
ADMIN_NAME=$(ask "Admin name" "Admin")
ADMIN_EMAIL=$(ask "Admin email")
ADMIN_PASS=$(ask_secret "Admin password (min 8 chars)")
while [[ ${#ADMIN_PASS} -lt 8 ]]; do
    warn "Password too short"; ADMIN_PASS=$(ask_secret "Admin password (min 8 chars)")
done

step "Wings / Pterodactyl"
WINGS_ENABLED=false
if ask_yn "Connect to Wings (Pterodactyl/Pelican)?"; then
    WINGS_ENABLED=true
fi

step "Skyportd"
SKYPORT_ENABLED=false
SKYPORT_URL=""; SKYPORT_KEY=""
if ask_yn "Connect to Skyportd?" "n"; then
    SKYPORT_ENABLED=true
    SKYPORT_URL=$(ask "Skyportd panel URL")
    SKYPORT_KEY=$(ask "Skyportd API key")
fi

step "Discord OAuth"
DISCORD_ENABLED=false
DISCORD_CLIENT_ID=""; DISCORD_CLIENT_SECRET=""; DISCORD_BOT_TOKEN=""
if ask_yn "Enable Discord OAuth?"; then
    DISCORD_ENABLED=true
    DISCORD_CLIENT_ID=$(ask "Discord Client ID")
    DISCORD_CLIENT_SECRET=$(ask_secret "Discord Client Secret")
    DISCORD_BOT_TOKEN=$(ask_secret "Discord Bot Token (for DM notifications)")
fi

step "Stripe payments"
STRIPE_ENABLED=false
STRIPE_KEY=""; STRIPE_SECRET=""; STRIPE_WEBHOOK=""
if ask_yn "Enable Stripe?" "n"; then
    STRIPE_ENABLED=true
    STRIPE_KEY=$(ask "Stripe Publishable Key")
    STRIPE_SECRET=$(ask_secret "Stripe Secret Key")
    STRIPE_WEBHOOK=$(ask_secret "Stripe Webhook Secret")
fi

step "UPI payments"
UPI_VPA=$(ask "Your UPI ID" "abcd@fam")
UPI_NAME=$(ask "UPI display name" "Forge Panel")

step "Renewal system"
RENEWAL_ENABLED=false
RENEWAL_PERIOD="monthly"
RENEWAL_CUSTOM_DAYS=30
if ask_yn "Enable server renewals?"; then
    RENEWAL_ENABLED=true
    P=$(ask_choice "Renewal period" "Daily" "Weekly" "Monthly" "Custom (specify days)")
    case "$P" in
        1) RENEWAL_PERIOD="daily" ;;
        2) RENEWAL_PERIOD="weekly" ;;
        3) RENEWAL_PERIOD="monthly" ;;
        4) RENEWAL_PERIOD="custom"; RENEWAL_CUSTOM_DAYS=$(ask "Custom period in days" "30") ;;
    esac
fi

step "Cloudflare Subdomains"
CF_ENABLED=false
CF_API_TOKEN=""; CF_ZONE_ID=""; CF_DOMAIN=""
if ask_yn "Enable Cloudflare subdomains?" "n"; then
    CF_ENABLED=true
    CF_API_TOKEN=$(ask_secret "Cloudflare API Token")
    CF_ZONE_ID=$(ask "Zone ID")
    CF_DOMAIN=$(ask "Domain (e.g. example.com)")
fi

step "Discord webhook logging"
DISCORD_LOG_WEBHOOK=""
if ask_yn "Enable Discord webhook logs?" "n"; then
    DISCORD_LOG_WEBHOOK=$(ask "Webhook URL")
fi

step "Starter server on signup"
STARTER_ENABLED=false
if ask_yn "Give new users a free starter server?" "n"; then
    STARTER_ENABLED=true
fi

# ── Summary ────────────────────────────────────────────────────
step "Installation summary"
info "URL:       $APP_URL"
info "Database:  $DB_CONN"
info "Admin:     $ADMIN_EMAIL"
info "Wings:     $WINGS_ENABLED"
info "Skyportd:  $SKYPORT_ENABLED"
info "Discord:   $DISCORD_ENABLED"
info "Stripe:    $STRIPE_ENABLED"
info "UPI:       $UPI_VPA"
info "Renewal:   $RENEWAL_ENABLED ($RENEWAL_PERIOD)"
echo ""
ask_yn "Begin installation?" || { info "Cancelled."; exit 0; }

# ── System packages ────────────────────────────────────────────
step "System dependencies"

install_base() {
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y curl gnupg2 ca-certificates lsb-release unzip git nginx sqlite3 \
        software-properties-common build-essential zip
}
run_step "Installing base packages" install_base

install_php() {
    source /etc/os-release
    if [[ "$ID" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php
    else
        curl -fsSL https://packages.sury.org/php/apt.gpg | gpg --dearmor --yes -o /usr/share/keyrings/sury-php.gpg
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] https://packages.sury.org/php/ $(lsb_release -sc) main" \
            > /etc/apt/sources.list.d/sury-php.list
    fi
    apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        php8.4-cli php8.4-common php8.4-curl php8.4-mbstring \
        php8.4-xml php8.4-zip php8.4-bcmath php8.4-sqlite3 \
        php8.4-mysql php8.4-swoole php8.4-readline php8.4-gd \
        php8.4-intl php8.4-pdo
}
run_step "Installing PHP 8.4 + Swoole" install_php

install_composer() {
    command -v composer &>/dev/null && return
    local sig; sig=$(curl -fsSL --retry 3 https://composer.github.io/installer.sig)
    curl -fsSL --retry 3 https://getcomposer.org/installer -o /tmp/composer-setup.php
    php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
    rm -f /tmp/composer-setup.php
}
run_step "Installing Composer" install_composer

install_bun() {
    command -v bun &>/dev/null && return
    curl -fsSL https://bun.sh/install | bash
    [[ -f "$HOME/.bun/bin/bun" ]] && ln -sf "$HOME/.bun/bin/bun" /usr/local/bin/bun
}
run_step "Installing Bun" install_bun
export PATH="/usr/local/bin:$HOME/.bun/bin:$PATH"

# ── Copy panel ─────────────────────────────────────────────────
step "Setting up Forge Panel"

copy_panel() {
    [[ ! -d "$PANEL_DIR" ]] && { echo "panel/ directory not found"; exit 1; }
    [[ -d "$INSTALL_DIR" ]] && rm -rf "$INSTALL_DIR"
    cp -r "$PANEL_DIR" "$INSTALL_DIR"
    [[ ! -f "$INSTALL_DIR/artisan" ]] && { echo "artisan not found after copy"; exit 1; }
}
run_step "Copying panel source" copy_panel

# ── Write .env ─────────────────────────────────────────────────
write_env() {
    cd "$INSTALL_DIR"
    cp .env.example .env
    php artisan key:generate --no-interaction --force

    cat >> .env << ENVEOF

# ── Forge Panel ───────────────────────────────────────────────
APP_NAME="Forge Panel"
APP_URL=${APP_URL}
FORGE_LOGO_URL=https://i.postimg.cc/K8ZkkhM9/file-000000001d5c72089d1c7d0792db739d.png
OCTANE_SERVER=swoole
TRUSTED_PROXIES=*
APP_VERSION=1.0.0-alpha2

# Database
DB_CONNECTION=${DB_CONN}
DB_HOST=${DB_HOST}
DB_PORT=${DB_PORT}
DB_DATABASE=${DB_NAME}
DB_USERNAME=${DB_USER}
DB_PASSWORD=${DB_PASS}

# Discord
DISCORD_CLIENT_ID=${DISCORD_CLIENT_ID}
DISCORD_CLIENT_SECRET=${DISCORD_CLIENT_SECRET}
DISCORD_BOT_TOKEN=${DISCORD_BOT_TOKEN}
DISCORD_REDIRECT_URI=${APP_URL}/auth/discord/callback
DISCORD_LOG_WEBHOOK=${DISCORD_LOG_WEBHOOK}
DISCORD_SIGNUP_BONUS=100

# Stripe
STRIPE_KEY=${STRIPE_KEY}
STRIPE_SECRET=${STRIPE_SECRET}
STRIPE_WEBHOOK_SECRET=${STRIPE_WEBHOOK}

# UPI
UPI_VPA=${UPI_VPA}
UPI_NAME=${UPI_NAME}

# Coins
COINS_PER_INR=10
COINS_PER_USD=100

# Daily
DAILY_BASE_COINS=25
DAILY_STREAK_7_MULT=1.5
DAILY_STREAK_14_MULT=2.0
DAILY_STREAK_30_MULT=3.0

# Renewal
RENEWAL_ENABLED=${RENEWAL_ENABLED}
RENEWAL_PERIOD=${RENEWAL_PERIOD}
RENEWAL_CUSTOM_DAYS=${RENEWAL_CUSTOM_DAYS}
RENEWAL_WARNING_DAYS=3
RENEWAL_GRACE_DAYS=7

# Referral
REFERRAL_ENABLED=true
REFERRAL_REFERRER_COINS=200
REFERRAL_REFEREE_COINS=100

# Shop
SHOP_RAM_COIN_COST=10
SHOP_DISK_COIN_COST=5
SHOP_CPU_COIN_COST=20
SHOP_SERVER_COIN_COST=500

# Cloudflare
CF_ENABLED=${CF_ENABLED}
CF_API_TOKEN=${CF_API_TOKEN}
CF_ZONE_ID=${CF_ZONE_ID}
CF_DOMAIN=${CF_DOMAIN}

# Wings / Skyportd
WINGS_ENABLED=${WINGS_ENABLED}
SKYPORT_ENABLED=${SKYPORT_ENABLED}
SKYPORT_URL=${SKYPORT_URL}
SKYPORT_KEY=${SKYPORT_KEY}

# Starter server
STARTER_SERVER_ENABLED=${STARTER_ENABLED}
STARTER_SERVER_RAM=512
STARTER_SERVER_DISK=2048
STARTER_SERVER_CPU=50
ENVEOF

    [[ "$DB_CONN" == "sqlite" ]] && touch database/forge.db
}
run_step "Writing .env configuration" write_env

# ── Install deps & build ────────────────────────────────────────
install_deps() {
    cd "$INSTALL_DIR"
    COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --no-interaction --optimize-autoloader --no-progress
}
build_frontend() {
    cd "$INSTALL_DIR"
    bun install 2>/dev/null || bun install
    bun run build:ssr
}
run_step "Installing PHP dependencies" install_deps
run_step "Building frontend (React + Vite)" build_frontend

# ── Migrate & seed ─────────────────────────────────────────────
run_migrations() {
    cd "$INSTALL_DIR"
    php artisan migrate --force --no-interaction
}
create_admin() {
    cd "$INSTALL_DIR"
    php artisan user:create \
        --name="$ADMIN_NAME" \
        --email="$ADMIN_EMAIL" \
        --password="$ADMIN_PASS" \
        --admin \
        --no-interaction 2>/dev/null || true
    # Also give admin extra coins/resources
    php artisan tinker --execute="
\$u = \\App\\Models\\User::where('email','$ADMIN_EMAIL')->first();
if(\$u){
    \$u->coins = 99999;
    \$u->ram_limit = 32768;
    \$u->disk_limit = 102400;
    \$u->cpu_limit = 1000;
    \$u->server_limit = 99;
    \$u->referral_code = strtoupper(substr(md5('$ADMIN_EMAIL'),0,8));
    \$u->save();
    echo 'Admin resources set';
}" 2>/dev/null || true
}
run_step "Running database migrations" run_migrations || abort "Migrations failed"
run_step "Creating admin account" create_admin

# ── Permissions ─────────────────────────────────────────────────
set_permissions() {
    cd "$INSTALL_DIR"
    chown -R www-data:www-data .
    chmod -R 755 storage bootstrap/cache
    [[ "$DB_CONN" == "sqlite" ]] && { chmod 664 database/forge.db; chmod 775 database; }
}
run_step "Setting permissions" set_permissions

# ── SSL / Cloudflare Tunnel setup ────────────────────────────
step "Web & SSL configuration"

USE_SSL=false
USE_CLOUDFLARE=false
CF_TUNNEL_TOKEN=""

if ask_yn "Are you using SSL (HTTPS with Let's Encrypt)?"; then
    USE_SSL=true
    FQDN=$(ask "Your domain name (e.g. panel.example.com)" "panel.example.com")
    APP_URL="https://${FQDN}"
else
    if ask_yn "Are you using Cloudflare Tunnel?"; then
        USE_CLOUDFLARE=true
        APP_URL_PROTO="https"
        info "Cloudflare Tunnel handles HTTPS externally — panel will run on plain HTTP internally."

        if ask_yn "Install and configure cloudflared now?"; then
            # Install cloudflared
            install_cloudflared() {
                curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
                    | gpg --dearmor --yes -o /usr/share/keyrings/cloudflare-main.gpg
                echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] \
                    https://pkg.cloudflare.com/cloudflared $(lsb_release -cs) main" \
                    | tee /etc/apt/sources.list.d/cloudflared.list
                apt-get update -y
                apt-get install -y cloudflared
            }
            run_step "Installing cloudflared" install_cloudflared

            echo ""
            info "To connect cloudflared to your Cloudflare account, run:"
            info "  cloudflared tunnel login"
            info "Then create a tunnel:"
            info "  cloudflared tunnel create forge-panel"
            info ""
            CF_TUNNEL_TOKEN=$(ask "Paste your Cloudflare Tunnel token (from dashboard → Tunnels → your tunnel → Configure)" "")

            if [[ -n "$CF_TUNNEL_TOKEN" ]]; then
                setup_cloudflared_service() {
                    mkdir -p /etc/cloudflared

                    cat > /etc/cloudflared/config.yml << CFCFG
tunnel: forge-panel
credentials-file: /root/.cloudflared/forge-panel.json

ingress:
  - hostname: ${APP_URL#https://}
    service: http://127.0.0.1:${APP_PORT}
    originRequest:
      noTLSVerify: true
  - service: http_status:404
CFCFG

                    cloudflared service install "$CF_TUNNEL_TOKEN" 2>/dev/null || true
                    systemctl enable cloudflared 2>/dev/null || true
                    systemctl restart cloudflared 2>/dev/null || true
                }
                run_step "Configuring cloudflared service" setup_cloudflared_service
            else
                warn "No token provided — skipping cloudflared service setup."
                warn "Run 'cloudflared service install <token>' manually after install."
            fi
        else
            info "Skipping cloudflared installation."
            info "Make sure your tunnel points to: http://127.0.0.1:${APP_PORT}"
        fi
    else
        info "Running without SSL or Cloudflare — plain HTTP on port ${APP_PORT}."
    fi
fi

# ── Nginx ───────────────────────────────────────────────────────
configure_nginx() {
    if $USE_SSL; then
        # Install Certbot and get cert
        DEBIAN_FRONTEND=noninteractive apt-get install -y certbot python3-certbot-nginx >> "$LOG_FILE" 2>&1
        systemctl stop nginx 2>/dev/null || true
        certbot certonly --standalone -d "$FQDN" \
            --non-interactive --agree-tos --register-unsafely-without-email >> "$LOG_FILE" 2>&1 \
            || abort "Let's Encrypt certificate failed. Make sure $FQDN points to this server and port 80 is open."
        systemctl start nginx 2>/dev/null || true

        cat > /etc/nginx/sites-available/forge-panel.conf << NGINX
server {
    listen 80;
    server_name ${FQDN};
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl;
    server_name ${FQDN};
    ssl_certificate /etc/letsencrypt/live/${FQDN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${FQDN}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_buffering off;
        proxy_read_timeout 300s;
    }
}
NGINX
    else
        # Plain HTTP (Cloudflare tunnel or local)
        cat > /etc/nginx/sites-available/forge-panel.conf << NGINX
server {
    listen ${APP_PORT};
    server_name _;
    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_buffering off;
        proxy_read_timeout 300s;
    }
}
NGINX
    fi

    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/forge-panel.conf /etc/nginx/sites-enabled/forge-panel.conf
    nginx -t && systemctl restart nginx
}
run_step "Configuring Nginx" configure_nginx

# ── Fix APP_URL / ASSET_URL in .env (prevents broken UI) ─────
fix_env_urls() {
    cd "$INSTALL_DIR"

    # Correct APP_URL and ASSET_URL
    sed -i "s|APP_URL=.*|APP_URL=${APP_URL}|" .env
    grep -q "^ASSET_URL=" .env \
        && sed -i "s|ASSET_URL=.*|ASSET_URL=${APP_URL}|" .env \
        || echo "ASSET_URL=${APP_URL}" >> .env

    # TRUSTED_PROXIES must be set for Cloudflare / reverse proxy
    grep -q "^TRUSTED_PROXIES=" .env \
        && sed -i "s|TRUSTED_PROXIES=.*|TRUSTED_PROXIES=*|" .env \
        || echo "TRUSTED_PROXIES=*" >> .env

    # APP_VERSION must match daemon version
    grep -q "^APP_VERSION=" .env \
        && sed -i "s|APP_VERSION=.*|APP_VERSION=1.0.0-alpha2|" .env \
        || echo "APP_VERSION=1.0.0-alpha2" >> .env

    # Clear all caches and restart services
    php artisan optimize:clear
    php artisan config:clear
    php artisan cache:clear
    php artisan route:clear
    php artisan view:clear
}
run_step "Fixing APP_URL, ASSET_URL and clearing caches" fix_env_urls

# ── Systemd services ─────────────────────────────────────────────
create_services() {
    cat > /etc/systemd/system/forge-panel.service << SVC
[Unit]
Description=Forge Panel (Octane/Swoole)
After=network.target
[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan octane:start --server=swoole --host=127.0.0.1 --port=8000
ExecReload=/usr/bin/php artisan octane:reload
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/forge-queue.service << SVC
[Unit]
Description=Forge Panel Queue
After=network.target forge-panel.service
[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan queue:work --tries=3 --timeout=60
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/forge-ssr.service << SVC
[Unit]
Description=Forge Panel SSR
After=network.target
[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan inertia:start-ssr
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/forge-scheduler.service << SVC
[Unit]
Description=Forge Panel Scheduler
After=network.target
[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan schedule:work
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
SVC

    systemctl daemon-reload
    systemctl enable forge-panel forge-queue forge-ssr forge-scheduler
    systemctl start forge-panel forge-queue forge-ssr forge-scheduler
}
run_step "Creating systemd services" create_services

# ── Final APP_URL fix + restart after services are up ─────────
final_fix() {
    sleep 3
    cd "$INSTALL_DIR"

    # One final guarantee that APP_URL and ASSET_URL are correct
    sed -i "s|APP_URL=.*|APP_URL=${APP_URL}|" .env
    grep -q "^ASSET_URL=" .env \
        && sed -i "s|ASSET_URL=.*|ASSET_URL=${APP_URL}|" .env \
        || echo "ASSET_URL=${APP_URL}" >> .env

    php artisan optimize:clear >> /dev/null 2>&1 || true
    php artisan config:clear   >> /dev/null 2>&1 || true

    systemctl restart forge-panel forge-ssr forge-queue 2>/dev/null || true
}
run_step "Final URL fix + service restart" final_fix

# ── Done ────────────────────────────────────────────────────────
trap - ERR

step "Installation complete!"
echo ""
echo -e "  ${BLUE}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${WHITE}⚒  Forge Panel is live!${RESET}                         ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}URL:${RESET}    ${BLUE}${APP_URL}${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}Admin:${RESET}  ${BLUE}${ADMIN_EMAIL}${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}DB:${RESET}     ${BLUE}${DB_CONN}${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}If using Cloudflare Tunnel:${RESET}                     ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}     ${DIM}point tunnel → http://localhost:${APP_PORT}${RESET}        ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}Logs:${RESET}   ${DIM}journalctl -u forge-panel -f${RESET}        ${BLUE}║${RESET}"
echo -e "  ${BLUE}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""
