#!/usr/bin/env bash
set -euo pipefail

# ──────────────────────────────────────────────────────────────
#  Forge Panel Installer v1.0.1
#  Skyport base + Discord OAuth, billing, daily rewards,
#  referrals, redeem codes, tickets, renewals, and more.
# ──────────────────────────────────────────────────────────────

INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_SRC="$INSTALLER_DIR/panel"
INSTALL_DIR="/var/www/skyport"
PANEL_USER="www-data"
PANEL_GROUP="www-data"

# ── Source ui.sh (Skyport's UI helpers, $2 bug already fixed) ─
if [[ ! -f "$INSTALLER_DIR/lib/ui.sh" ]]; then
    echo "ERROR: lib/ui.sh not found. Re-extract the zip."
    exit 1
fi
source "$INSTALLER_DIR/lib/ui.sh"

# ── Override colors to white/grey theme ───────────────────────
ORANGE='\033[1;37m'          # white  (was orange)
ORANGE_DARK='\033[38;2;180;180;180m'  # light grey (was orange-dark)
GRAY='\033[38;2;160;160;160m'         # grey
GRAY_DARK='\033[38;2;100;100;100m'    # dark grey
WHITE='\033[1;37m'
DIM='\033[2m'
RESET='\033[0m'
RED='\033[38;2;220;50;50m'
GREEN='\033[38;2;80;200;120m'

# ── Verify panel source exists ────────────────────────────────
if [[ ! -f "$PANEL_SRC/artisan" ]]; then
    error "panel/ directory not found or incomplete."
    error "Make sure you extracted the full forge-panel zip and"
    error "are running install.sh from inside forge-skyport/."
    exit 1
fi

trap 'abort_with_log "Installation failed unexpectedly at line $LINENO."' ERR
> "$LOG_FILE"

# ═════════════════════════════════════════════════════════════
#  PHASE 1 — GATHER CONFIG
# ═════════════════════════════════════════════════════════════

banner "Forge Panel Installer"

check_root
check_os
check_disk_space 3000 "$INSTALL_DIR"
check_memory

# ── Existing install ──────────────────────────────────────────
if [[ -f "$INSTALL_DIR/artisan" ]]; then
    warn "An existing installation was found at $INSTALL_DIR."
    echo ""
    if ask_yes_no "Remove it and start fresh?" "n"; then
        systemctl stop skyport-panel skyport-queue skyport-ssr 2>/dev/null || true
        rm -rf "$INSTALL_DIR"
        success "Removed existing installation."
    else
        error "Installation cancelled."
        exit 1
    fi
fi

# ── Web / SSL / Cloudflare ────────────────────────────────────
step "Web server configuration"

USE_SSL=false
USE_CLOUDFLARE=false
FQDN=""
LISTEN_PORT=""
APP_URL=""

if ask_yes_no "Set up with a domain name (with SSL)?" "y"; then
    USE_SSL=true
    FQDN=$(ask "Domain name" "panel.example.com")
    APP_URL="https://${FQDN}"
    success "SSL enabled for ${FQDN}"
else
    LISTEN_PORT=$(ask "Port to listen on" "8080")
    while ! [[ "$LISTEN_PORT" =~ ^[0-9]+$ ]] || \
          [[ "$LISTEN_PORT" -lt 1 || "$LISTEN_PORT" -gt 65535 ]]; do
        warn "Invalid port."
        LISTEN_PORT=$(ask "Port to listen on" "8080")
    done
    info "Nginx will listen on port ${LISTEN_PORT}."
    echo ""

    if ask_yes_no "Are you using a Cloudflare Tunnel?" "n"; then
        USE_CLOUDFLARE=true
        FQDN=$(ask "Your panel domain (e.g. panel.example.com)")
        APP_URL="https://${FQDN}"
        info "Cloudflare Tunnel: https://${FQDN} → http://localhost:${LISTEN_PORT}"
        echo ""

        if ask_yes_no "Install and configure Cloudflare Tunnel (cloudflared) now?" "y"; then
            echo ""
            info "Running Cloudflare Tunnel installer script..."
            info "You will be prompted for your tunnel token."
            echo ""
            bash <(curl -fsSL https://raw.githubusercontent.com/JishnuTheGamer/Vps/refs/heads/main/cd/cloudflare.sh)
            success "Cloudflare Tunnel configured."
        else
            echo ""
            warn "Skipping cloudflared install."
            info "Manually point your tunnel to: http://localhost:${LISTEN_PORT}"
            info "Command: sudo cloudflared service install <YOUR_TOKEN>"
            echo ""
        fi
    else
        APP_URL="http://$(hostname -I | awk '{print $1}' 2>/dev/null || echo 'localhost'):${LISTEN_PORT}"
        info "Plain HTTP on port ${LISTEN_PORT}"
    fi
fi

# ── Database ──────────────────────────────────────────────────
step "Database"

DB_CHOICE=$(ask_choice "Database engine" \
    "SQLite (recommended — zero setup)" \
    "MySQL / MariaDB")

if [[ "$DB_CHOICE" == "2" ]]; then
    DB_CONNECTION="mysql"
    DB_HOST=$(ask "Database host" "127.0.0.1")
    DB_PORT=$(ask "Database port" "3306")
    DB_DATABASE=$(ask "Database name" "skyport")
    DB_USERNAME=$(ask "Database username" "skyport")
    DB_PASSWORD=$(ask_password "Database password")
else
    DB_CONNECTION="sqlite"
    DB_HOST="" DB_PORT="" DB_DATABASE="" DB_USERNAME="" DB_PASSWORD=""
fi
success "Database: $DB_CONNECTION"

# ── Admin account ─────────────────────────────────────────────
step "Administrator account"

ADMIN_NAME=$(ask "Admin name" "Admin")
ADMIN_EMAIL=$(ask "Admin email" "admin@example.com")
while [[ ! "$ADMIN_EMAIL" =~ ^[^@]+@[^@]+\.[^@]+$ ]]; do
    warn "Enter a valid email."
    ADMIN_EMAIL=$(ask "Admin email")
done
ADMIN_PASSWORD=$(ask_password "Admin password (min 8 chars)")
while [[ ${#ADMIN_PASSWORD} -lt 8 ]]; do
    warn "Password must be at least 8 characters."
    ADMIN_PASSWORD=$(ask_password "Admin password (min 8 chars)")
done
success "Admin: $ADMIN_EMAIL"

# ── Discord OAuth ─────────────────────────────────────────────
step "Discord OAuth (optional)"

DISCORD_CLIENT_ID=""
DISCORD_CLIENT_SECRET=""
DISCORD_BOT_TOKEN=""
DISCORD_LOG_WEBHOOK=""

if ask_yes_no "Enable Discord OAuth (login with Discord)?" "n"; then
    DISCORD_CLIENT_ID=$(ask "Discord Client ID")
    DISCORD_CLIENT_SECRET=$(ask_password "Discord Client Secret")
    if ask_yes_no "Enable Discord Bot for DM notifications + webhook logs?" "n"; then
        DISCORD_BOT_TOKEN=$(ask_password "Discord Bot Token")
        DISCORD_LOG_WEBHOOK=$(ask "Discord Webhook URL for logs (leave blank to skip)" "")
    fi
    success "Discord OAuth: enabled"
else
    success "Discord OAuth: skipped"
fi

# ── Stripe ────────────────────────────────────────────────────
step "Stripe payments (optional)"

STRIPE_KEY=""
STRIPE_SECRET=""
STRIPE_WEBHOOK_SECRET=""

if ask_yes_no "Enable Stripe card payments?" "n"; then
    STRIPE_KEY=$(ask "Stripe Publishable Key (pk_...)")
    STRIPE_SECRET=$(ask_password "Stripe Secret Key (sk_...)")
    STRIPE_WEBHOOK_SECRET=$(ask_password "Stripe Webhook Secret (whsec_...)")
    success "Stripe: enabled"
else
    success "Stripe: skipped"
fi

# ── UPI ───────────────────────────────────────────────────────
step "UPI payments"
UPI_VPA=$(ask "Your UPI ID" "abcd@fam")
UPI_NAME=$(ask "UPI display name" "Forge Panel")

# ── Renewal ───────────────────────────────────────────────────
step "Server renewal system (optional)"

RENEWAL_ENABLED=false
RENEWAL_PERIOD="monthly"
RENEWAL_CUSTOM_DAYS=30

if ask_yes_no "Enable server renewals (auto-suspend on expiry)?" "n"; then
    RENEWAL_ENABLED=true
    P=$(ask_choice "Renewal period" \
        "Daily (1 day)" \
        "Weekly (7 days)" \
        "Monthly (30 days)" \
        "Custom (specify days)")
    case "$P" in
        1) RENEWAL_PERIOD="daily" ;;
        2) RENEWAL_PERIOD="weekly" ;;
        3) RENEWAL_PERIOD="monthly" ;;
        4) RENEWAL_PERIOD="custom"
           RENEWAL_CUSTOM_DAYS=$(ask "Days per period" "30") ;;
    esac
    success "Renewals: ${RENEWAL_PERIOD}"
else
    success "Renewals: disabled"
fi

# ── Cloudflare Subdomains ─────────────────────────────────────
step "Cloudflare Subdomain management (optional)"

CF_SUB_ENABLED=false
CF_API_TOKEN=""
CF_ZONE_ID=""
CF_DOMAIN_NAME=""

if ask_yes_no "Enable per-server Cloudflare subdomains?" "n"; then
    CF_SUB_ENABLED=true
    CF_API_TOKEN=$(ask_password "Cloudflare API Token")
    CF_ZONE_ID=$(ask "Cloudflare Zone ID")
    CF_DOMAIN_NAME=$(ask "Base domain (e.g. example.com)")
    success "CF subdomains: ${CF_DOMAIN_NAME}"
else
    success "CF subdomains: skipped"
fi

# ── Telemetry ─────────────────────────────────────────────────
step "Telemetry"
TELEMETRY_ENABLED=false
if ask_yes_no "Enable anonymous telemetry?" "y"; then
    TELEMETRY_ENABLED=true
fi

# ── Summary ───────────────────────────────────────────────────
step "Installation summary"
info "URL:        ${APP_URL}"
info "Database:   ${DB_CONNECTION}"
info "Admin:      ${ADMIN_EMAIL}"
info "Discord:    ${DISCORD_CLIENT_ID:+enabled}${DISCORD_CLIENT_ID:-skipped}"
info "Stripe:     ${STRIPE_KEY:+enabled}${STRIPE_KEY:-skipped}"
info "UPI:        ${UPI_VPA}"
info "Renewals:   $(if $RENEWAL_ENABLED; then echo "enabled (${RENEWAL_PERIOD})"; else echo "disabled"; fi)"
info "Install to: ${INSTALL_DIR}"
echo ""
ask_yes_no "Begin installation?" "y" || { info "Cancelled."; exit 0; }

# ═════════════════════════════════════════════════════════════
#  PHASE 2 — SYSTEM PACKAGES
# ═════════════════════════════════════════════════════════════
step "Installing system dependencies"

run_step "Updating package lists" apt-get update -y

install_base() {
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        curl gnupg2 ca-certificates lsb-release unzip git \
        nginx sqlite3 software-properties-common build-essential zip
}
run_step "Base packages" install_base

install_php() {
    source /etc/os-release
    if [[ "$ID" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php
    else
        curl -fsSL https://packages.sury.org/php/apt.gpg \
            | gpg --dearmor --yes -o /usr/share/keyrings/sury-php.gpg
        local codename; codename=$(lsb_release -sc)
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] \
            https://packages.sury.org/php/ ${codename} main" \
            > /etc/apt/sources.list.d/sury-php.list
    fi
    apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        php8.4-cli php8.4-common php8.4-curl php8.4-mbstring \
        php8.4-xml php8.4-zip php8.4-bcmath php8.4-sqlite3 \
        php8.4-mysql php8.4-swoole php8.4-readline php8.4-gd php8.4-intl
}
run_step "PHP 8.4 + Swoole + sqlite3" install_php

php -v >> "$LOG_FILE" 2>&1 || abort_with_log "PHP 8.4 installation failed."

install_composer() {
    check_command composer && return 0
    local sig actual
    sig=$(curl -fsSL --retry 3 https://composer.github.io/installer.sig)
    curl -fsSL --retry 3 https://getcomposer.org/installer -o /tmp/composer-setup.php
    actual=$(php -r "echo hash_file('sha384', '/tmp/composer-setup.php');")
    [[ "$sig" == "$actual" ]] || { echo "Composer signature mismatch" >&2; exit 1; }
    php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
    rm -f /tmp/composer-setup.php
}
run_step "Composer" install_composer

install_bun() {
    check_command bun && return 0
    curl -fsSL --retry 3 https://bun.sh/install | bash
    [[ -f "$HOME/.bun/bin/bun" ]] && ln -sf "$HOME/.bun/bin/bun" /usr/local/bin/bun
}
run_step "Bun (JS runtime)" install_bun
export PATH="/usr/local/bin:$HOME/.bun/bin:$PATH"
check_command bun || abort_with_log "Bun installation failed."

install_node() {
    if check_command node; then
        local v; v=$(node -v 2>/dev/null | grep -oP '^v\K\d+' || echo "0")
        [[ "$v" -ge 22 ]] && return 0
    fi
    curl -fsSL --retry 3 https://deb.nodesource.com/setup_22.x | bash -
    DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs
}
run_step "Node.js 22" install_node

# ── MySQL (if chosen) ─────────────────────────────────────────
if [[ "$DB_CONNECTION" == "mysql" ]]; then
    install_mysql() {
        DEBIAN_FRONTEND=noninteractive apt-get install -y mariadb-server
        systemctl enable --now mariadb
        mysql -e "CREATE DATABASE IF NOT EXISTS \`${DB_DATABASE}\`;"
        mysql -e "CREATE USER IF NOT EXISTS '${DB_USERNAME}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';"
        mysql -e "GRANT ALL ON \`${DB_DATABASE}\`.* TO '${DB_USERNAME}'@'localhost'; FLUSH PRIVILEGES;"
    }
    run_step "MariaDB setup" install_mysql
fi

# ── Certbot (if SSL) ──────────────────────────────────────────
if $USE_SSL; then
    run_step "Certbot" \
        apt-get install -y certbot python3-certbot-nginx
fi

# ═════════════════════════════════════════════════════════════
#  PHASE 3 — COPY FORGE PANEL SOURCE
# ═════════════════════════════════════════════════════════════
step "Setting up Forge Panel"

copy_panel() {
    [[ -d "$INSTALL_DIR" ]] && rm -rf "$INSTALL_DIR"
    cp -r "$PANEL_SRC" "$INSTALL_DIR"
    [[ -f "$INSTALL_DIR/artisan" ]] || { echo "artisan not found after copy"; exit 1; }
}
run_step "Copying Forge Panel source" copy_panel

# ═════════════════════════════════════════════════════════════
#  PHASE 4 — ENVIRONMENT
# ═════════════════════════════════════════════════════════════
step "Configuring application"

configure_env() {
    cd "$INSTALL_DIR"
    cp .env.example .env
    php artisan key:generate --no-interaction --force

    # environment:setup if it exists
    if php artisan list 2>/dev/null | grep -q "environment:setup"; then
        local env_args=(--url="$APP_URL" --db-connection="$DB_CONNECTION")
        if [[ "$DB_CONNECTION" == "mysql" ]]; then
            env_args+=(
                --db-host="$DB_HOST"
                --db-port="$DB_PORT"
                --db-database="$DB_DATABASE"
                --db-username="$DB_USERNAME"
                --db-password="$DB_PASSWORD"
            )
        fi
        php artisan environment:setup "${env_args[@]}" --no-interaction
    fi

    [[ "$DB_CONNECTION" == "sqlite" ]] && touch database/database.sqlite

    # Reliable key setter — replaces existing or appends
    set_env() {
        local k="$1" v="$2"
        if grep -q "^${k}=" .env 2>/dev/null; then
            sed -i "s|^${k}=.*|${k}=${v}|" .env
        else
            echo "${k}=${v}" >> .env
        fi
    }

    # Core
    set_env APP_URL            "${APP_URL}"
    set_env ASSET_URL          "${APP_URL}"
    set_env TRUSTED_PROXIES    '*'
    set_env APP_VERSION        '1.0.0-alpha2'
    set_env OCTANE_SERVER      'swoole'
    set_env SKYPORT_TELEMETRY_ENABLED \
        "$(if $TELEMETRY_ENABLED; then echo true; else echo false; fi)"

    # Forge
    set_env FORGE_LOGO_URL \
        'https://i.postimg.cc/K8ZkkhM9/file-000000001d5c72089d1c7d0792db739d.png'

    # Discord
    set_env DISCORD_CLIENT_ID     "${DISCORD_CLIENT_ID}"
    set_env DISCORD_CLIENT_SECRET "${DISCORD_CLIENT_SECRET}"
    set_env DISCORD_BOT_TOKEN     "${DISCORD_BOT_TOKEN}"
    set_env DISCORD_REDIRECT_URI  "${APP_URL}/auth/discord/callback"
    set_env DISCORD_LOG_WEBHOOK   "${DISCORD_LOG_WEBHOOK}"
    set_env DISCORD_SIGNUP_BONUS  '100'

    # Stripe
    set_env STRIPE_KEY            "${STRIPE_KEY}"
    set_env STRIPE_SECRET         "${STRIPE_SECRET}"
    set_env STRIPE_WEBHOOK_SECRET "${STRIPE_WEBHOOK_SECRET}"

    # UPI
    set_env UPI_VPA  "${UPI_VPA}"
    set_env UPI_NAME "\"${UPI_NAME}\""

    # Coins
    set_env COINS_PER_INR '10'
    set_env COINS_PER_USD '100'

    # Daily
    set_env DAILY_BASE_COINS     '25'
    set_env DAILY_STREAK_7_MULT  '1.5'
    set_env DAILY_STREAK_14_MULT '2.0'
    set_env DAILY_STREAK_30_MULT '3.0'

    # Referral
    set_env REFERRAL_ENABLED        'true'
    set_env REFERRAL_REFERRER_COINS '200'
    set_env REFERRAL_REFEREE_COINS  '100'

    # Shop
    set_env SHOP_RAM_COIN_COST    '10'
    set_env SHOP_DISK_COIN_COST   '5'
    set_env SHOP_CPU_COIN_COST    '20'
    set_env SHOP_SERVER_COIN_COST '500'

    # Renewal
    set_env RENEWAL_ENABLED \
        "$(if $RENEWAL_ENABLED; then echo true; else echo false; fi)"
    set_env RENEWAL_PERIOD       "${RENEWAL_PERIOD}"
    set_env RENEWAL_CUSTOM_DAYS  "${RENEWAL_CUSTOM_DAYS}"
    set_env RENEWAL_WARNING_DAYS '3'
    set_env RENEWAL_GRACE_DAYS   '7'

    # Cloudflare subdomains
    set_env CF_ENABLED \
        "$(if $CF_SUB_ENABLED; then echo true; else echo false; fi)"
    set_env CF_API_TOKEN  "${CF_API_TOKEN}"
    set_env CF_ZONE_ID    "${CF_ZONE_ID}"
    set_env CF_DOMAIN     "${CF_DOMAIN_NAME}"

    # Default resources
    set_env DEFAULT_RAM     '2048'
    set_env DEFAULT_DISK    '5120'
    set_env DEFAULT_CPU     '100'
    set_env DEFAULT_SERVERS '1'
}
run_step "Configuring environment" configure_env

# ═════════════════════════════════════════════════════════════
#  PHASE 5 — DEPENDENCIES, MIGRATIONS, BUILD
# ═════════════════════════════════════════════════════════════
step "Installing application dependencies"

install_php_deps() {
    cd "$INSTALL_DIR"
    COMPOSER_ALLOW_SUPERUSER=1 composer install \
        --no-dev --no-interaction --optimize-autoloader --no-progress
}
install_js_deps() {
    cd "$INSTALL_DIR"
    bun install --frozen-lockfile 2>/dev/null || bun install
}
run_step "PHP dependencies" install_php_deps
run_step "JS dependencies"  install_js_deps

step "Configuring application"

run_migrations() {
    cd "$INSTALL_DIR"
    php artisan migrate --force --no-interaction
}
run_wayfinder() {
    cd "$INSTALL_DIR"
    php artisan wayfinder:generate --with-form --no-interaction 2>/dev/null || true
}
build_assets() {
    cd "$INSTALL_DIR"
    bun run build:ssr
}
create_admin() {
    cd "$INSTALL_DIR"
    php artisan user:create \
        --name="$ADMIN_NAME" \
        --email="$ADMIN_EMAIL" \
        --password="$ADMIN_PASSWORD" \
        --admin \
        --no-interaction
}

run_step "Running database migrations" run_migrations \
    || abort_with_log "Database migrations failed. Check your database configuration."
run_step "Generating route bindings" run_wayfinder
run_step "Building frontend assets" build_assets \
    || abort_with_log "Asset build failed."
run_step "Creating admin user" create_admin

# ═════════════════════════════════════════════════════════════
#  PHASE 6 — PERMISSIONS
# ═════════════════════════════════════════════════════════════
set_permissions() {
    cd "$INSTALL_DIR"
    chown -R "$PANEL_USER:$PANEL_GROUP" .
    chmod -R 755 storage bootstrap/cache
    if [[ "$DB_CONNECTION" == "sqlite" && -f database/database.sqlite ]]; then
        chown "$PANEL_USER:$PANEL_GROUP" database/database.sqlite database
        chmod 664 database/database.sqlite
        chmod 775 database
    fi
}
run_step "Setting permissions" set_permissions

# ═════════════════════════════════════════════════════════════
#  PHASE 7 — SSL CERTIFICATE
# ═════════════════════════════════════════════════════════════
if $USE_SSL; then
    step "Obtaining SSL certificate"
    obtain_cert() {
        systemctl stop nginx 2>/dev/null || true
        certbot certonly --standalone \
            -d "$FQDN" \
            --non-interactive \
            --agree-tos \
            --register-unsafely-without-email
        systemctl start nginx 2>/dev/null || true
    }
    run_step "Let's Encrypt certificate for ${FQDN}" obtain_cert \
        || abort_with_log "Certbot failed. Ensure ${FQDN} points here and port 80 is open."
fi

# ═════════════════════════════════════════════════════════════
#  PHASE 8 — NGINX
# ═════════════════════════════════════════════════════════════
step "Configuring Nginx"

configure_nginx() {
    local octane_port=8000

    if $USE_SSL; then
        cat > /etc/nginx/sites-available/skyport.conf << NGINX
server {
    listen 80;
    server_name ${FQDN};
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl http2;
    server_name ${FQDN};
    ssl_certificate     /etc/letsencrypt/live/${FQDN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${FQDN}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;
    location / {
        proxy_pass         http://127.0.0.1:${octane_port};
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Upgrade           \$http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_buffering    off;
        proxy_read_timeout 300s;
    }
}
NGINX
    else
        cat > /etc/nginx/sites-available/skyport.conf << NGINX
server {
    listen ${LISTEN_PORT};
    server_name _;
    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;
    location / {
        proxy_pass         http://127.0.0.1:${octane_port};
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Upgrade           \$http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_buffering    off;
        proxy_read_timeout 300s;
    }
}
NGINX
    fi

    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/skyport.conf \
           /etc/nginx/sites-enabled/skyport.conf
    nginx -t
    systemctl restart nginx
}
run_step "Nginx configuration" configure_nginx \
    || abort_with_log "Nginx configuration failed."

# ═════════════════════════════════════════════════════════════
#  PHASE 9 — SYSTEMD SERVICES
# ═════════════════════════════════════════════════════════════
step "Creating systemd services"

create_services() {
    cat > /etc/systemd/system/skyport-panel.service << SVC
[Unit]
Description=Skyport Panel (Octane/Swoole)
After=network.target
[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan octane:start --server=swoole --host=127.0.0.1 --port=8000
ExecReload=/usr/bin/php artisan octane:reload
Restart=always
RestartSec=5
StartLimitBurst=5
StartLimitIntervalSec=60
[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/skyport-queue.service << SVC
[Unit]
Description=Skyport Queue Worker
After=network.target skyport-panel.service
[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan queue:work --tries=3 --timeout=60
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/skyport-ssr.service << SVC
[Unit]
Description=Skyport Inertia SSR
After=network.target
[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan inertia:start-ssr
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/skyport-scheduler.service << SVC
[Unit]
Description=Skyport Scheduler (renewals etc)
After=network.target
[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan schedule:work
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
SVC

    systemctl daemon-reload
    systemctl enable  skyport-panel skyport-queue skyport-ssr skyport-scheduler
    systemctl restart skyport-panel skyport-queue skyport-ssr skyport-scheduler
}
run_step "Creating and starting services" create_services

sleep 3
FAILED=""
for svc in skyport-panel skyport-queue skyport-ssr; do
    systemctl is-active --quiet "$svc" || FAILED="$FAILED $svc"
done
[[ -n "$FAILED" ]] && warn "Some services still starting:$FAILED" \
                   || success "All services running"

# ═════════════════════════════════════════════════════════════
#  PHASE 10 — FINAL .env FIX (prevents broken UI)
# ═════════════════════════════════════════════════════════════
final_fix() {
    cd "$INSTALL_DIR"
    sed -i "s|APP_URL=.*|APP_URL=${APP_URL}|"     .env
    sed -i "s|ASSET_URL=.*|ASSET_URL=${APP_URL}|" .env 2>/dev/null \
        || echo "ASSET_URL=${APP_URL}" >> .env
    grep -q "^TRUSTED_PROXIES=" .env \
        && sed -i "s|TRUSTED_PROXIES=.*|TRUSTED_PROXIES=*|" .env \
        || echo "TRUSTED_PROXIES=*" >> .env
    grep -q "^APP_VERSION=" .env \
        && sed -i "s|APP_VERSION=.*|APP_VERSION=1.0.0-alpha2|" .env \
        || echo "APP_VERSION=1.0.0-alpha2" >> .env

    php artisan optimize:clear
    php artisan config:clear
    php artisan cache:clear

    systemctl restart skyport-panel skyport-ssr skyport-queue 2>/dev/null || true
}
run_step "Fixing APP_URL + clearing caches" final_fix

# ═════════════════════════════════════════════════════════════
#  DONE
# ═════════════════════════════════════════════════════════════
trap - ERR

step "Installation complete"

echo ""
echo -e "  ${WHITE}╭──────────────────────────────────────────────────────╮${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}   ${WHITE}⚒  Forge Panel is now running!${RESET}                    ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}   ${GRAY}URL:${RESET}   ${WHITE}${APP_URL}${RESET}"
echo -e "  ${WHITE}│${RESET}   ${GRAY}Admin:${RESET} ${WHITE}${ADMIN_EMAIL}${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"

if $USE_CLOUDFLARE; then
echo -e "  ${WHITE}│${RESET}   ${GRAY}Cloudflare Tunnel:${RESET}                              ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}Public:   ${APP_URL}${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}Internal: http://localhost:${LISTEN_PORT}${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"
elif ! $USE_SSL; then
echo -e "  ${WHITE}│${RESET}   ${GRAY}Nginx port:${RESET} ${LISTEN_PORT}                               ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}   ${GRAY}To add Cloudflare Tunnel later:${RESET}                 ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}sudo cloudflared service install <TOKEN>${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}Point tunnel → http://localhost:${LISTEN_PORT}${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"
fi

echo -e "  ${WHITE}│${RESET}   ${GRAY}Services:${RESET}                                       ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}systemctl status skyport-panel${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}journalctl -u skyport-panel -f${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}   ${GRAY}To fix .env later:${RESET}                              ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}nano ${INSTALL_DIR}/.env${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}cd ${INSTALL_DIR}${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}php artisan optimize:clear${RESET}"
echo -e "  ${WHITE}│${RESET}     ${DIM}systemctl restart skyport-panel skyport-ssr skyport-queue${RESET}"
echo -e "  ${WHITE}│${RESET}                                                      ${WHITE}│${RESET}"
echo -e "  ${WHITE}│${RESET}   ${GRAY}Log:${RESET} ${DIM}${LOG_FILE}${RESET}"
echo -e "  ${WHITE}╰──────────────────────────────────────────────────────╯${RESET}"
echo ""
