#!/usr/bin/env bash
set -euo pipefail

# ──────────────────────────────────────────────────────────────
#  Forge Panel Installer — based on Skyport official installer
#  Extra features: Discord OAuth, UPI billing, Stripe,
#  daily rewards, referrals, redeem codes, tickets,
#  Cloudflare Tunnel auto-setup, and more.
# ──────────────────────────────────────────────────────────────

INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source ui.sh — use local copy (with $2 bug fixed)
if [[ -f "$INSTALLER_DIR/lib/ui.sh" ]]; then
    source "$INSTALLER_DIR/lib/ui.sh"
else
    echo "ERROR: lib/ui.sh not found. Make sure you extracted the full zip."
    exit 1
fi

INSTALL_DIR="/var/www/skyport"
PANEL_USER="www-data"
PANEL_GROUP="www-data"

trap 'abort_with_log "Installation failed unexpectedly at line $LINENO."' ERR

# ── Preflight ─────────────────────────────────────────────────

banner "Forge Panel Installer"

check_root
check_os
check_disk_space 2000 "$INSTALL_DIR"
check_memory

echo ""
> "$LOG_FILE"

# ── Existing install check ────────────────────────────────────

if [[ -f "$INSTALL_DIR/artisan" ]]; then
    warn "An existing installation was found at $INSTALL_DIR."
    echo ""
    if ask_yes_no "Remove it and start fresh?" "n"; then
        systemctl stop skyport-panel skyport-queue skyport-ssr 2>/dev/null || true
        rm -rf "$INSTALL_DIR"
        success "Removed existing installation."
    else
        error "Installation cancelled."
        exit 1
    fi
fi

# ── Release channel ───────────────────────────────────────────

step "Release channel"

CHANNEL_CHOICE=$(ask_choice "Which release channel?" \
    "Stable (latest release — recommended)" \
    "Bleeding edge (main branch)")
if [[ "$CHANNEL_CHOICE" == "2" ]]; then
    CHANNEL="edge"
    warn "Bleeding edge may contain bugs or incomplete features."
    echo ""
    if ! ask_yes_no "Continue with bleeding edge?" "n"; then
        CHANNEL="stable"
    fi
else
    CHANNEL="stable"
fi
success "Channel: $CHANNEL"

# ── Web server / SSL / Cloudflare ─────────────────────────────

step "Web server configuration"

USE_SSL=false
USE_CLOUDFLARE=false
FQDN=""
LISTEN_PORT=""
APP_URL=""

if ask_yes_no "Set up with a domain name (with SSL)?" "y"; then
    USE_SSL=true
    FQDN=$(ask "Domain name" "panel.example.com")
    while [[ -z "$FQDN" || "$FQDN" == "panel.example.com" ]]; do
        if ask_yes_no "Use 'panel.example.com' as the actual domain?" "n"; then break; fi
        FQDN=$(ask "Domain name")
    done
    APP_URL="https://${FQDN}"
    LISTEN_PORT=""
    info "Will configure Nginx + Let's Encrypt for $FQDN"
else
    # Ask port first (matches original Skyport behaviour)
    LISTEN_PORT=$(ask "Port to listen on" "8080")
    while ! [[ "$LISTEN_PORT" =~ ^[0-9]+$ ]] || \
          [[ "$LISTEN_PORT" -lt 1 || "$LISTEN_PORT" -gt 65535 ]]; do
        warn "Invalid port. Enter a number between 1 and 65535."
        LISTEN_PORT=$(ask "Port to listen on" "8080")
    done
    if ! check_port_available "$LISTEN_PORT"; then
        warn "Port $LISTEN_PORT is already in use."
        if ! ask_yes_no "Continue anyway?" "n"; then
            LISTEN_PORT=$(ask "Port to listen on" "8080")
        fi
    fi

    # Ask domain for APP_URL (used by Cloudflare tunnel)
    if ask_yes_no "Are you using a Cloudflare Tunnel?" "n"; then
        USE_CLOUDFLARE=true
        FQDN=$(ask "Your panel domain (e.g. panel.example.com)" "panel.example.com")
        APP_URL="https://${FQDN}"
        info "Nginx will listen on port $LISTEN_PORT (HTTP only)."
        info "Cloudflare Tunnel will proxy https://${FQDN} → http://localhost:${LISTEN_PORT}"
        echo ""

        if ask_yes_no "Install Cloudflare Tunnel (cloudflared) now?" "y"; then
            echo ""
            info "Running Cloudflare Tunnel installer..."
            info "You will be asked for your tunnel token."
            echo ""
            # Run the cloudflare.sh script directly
            bash <(curl -fsSL https://raw.githubusercontent.com/JishnuTheGamer/Vps/refs/heads/main/cd/cloudflare.sh)
            success "Cloudflare Tunnel setup complete."
        else
            echo ""
            warn "Skipping cloudflared install."
            info "Manually point your Cloudflare Tunnel to: http://localhost:${LISTEN_PORT}"
            info "Command: cloudflared service install <YOUR_TUNNEL_TOKEN>"
            echo ""
        fi
    else
        FQDN=""
        APP_URL="http://$(hostname -I | awk '{print $1}'):${LISTEN_PORT}"
        info "Will configure Nginx on port $LISTEN_PORT (no SSL, no tunnel)"
    fi
fi

# ── Database ──────────────────────────────────────────────────

step "Database"

DB_CHOICE=$(ask_choice "Database engine" \
    "SQLite (simple, no setup)" \
    "MySQL / MariaDB (existing server)")
if [[ "$DB_CHOICE" == "2" ]]; then
    DB_CONNECTION="mysql"
    DB_HOST=$(ask "Database host" "127.0.0.1")
    DB_PORT=$(ask "Database port" "3306")
    DB_DATABASE=$(ask "Database name" "skyport")
    DB_USERNAME=$(ask "Database username" "skyport")
    DB_PASSWORD=$(ask_password "Database password")

    if check_command php; then
        info "Testing database connection..."
        if php -r "try { new PDO('mysql:host=${DB_HOST};port=${DB_PORT};dbname=${DB_DATABASE}', '${DB_USERNAME}', '${DB_PASSWORD}'); echo 'ok'; } catch(Exception \$e) { echo 'fail: ' . \$e->getMessage(); exit(1); }" 2>/dev/null; then
            success "Database connection successful"
        else
            warn "Could not connect to the database. Migrations may fail."
            if ! ask_yes_no "Continue anyway?" "y"; then exit 1; fi
        fi
    fi
else
    DB_CONNECTION="sqlite"
    DB_HOST="" DB_PORT="" DB_DATABASE="" DB_USERNAME="" DB_PASSWORD=""
fi
success "Database: $DB_CONNECTION"

# ── Admin account ─────────────────────────────────────────────

step "Administrator account"

ADMIN_NAME=$(ask "Admin name" "Admin")
ADMIN_EMAIL=$(ask "Admin email" "admin@example.com")
while [[ ! "$ADMIN_EMAIL" =~ ^[^@]+@[^@]+\.[^@]+$ ]]; do
    warn "Please enter a valid email address."
    ADMIN_EMAIL=$(ask "Admin email")
done
ADMIN_PASSWORD=$(ask_password "Admin password")
while [[ ${#ADMIN_PASSWORD} -lt 8 ]]; do
    warn "Password must be at least 8 characters."
    ADMIN_PASSWORD=$(ask_password "Admin password")
done
success "Admin: $ADMIN_EMAIL"

# ── Discord OAuth ─────────────────────────────────────────────

step "Discord OAuth (optional)"

DISCORD_CLIENT_ID=""
DISCORD_CLIENT_SECRET=""
DISCORD_BOT_TOKEN=""
DISCORD_LOG_WEBHOOK=""

if ask_yes_no "Enable Discord OAuth (login with Discord)?" "n"; then
    DISCORD_CLIENT_ID=$(ask "Discord Client ID")
    DISCORD_CLIENT_SECRET=$(ask_password "Discord Client Secret")
    if ask_yes_no "Enable Discord Bot notifications (DMs + webhook logs)?" "n"; then
        DISCORD_BOT_TOKEN=$(ask_password "Discord Bot Token")
        DISCORD_LOG_WEBHOOK=$(ask "Discord Webhook URL for logs (leave blank to skip)" "")
    fi
    success "Discord OAuth: enabled"
else
    success "Discord OAuth: skipped"
fi

# ── Billing ───────────────────────────────────────────────────

step "Billing (Stripe + UPI)"

STRIPE_KEY=""
STRIPE_SECRET=""
STRIPE_WEBHOOK_SECRET=""

if ask_yes_no "Enable Stripe card payments?" "n"; then
    STRIPE_KEY=$(ask "Stripe Publishable Key (pk_...)")
    STRIPE_SECRET=$(ask_password "Stripe Secret Key (sk_...)")
    STRIPE_WEBHOOK_SECRET=$(ask_password "Stripe Webhook Secret (whsec_...)")
    success "Stripe: enabled"
else
    success "Stripe: skipped"
fi

UPI_VPA=$(ask "Your UPI ID (for UPI payments)" "abcd@fam")
UPI_NAME=$(ask "UPI display name" "Forge Panel")

# ── Renewal system ────────────────────────────────────────────

step "Server renewal system (optional)"

RENEWAL_ENABLED=false
RENEWAL_PERIOD="monthly"
RENEWAL_CUSTOM_DAYS=30

if ask_yes_no "Enable server renewals (auto-suspend on expiry)?" "n"; then
    RENEWAL_ENABLED=true
    P=$(ask_choice "Renewal period" \
        "Daily (every 1 day)" \
        "Weekly (every 7 days)" \
        "Monthly (every 30 days)" \
        "Custom (specify days)")
    case "$P" in
        1) RENEWAL_PERIOD="daily" ;;
        2) RENEWAL_PERIOD="weekly" ;;
        3) RENEWAL_PERIOD="monthly" ;;
        4) RENEWAL_PERIOD="custom"
           RENEWAL_CUSTOM_DAYS=$(ask "Days per renewal period" "30") ;;
    esac
    success "Renewals: enabled ($RENEWAL_PERIOD)"
else
    success "Renewals: disabled"
fi

# ── Cloudflare Subdomains ─────────────────────────────────────

step "Cloudflare Subdomains (optional)"

CF_SUB_ENABLED=false
CF_API_TOKEN=""
CF_ZONE_ID=""
CF_DOMAIN_NAME=""

if ask_yes_no "Enable per-server Cloudflare subdomain management?" "n"; then
    CF_SUB_ENABLED=true
    CF_API_TOKEN=$(ask_password "Cloudflare API Token")
    CF_ZONE_ID=$(ask "Cloudflare Zone ID")
    CF_DOMAIN_NAME=$(ask "Base domain (e.g. example.com)")
    success "Cloudflare subdomains: enabled"
else
    success "Cloudflare subdomains: skipped"
fi

# ── Telemetry ─────────────────────────────────────────────────

step "Telemetry"

info "Skyport can send anonymous install telemetry (no personal data)."
echo ""
if ask_yes_no "Enable anonymous telemetry?" "y"; then
    TELEMETRY_ENABLED=true
else
    TELEMETRY_ENABLED=false
fi
success "Telemetry: $(if $TELEMETRY_ENABLED; then echo 'enabled'; else echo 'disabled'; fi)"

# ── Summary ───────────────────────────────────────────────────

step "Installation summary"

info "Channel:    ${CHANNEL}"
if $USE_SSL; then
    info "URL:        ${APP_URL} (SSL with Let's Encrypt)"
elif $USE_CLOUDFLARE; then
    info "URL:        ${APP_URL} (Cloudflare Tunnel → localhost:${LISTEN_PORT})"
else
    info "URL:        ${APP_URL}"
fi
info "Database:   ${DB_CONNECTION}"
info "Admin:      ${ADMIN_EMAIL}"
info "Discord:    ${DISCORD_CLIENT_ID:+enabled}${DISCORD_CLIENT_ID:-skipped}"
info "Stripe:     ${STRIPE_KEY:+enabled}${STRIPE_KEY:-skipped}"
info "UPI ID:     ${UPI_VPA}"
info "Renewals:   $(if $RENEWAL_ENABLED; then echo "enabled (${RENEWAL_PERIOD})"; else echo "disabled"; fi)"
info "CF Subs:    $(if $CF_SUB_ENABLED; then echo "enabled (${CF_DOMAIN_NAME})"; else echo "disabled"; fi)"
info "Install to: ${INSTALL_DIR}"
echo ""

if ! ask_yes_no "Begin installation?" "y"; then
    info "Installation cancelled."
    exit 0
fi

# ── System packages ───────────────────────────────────────────

step "Installing system dependencies"

run_step "Updating package lists" apt-get update -y

install_base_packages() {
    local packages=(curl gnupg2 ca-certificates lsb-release unzip git nginx)
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${packages[@]}"
}
run_step "Installing base packages" install_base_packages

install_php_packages() {
    source /etc/os-release
    if [[ "$ID" == "ubuntu" ]]; then
        DEBIAN_FRONTEND=noninteractive apt-get install -y software-properties-common
        add-apt-repository -y ppa:ondrej/php
    else
        curl -fsSL https://packages.sury.org/php/apt.gpg | gpg --dearmor --yes -o /usr/share/keyrings/sury-php.gpg
        local codename; codename=$(lsb_release -sc)
        if ! curl -fsSL --head "https://packages.sury.org/php/dists/${codename}/Release" >/dev/null 2>&1; then
            codename="bookworm"
        fi
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] https://packages.sury.org/php/ ${codename} main" \
            > /etc/apt/sources.list.d/sury-php.list
    fi
    apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        php8.4-cli php8.4-common php8.4-curl php8.4-mbstring \
        php8.4-xml php8.4-zip php8.4-bcmath php8.4-sqlite3 \
        php8.4-mysql php8.4-swoole php8.4-readline php8.4-gd php8.4-intl \
        sqlite3
}
run_step "Installing PHP 8.4 + Swoole + sqlite3" install_php_packages

if ! php -v >> "$LOG_FILE" 2>&1; then
    abort_with_log "PHP 8.4 installation failed."
fi

install_composer() {
    if check_command composer; then return 0; fi
    local expected_sig actual_sig
    expected_sig=$(curl -fsSL --retry 3 https://composer.github.io/installer.sig)
    curl -fsSL --retry 3 https://getcomposer.org/installer -o /tmp/composer-setup.php
    actual_sig=$(php -r "echo hash_file('sha384', '/tmp/composer-setup.php');")
    if [[ "$expected_sig" != "$actual_sig" ]]; then
        echo "Composer signature mismatch" >&2; rm -f /tmp/composer-setup.php; return 1
    fi
    php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
    rm -f /tmp/composer-setup.php
}
run_step "Installing Composer" install_composer

install_bun() {
    if check_command bun; then return 0; fi
    curl -fsSL --retry 3 https://bun.sh/install | bash
    [[ -f "$HOME/.bun/bin/bun" ]] && ln -sf "$HOME/.bun/bin/bun" /usr/local/bin/bun
}
run_step "Installing Bun" install_bun
export PATH="/usr/local/bin:$HOME/.bun/bin:$PATH"
if ! check_command bun; then abort_with_log "Bun installation failed."; fi

install_node() {
    local need_install=true
    if check_command node; then
        local current_major
        current_major=$(node -v 2>/dev/null | grep -oP '^v\K\d+' || echo "0")
        [[ "$current_major" -ge 22 ]] && need_install=false
    fi
    if $need_install; then
        curl -fsSL --retry 3 https://deb.nodesource.com/setup_22.x | bash -
        DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs
    fi
}
run_step "Installing Node.js 22" install_node

# ── Download panel ────────────────────────────────────────────

step "Downloading Skyport Panel"

download_panel() {
    [[ -d "$INSTALL_DIR" ]] && rm -rf "$INSTALL_DIR"
    mkdir -p "$INSTALL_DIR"
    if [[ "$CHANNEL" == "stable" ]]; then
        local tag
        tag=$(latest_github_release "skyportsh/panel")
        if [[ -n "$tag" ]]; then
            curl -fsSL --retry 3 "https://github.com/skyportsh/panel/archive/refs/tags/${tag}.tar.gz" \
                | tar -xz --strip-components=1 -C "$INSTALL_DIR"
            return 0
        fi
    fi
    git clone --depth 1 https://github.com/skyportsh/panel.git "$INSTALL_DIR"
}
run_step "Downloading panel ($CHANNEL)" download_panel

if [[ ! -f "$INSTALL_DIR/artisan" ]]; then
    abort_with_log "Panel download failed — artisan not found."
fi

# ── Apply Forge patches over downloaded Skyport ───────────────
step "Applying Forge Panel patches"

apply_forge_patches() {
    local forge_src="$INSTALLER_DIR/panel"

    if [[ ! -d "$forge_src" ]]; then
        echo "ERROR: panel/ directory not found at $forge_src" >&2
        echo "Make sure you extracted the full forge-panel zip." >&2
        exit 1
    fi

    # Copy all Forge additions on top of the downloaded Skyport
    # Migrations
    cp -f "$forge_src"/database/migrations/2025_01_01_*.php         "$INSTALL_DIR/database/migrations/" 2>/dev/null || true

    # Models
    for f in DailyReward Transaction Renewal Referral RedeemCode RedeemCodeUse               Subdomain Ticket TicketMessage Announcement ForgeNotification; do
        cp -f "$forge_src/app/Models/${f}.php" "$INSTALL_DIR/app/Models/" 2>/dev/null || true
    done

    # Patch User model — append Forge relationships if not already there
    if ! grep -q "forgeNotifications" "$INSTALL_DIR/app/Models/User.php" 2>/dev/null; then
        python3 - << PYEOF
import re, sys

path = "$INSTALL_DIR/app/Models/User.php"
content = open(path).read()

forge_methods = """
    // ── Forge relationships ──────────────────────────────────────

    public function transactions(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(Transaction::class);
    }

    public function dailyRewards(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(DailyReward::class);
    }

    public function referrals(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(Referral::class, 'referrer_id');
    }

    public function renewals(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(Renewal::class);
    }

    public function tickets(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(Ticket::class);
    }

    public function subdomains(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(Subdomain::class);
    }

    public function forgeNotifications(): \\Illuminate\\Database\\Eloquent\\Relations\\HasMany
    {
        return \\$this->hasMany(ForgeNotification::class);
    }

    public function unreadNotificationsCount(): int
    {
        return \\$this->forgeNotifications()->where('read', false)->count();
    }

    public function getDiscordAvatarUrlAttribute(): string
    {
        if (\\$this->discord_id && \\$this->discord_avatar) {
            return "https://cdn.discordapp.com/avatars/{\\$this->discord_id}/{\\$this->discord_avatar}.png?size=64";
        }
        return "https://ui-avatars.com/api/?name=" . urlencode(\\$this->name) . "&background=0718d9&color=fff&size=64";
    }
"""

# Insert before last closing brace
content = content.rstrip()
if content.endswith('}'):
    content = content[:-1] + forge_methods + "
}
"
    open(path, 'w').write(content)
    print("User model patched")
else:
    print("User model: could not find closing brace", file=sys.stderr)
PYEOF
    fi

    # Services
    for f in BillingService DailyRewardService DiscordService               ForgeServices NotificationService; do
        cp -f "$forge_src/app/Services/${f}.php" "$INSTALL_DIR/app/Services/" 2>/dev/null || true
    done

    # Controllers
    mkdir -p "$INSTALL_DIR/app/Http/Controllers/Forge"
    mkdir -p "$INSTALL_DIR/app/Http/Controllers/Admin"
    cp -f "$forge_src/app/Http/Controllers/Forge/DiscordAuthController.php"         "$INSTALL_DIR/app/Http/Controllers/Forge/" 2>/dev/null || true
    cp -f "$forge_src/app/Http/Controllers/Forge/ForgeControllers.php"         "$INSTALL_DIR/app/Http/Controllers/Forge/" 2>/dev/null || true
    cp -f "$forge_src/app/Http/Controllers/Admin/ForgeAdminControllers.php"         "$INSTALL_DIR/app/Http/Controllers/Admin/" 2>/dev/null || true

    # Console commands
    mkdir -p "$INSTALL_DIR/app/Console/Commands"
    cp -f "$forge_src/app/Console/Commands/ProcessRenewals.php"         "$INSTALL_DIR/app/Console/Commands/" 2>/dev/null || true

    # Config
    cp -f "$forge_src/config/forge.php" "$INSTALL_DIR/config/" 2>/dev/null || true

    # Routes
    cp -f "$forge_src/routes/forge.php" "$INSTALL_DIR/routes/" 2>/dev/null || true

    # Register forge routes in web.php
    if ! grep -q "forge.php" "$INSTALL_DIR/routes/web.php" 2>/dev/null; then
        echo "" >> "$INSTALL_DIR/routes/web.php"
        echo "require __DIR__.'/forge.php';" >> "$INSTALL_DIR/routes/web.php"
    fi

    # React pages
    mkdir -p "$INSTALL_DIR/resources/js/pages/forge"
    mkdir -p "$INSTALL_DIR/resources/js/pages/admin/forge"
    cp -f "$forge_src/resources/js/pages/forge/"*.tsx         "$INSTALL_DIR/resources/js/pages/forge/" 2>/dev/null || true
    cp -f "$forge_src/resources/js/pages/admin/forge/"*.tsx         "$INSTALL_DIR/resources/js/pages/admin/forge/" 2>/dev/null || true

    # SVG icon components
    for icon in billing-icon shop-icon daily-icon referral-icon redeem-icon                 ticket-icon leaderboard-icon announcement-icon; do
        cp -f "$forge_src/resources/js/components/${icon}.tsx"             "$INSTALL_DIR/resources/js/components/" 2>/dev/null || true
    done

    # Patched auth pages (Discord button added)
    cp -f "$forge_src/resources/js/pages/auth/login.tsx"         "$INSTALL_DIR/resources/js/pages/auth/" 2>/dev/null || true
    cp -f "$forge_src/resources/js/pages/auth/register.tsx"         "$INSTALL_DIR/resources/js/pages/auth/" 2>/dev/null || true

    # Patched sidebar (Forge nav items + logo)
    cp -f "$forge_src/resources/js/components/app-sidebar.tsx"         "$INSTALL_DIR/resources/js/components/" 2>/dev/null || true

    # Patched header (coins + notification bell)
    cp -f "$forge_src/resources/js/components/app-header.tsx"         "$INSTALL_DIR/resources/js/components/" 2>/dev/null || true

    # Patched dashboard (announcements + daily banner)
    cp -f "$forge_src/resources/js/pages/dashboard.tsx"         "$INSTALL_DIR/resources/js/pages/" 2>/dev/null || true

    # CSS brand color fix (orange → Forge blue)
    if [[ -f "$forge_src/resources/css/app.css" ]]; then
        cp -f "$forge_src/resources/css/app.css"             "$INSTALL_DIR/resources/css/" 2>/dev/null || true
    fi

    # Patch AppServiceProvider to register Forge services + schedule
    local provider="$INSTALL_DIR/app/Providers/AppServiceProvider.php"
    if [[ -f "$provider" ]] && ! grep -q "DailyRewardService" "$provider"; then
        python3 - << PYEOF2
content = open("$provider").read()
forge_boot = """
        // ── Forge Panel services ──────────────────────────────────
        \\$this->app->singleton(\\App\\Services\\DailyRewardService::class);
        \\$this->app->singleton(\\App\\Services\\BillingService::class);
        \\$this->app->singleton(\\App\\Services\\ReferralService::class);
        \\$this->app->singleton(\\App\\Services\\RedeemService::class);
        \\$this->app->singleton(\\App\\Services\\RenewalService::class);
        \\$this->app->singleton(\\App\\Services\\NotificationService::class);
        \\$this->app->singleton(\\App\\Services\\DiscordService::class);

        // Renewal cron
        \\$schedule = \\$this->app->make(\\Illuminate\\Console\\Scheduling\\Schedule::class);
        \\$schedule->command('forge:renewals')->everyThirtyMinutes();

"""
content = content.replace(
    "    public function boot(): void
    {
",
    "    public function boot(): void
    {
" + forge_boot,
    1
)
open("$provider", 'w').write(content)
print("AppServiceProvider patched")
PYEOF2
    fi

    echo "Forge patches applied successfully."
}
run_step "Applying Forge patches" apply_forge_patches

# ── Dependencies ──────────────────────────────────────────────

step "Installing application dependencies"

install_php_deps() {
    cd "$INSTALL_DIR"
    COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --no-interaction --optimize-autoloader --no-progress
}
install_js_deps() {
    cd "$INSTALL_DIR"
    bun install --frozen-lockfile 2>/dev/null || bun install
}
run_step "Installing PHP dependencies" install_php_deps
run_step "Installing JS dependencies" install_js_deps

# ── Configure environment ─────────────────────────────────────

step "Configuring application"

configure_env() {
    cd "$INSTALL_DIR"
    cp .env.example .env
    php artisan key:generate --no-interaction --force

    local env_args=(--url="$APP_URL" --db-connection="$DB_CONNECTION")
    if [[ "$DB_CONNECTION" == "mysql" ]]; then
        env_args+=(
            --db-host="$DB_HOST" --db-port="$DB_PORT"
            --db-database="$DB_DATABASE" --db-username="$DB_USERNAME"
            --db-password="$DB_PASSWORD"
        )
    fi
    php artisan environment:setup "${env_args[@]}" --no-interaction

    [[ "$DB_CONNECTION" == "sqlite" ]] && touch database/database.sqlite

    sed -i -e '$a\' .env

    # Helper: set or replace a key in .env
    set_env() {
        local key="$1" val="$2"
        if grep -q "^${key}=" .env 2>/dev/null; then
            sed -i "s|^${key}=.*|${key}=${val}|" .env
        else
            echo "${key}=${val}" >> .env
        fi
    }

    # Core fixes (prevents broken UI / wrong redirects)
    set_env APP_URL        "${APP_URL}"
    set_env ASSET_URL      "${APP_URL}"
    set_env TRUSTED_PROXIES '*'
    set_env APP_VERSION    '1.0.0-alpha2'
    set_env OCTANE_SERVER  'swoole'

    # Telemetry
    set_env SKYPORT_TELEMETRY_ENABLED "$(if $TELEMETRY_ENABLED; then echo true; else echo false; fi)"

    # ── Forge additions ──────────────────────────────────────
    set_env FORGE_LOGO_URL 'https://i.postimg.cc/K8ZkkhM9/file-000000001d5c72089d1c7d0792db739d.png'

    # Discord
    set_env DISCORD_CLIENT_ID      "${DISCORD_CLIENT_ID}"
    set_env DISCORD_CLIENT_SECRET  "${DISCORD_CLIENT_SECRET}"
    set_env DISCORD_BOT_TOKEN      "${DISCORD_BOT_TOKEN}"
    set_env DISCORD_REDIRECT_URI   "${APP_URL}/auth/discord/callback"
    set_env DISCORD_LOG_WEBHOOK    "${DISCORD_LOG_WEBHOOK}"
    set_env DISCORD_SIGNUP_BONUS   '100'

    # Stripe
    set_env STRIPE_KEY             "${STRIPE_KEY}"
    set_env STRIPE_SECRET          "${STRIPE_SECRET}"
    set_env STRIPE_WEBHOOK_SECRET  "${STRIPE_WEBHOOK_SECRET}"

    # UPI
    set_env UPI_VPA   "${UPI_VPA}"
    set_env UPI_NAME  "\"${UPI_NAME}\""

    # Coins
    set_env COINS_PER_INR '10'
    set_env COINS_PER_USD '100'

    # Daily
    set_env DAILY_BASE_COINS     '25'
    set_env DAILY_STREAK_7_MULT  '1.5'
    set_env DAILY_STREAK_14_MULT '2.0'
    set_env DAILY_STREAK_30_MULT '3.0'

    # Referral
    set_env REFERRAL_ENABLED        'true'
    set_env REFERRAL_REFERRER_COINS '200'
    set_env REFERRAL_REFEREE_COINS  '100'

    # Shop
    set_env SHOP_RAM_COIN_COST    '10'
    set_env SHOP_DISK_COIN_COST   '5'
    set_env SHOP_CPU_COIN_COST    '20'
    set_env SHOP_SERVER_COIN_COST '500'

    # Renewal
    set_env RENEWAL_ENABLED      "$(if $RENEWAL_ENABLED; then echo true; else echo false; fi)"
    set_env RENEWAL_PERIOD       "${RENEWAL_PERIOD}"
    set_env RENEWAL_CUSTOM_DAYS  "${RENEWAL_CUSTOM_DAYS}"
    set_env RENEWAL_WARNING_DAYS '3'
    set_env RENEWAL_GRACE_DAYS   '7'

    # Cloudflare subdomains
    set_env CF_ENABLED   "$(if $CF_SUB_ENABLED; then echo true; else echo false; fi)"
    set_env CF_API_TOKEN "${CF_API_TOKEN}"
    set_env CF_ZONE_ID   "${CF_ZONE_ID}"
    set_env CF_DOMAIN    "${CF_DOMAIN_NAME}"

    # Default resources
    set_env DEFAULT_RAM     '2048'
    set_env DEFAULT_DISK    '5120'
    set_env DEFAULT_CPU     '100'
    set_env DEFAULT_SERVERS '1'
}
run_step "Configuring environment" configure_env

# ── Migrations & build ────────────────────────────────────────

run_migrations() {
    cd "$INSTALL_DIR"
    php artisan migrate --force --no-interaction
}
generate_wayfinder() {
    cd "$INSTALL_DIR"
    php artisan wayfinder:generate --with-form --no-interaction 2>/dev/null || true
}
build_assets() {
    cd "$INSTALL_DIR"
    bun run build:ssr
}
create_admin_user() {
    cd "$INSTALL_DIR"
    php artisan user:create \
        --name="$ADMIN_NAME" --email="$ADMIN_EMAIL" \
        --password="$ADMIN_PASSWORD" --admin --no-interaction
}

run_step "Running database migrations" run_migrations \
    || abort_with_log "Database migrations failed. Check your database configuration."
run_step "Generating route bindings" generate_wayfinder
run_step "Building frontend assets (takes a minute)" build_assets \
    || abort_with_log "Asset build failed."
run_step "Creating admin user" create_admin_user

# ── Telemetry ─────────────────────────────────────────────────

configure_telemetry() {
    cd "$INSTALL_DIR"
    local val; val=$(if $TELEMETRY_ENABLED; then echo '1'; else echo '0'; fi)
    php artisan tinker --no-interaction --execute "
        \App\Models\AppSetting::updateOrCreate(
            ['key' => 'telemetry_enabled'],
            ['value' => '${val}']
        );
        echo 'Telemetry configured.';
    " 2>/dev/null || true
    if $TELEMETRY_ENABLED; then
        php artisan telemetry:report --event=install --no-interaction 2>/dev/null || true
    fi
}
run_step "Configuring telemetry" configure_telemetry

# ── Permissions ───────────────────────────────────────────────

set_permissions() {
    cd "$INSTALL_DIR"
    chown -R "$PANEL_USER:$PANEL_GROUP" .
    chmod -R 755 storage bootstrap/cache
    if [[ "$DB_CONNECTION" == "sqlite" && -f database/database.sqlite ]]; then
        chown "$PANEL_USER:$PANEL_GROUP" database/database.sqlite
        chmod 664 database/database.sqlite
        chown "$PANEL_USER:$PANEL_GROUP" database
        chmod 775 database
    fi
}
run_step "Setting file permissions" set_permissions

# ── SSL certificate ───────────────────────────────────────────

if $USE_SSL; then
    step "Setting up SSL"
    install_certbot() {
        DEBIAN_FRONTEND=noninteractive apt-get install -y certbot python3-certbot-nginx
    }
    obtain_certificate() {
        systemctl stop nginx 2>/dev/null || true
        certbot certonly --standalone -d "$FQDN" \
            --non-interactive --agree-tos --register-unsafely-without-email
        systemctl start nginx 2>/dev/null || true
    }
    run_step "Installing Certbot" install_certbot
    run_step "Obtaining Let's Encrypt certificate" obtain_certificate \
        || abort_with_log "SSL cert failed. Make sure $FQDN resolves to this server and port 80 is open."
fi

# ── Nginx ─────────────────────────────────────────────────────

step "Configuring Nginx"

configure_nginx() {
    local octane_port=8000

    if $USE_SSL; then
        cat > /etc/nginx/sites-available/skyport.conf << NGINX_CONF
server {
    listen 80;
    server_name ${FQDN};
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${FQDN};

    ssl_certificate     /etc/letsencrypt/live/${FQDN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${FQDN}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;

    location / {
        proxy_pass         http://127.0.0.1:${octane_port};
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Upgrade           \$http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_buffering    off;
        proxy_read_timeout 300s;
    }
}
NGINX_CONF
    else
        # Plain HTTP — Cloudflare Tunnel or direct HTTP on LISTEN_PORT
        cat > /etc/nginx/sites-available/skyport.conf << NGINX_CONF
server {
    listen ${LISTEN_PORT};
    server_name _;

    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;

    location / {
        proxy_pass         http://127.0.0.1:${octane_port};
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Upgrade           \$http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_buffering    off;
        proxy_read_timeout 300s;
    }
}
NGINX_CONF
    fi

    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/skyport.conf /etc/nginx/sites-enabled/skyport.conf
    nginx -t
    systemctl restart nginx
}
run_step "Configuring Nginx" configure_nginx \
    || abort_with_log "Nginx configuration failed."

# ── Systemd services ──────────────────────────────────────────

step "Creating systemd services"

create_services() {
    cat > /etc/systemd/system/skyport-panel.service << SERVICE
[Unit]
Description=Skyport Panel (Octane)
After=network.target

[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan octane:start --server=swoole --host=127.0.0.1 --port=8000
ExecReload=/usr/bin/php artisan octane:reload
Restart=always
RestartSec=5
StartLimitBurst=5
StartLimitIntervalSec=60

[Install]
WantedBy=multi-user.target
SERVICE

    cat > /etc/systemd/system/skyport-queue.service << SERVICE
[Unit]
Description=Skyport Queue Worker
After=network.target skyport-panel.service

[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan queue:work --tries=3 --timeout=60
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

    cat > /etc/systemd/system/skyport-ssr.service << SERVICE
[Unit]
Description=Skyport Inertia SSR
After=network.target

[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan inertia:start-ssr
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

    cat > /etc/systemd/system/skyport-scheduler.service << SERVICE
[Unit]
Description=Skyport Scheduler (renewals, etc)
After=network.target

[Service]
User=${PANEL_USER}
Group=${PANEL_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan schedule:work
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICE

    systemctl daemon-reload
    systemctl enable skyport-panel skyport-queue skyport-ssr skyport-scheduler
    systemctl restart skyport-panel skyport-queue skyport-ssr skyport-scheduler
}
run_step "Creating and starting services" create_services

sleep 3

FAILED_SERVICES=""
for svc in skyport-panel skyport-queue skyport-ssr; do
    if ! systemctl is-active --quiet "$svc"; then
        FAILED_SERVICES="$FAILED_SERVICES $svc"
    fi
done
[[ -n "$FAILED_SERVICES" ]] && \
    warn "Some services may still be starting:$FAILED_SERVICES" || \
    success "All services running"

# ── Final .env fix (prevents broken UI) ──────────────────────

final_fix() {
    cd "$INSTALL_DIR"
    # These are the definitive commands that fix broken UI
    sed -i "s|APP_URL=.*|APP_URL=${APP_URL}|"     .env
    sed -i "s|ASSET_URL=.*|ASSET_URL=${APP_URL}|" .env
    grep -q "^TRUSTED_PROXIES=" .env \
        && sed -i "s|TRUSTED_PROXIES=.*|TRUSTED_PROXIES=*|" .env \
        || echo "TRUSTED_PROXIES=*" >> .env
    grep -q "^APP_VERSION=" .env \
        && sed -i "s|APP_VERSION=.*|APP_VERSION=1.0.0-alpha2|" .env \
        || echo "APP_VERSION=1.0.0-alpha2" >> .env

    php artisan optimize:clear
    php artisan config:clear
    php artisan cache:clear
    systemctl restart skyport-panel skyport-ssr skyport-queue 2>/dev/null || true
}
run_step "Fixing APP_URL + clearing all caches" final_fix

# ── Done ──────────────────────────────────────────────────────

trap - ERR

step "Installation complete"

echo ""
echo -e "  ${ORANGE}╭──────────────────────────────────────────────────────╮${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${WHITE}Forge Panel is now running!${RESET}                        ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}URL:${RESET}   ${ORANGE_DARK}${APP_URL}${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}Admin:${RESET} ${ORANGE_DARK}${ADMIN_EMAIL}${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"

if $USE_CLOUDFLARE; then
    echo -e "  ${ORANGE}│${RESET}   ${GRAY}Cloudflare Tunnel:${RESET}                              ${ORANGE}│${RESET}"
    echo -e "  ${ORANGE}│${RESET}     ${DIM}Public:   ${APP_URL}${RESET}"
    echo -e "  ${ORANGE}│${RESET}     ${DIM}Internal: http://localhost:${LISTEN_PORT}${RESET}"
    echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
elif ! $USE_SSL; then
    echo -e "  ${ORANGE}│${RESET}   ${GRAY}Nginx port:${RESET} ${LISTEN_PORT}                               ${ORANGE}│${RESET}"
    echo -e "  ${ORANGE}│${RESET}   ${GRAY}If using Cloudflare Tunnel later:${RESET}               ${ORANGE}│${RESET}"
    echo -e "  ${ORANGE}│${RESET}     ${DIM}Point tunnel → http://localhost:${LISTEN_PORT}${RESET}"
    echo -e "  ${ORANGE}│${RESET}     ${DIM}cloudflared service install <TOKEN>${RESET}"
    echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
fi

echo -e "  ${ORANGE}│${RESET}   ${GRAY}Services:${RESET}                                          ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}systemctl status skyport-panel${RESET}                 ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}systemctl status skyport-queue${RESET}                 ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}systemctl status skyport-ssr${RESET}                   ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}journalctl -u skyport-panel -f${RESET}                 ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}To fix .env later:${RESET}                              ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}nano ${INSTALL_DIR}/.env${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}cd ${INSTALL_DIR} && php artisan optimize:clear${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}systemctl restart skyport-panel skyport-ssr skyport-queue${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}Logs:${RESET} ${DIM}${LOG_FILE}${RESET}"
echo -e "  ${ORANGE}╰──────────────────────────────────────────────────────╯${RESET}"
echo ""
