import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import axios from 'axios';
import { Eye, EyeOff } from 'lucide-react';

const DiscordIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.101 18.08.114 18.102.132 18.116a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
  </svg>
);

export default function Login() {
  const { refresh } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async e => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      await axios.post('/auth/login', form, { withCredentials: true });
      await refresh();
      window.location.href = '/dashboard';
    } catch (e) {
      setError(e.response?.data?.error || 'Login failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="card space-y-6">
      <div>
        <h1 className="text-xl font-bold">Welcome back</h1>
        <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>Sign in to Forge Panel</p>
      </div>

      {error && <div className="badge badge-red w-full justify-center py-2 text-sm">{error}</div>}

      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="text-sm font-medium block mb-1">Email</label>
          <input className="input" type="email" placeholder="you@example.com" value={form.email}
            onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1">Password</label>
          <div className="relative">
            <input className="input pr-10" type={showPass ? 'text' : 'password'} placeholder="••••••••"
              value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
            <button type="button" onClick={() => setShowPass(s => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'rgb(var(--text-muted))' }}>
              {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>
        </div>
        <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-2.5">
          {loading ? 'Signing in...' : 'Sign in'}
        </button>
      </form>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t" style={{ borderColor: 'rgb(var(--border))' }} />
        </div>
        <div className="relative flex justify-center text-xs" style={{ color: 'rgb(var(--text-muted))' }}>
          <span className="px-2" style={{ background: 'rgb(var(--bg-card))' }}>or continue with</span>
        </div>
      </div>

      <a href="/auth/discord" className="btn-secondary w-full justify-center py-2.5 text-[#5865F2] border-[#5865F2]/30 hover:bg-[#5865F2]/10">
        <DiscordIcon /> Sign in with Discord
      </a>

      <p className="text-center text-sm" style={{ color: 'rgb(var(--text-muted))' }}>
        Don't have an account?{' '}
        <Link to="/auth/register" className="text-forge-500 hover:underline font-medium">Sign up</Link>
      </p>
    </div>
  );
}
