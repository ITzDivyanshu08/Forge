import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import api from '../../lib/api';
import { CheckCircle, XCircle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function BillingSuccess() {
  const [params] = useSearchParams();
  const [status, setStatus] = useState('loading');
  const [tx, setTx] = useState(null);

  useEffect(() => {
    const sessionId = params.get('session_id');
    if (!sessionId) { setStatus('error'); return; }
    api.get(`/billing/stripe/verify?session_id=${sessionId}`)
      .then(r => { setTx(r.data); setStatus('success'); })
      .catch(() => setStatus('error'));
  }, []);

  if (status === 'loading') return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  return (
    <div className="max-w-sm mx-auto card text-center space-y-4 mt-20">
      {status === 'success' ? (
        <>
          <CheckCircle size={48} className="mx-auto text-green-500" />
          <h1 className="text-xl font-bold">Payment Successful!</h1>
          <p style={{ color: 'rgb(var(--text-muted))' }}>
            {tx?.credits_given?.toLocaleString()} credits have been added to your account.
          </p>
        </>
      ) : (
        <>
          <XCircle size={48} className="mx-auto text-red-500" />
          <h1 className="text-xl font-bold">Payment Failed</h1>
          <p style={{ color: 'rgb(var(--text-muted))' }}>Something went wrong. Please contact support if charged.</p>
        </>
      )}
      <Link to="/billing" className="btn-primary w-full justify-center">Back to Billing</Link>
    </div>
  );
}
