import { useEffect, useState } from 'react';
import api from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { CreditCard, Smartphone, ShoppingCart, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

const STRIPE_PACKAGES = [
  { usd: 1,  label: '$1',  credits: 100 },
  { usd: 5,  label: '$5',  credits: 500 },
  { usd: 10, label: '$10', credits: 1100, badge: '+100 bonus' },
  { usd: 25, label: '$25', credits: 3000, badge: '+500 bonus' },
];

const UPI_PACKAGES = [
  { inr: 50,  label: '₹50',  credits: 500 },
  { inr: 100, label: '₹100', credits: 1100, badge: '+100 bonus' },
  { inr: 250, label: '₹250', credits: 3000, badge: '+500 bonus' },
  { inr: 500, label: '₹500', credits: 6500, badge: '+1000 bonus' },
];

const COIN_ITEMS = [
  { item: 'ram',    label: 'RAM',    unit: '512 MB',  amount: 512,  coinsEach: 1024 },
  { item: 'disk',   label: 'Disk',   unit: '1 GB',    amount: 1024, coinsEach: 1024 },
  { item: 'cpu',    label: 'CPU',    unit: '10%',     amount: 10,   coinsEach: 50   },
  { item: 'server', label: 'Server', unit: '+1 slot', amount: 1,    coinsEach: 500  },
];

function TabBtn({ active, onClick, children }) {
  return (
    <button onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${active ? 'bg-forge-500 text-white' : 'btn-secondary'}`}>
      {children}
    </button>
  );
}

export default function Billing() {
  const { user, refresh } = useAuth();
  const [tab, setTab] = useState('stripe');
  const [txs, setTxs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [upiData, setUpiData] = useState(null);
  const [upiRef, setUpiRef] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    api.get('/billing/transactions').then(r => setTxs(r.data));
  }, []);

  const buyStripe = async (usd) => {
    setLoading(true); setMsg('');
    try {
      const r = await api.post('/billing/stripe', { amount: usd });
      window.location.href = r.data.url;
    } catch (e) {
      setMsg(e.response?.data?.error || 'Failed');
    } finally { setLoading(false); }
  };

  const buyUpi = async (inr) => {
    setLoading(true); setMsg('');
    try {
      const r = await api.post('/billing/upi', { amount: inr });
      setUpiData(r.data);
    } catch (e) {
      setMsg(e.response?.data?.error || 'Failed');
    } finally { setLoading(false); }
  };

  const verifyUpi = async () => {
    if (!upiRef.trim()) return setMsg('Enter UPI reference number');
    setVerifying(true); setMsg('');
    try {
      await api.post('/billing/upi/verify', { txId: upiData.txId, upiRef });
      setMsg('✅ Submitted for verification! Admin will confirm shortly.');
      setUpiData(null); setUpiRef('');
      api.get('/billing/transactions').then(r => setTxs(r.data));
    } catch (e) {
      setMsg(e.response?.data?.error || 'Failed');
    } finally { setVerifying(false); }
  };

  const buyCoins = async (item, amount) => {
    try {
      const r = await api.post('/billing/coins', { item, amount });
      await refresh();
      setMsg(`✅ Purchased ${item} for ${r.data.cost} coins!`);
    } catch (e) {
      setMsg(e.response?.data?.error || 'Failed');
    }
  };

  const statusBadge = (s) => {
    if (s === 'completed') return <span className="badge badge-green"><CheckCircle size={10} /> Completed</span>;
    if (s === 'verifying') return <span className="badge badge-yellow"><AlertCircle size={10} /> Verifying</span>;
    if (s === 'failed')    return <span className="badge badge-red"><XCircle size={10} /> Failed</span>;
    return <span className="badge badge-blue"><Clock size={10} /> Pending</span>;
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold">Billing</h1>
        <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>
          Top up credits or spend coins on resources
        </p>
      </div>

      {/* Balance */}
      <div className="grid grid-cols-2 gap-3">
        <div className="card text-center">
          <div className="text-3xl font-bold text-forge-500">{user?.coins?.toLocaleString()}</div>
          <div className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>🪙 Coins</div>
        </div>
        <div className="card text-center">
          <div className="text-3xl font-bold text-green-500">{user?.credits?.toLocaleString()}</div>
          <div className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>💳 Credits</div>
        </div>
      </div>

      {msg && (
        <div className={`card text-sm py-3 text-center ${msg.startsWith('✅') ? 'border-green-500/30 text-green-500' : 'border-red-500/30 text-red-500'}`}>
          {msg}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        <TabBtn active={tab === 'stripe'} onClick={() => setTab('stripe')}><CreditCard size={14} /> Card (Stripe)</TabBtn>
        <TabBtn active={tab === 'upi'} onClick={() => setTab('upi')}><Smartphone size={14} /> UPI</TabBtn>
        <TabBtn active={tab === 'coins'} onClick={() => setTab('coins')}><ShoppingCart size={14} /> Coin Store</TabBtn>
      </div>

      {/* Stripe */}
      {tab === 'stripe' && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {STRIPE_PACKAGES.map(p => (
            <button key={p.usd} onClick={() => buyStripe(p.usd)} disabled={loading}
              className="card hover:border-forge-500/50 transition-colors text-center group cursor-pointer disabled:opacity-50">
              <div className="text-2xl font-bold text-forge-500">{p.label}</div>
              <div className="text-sm mt-1">{p.credits.toLocaleString()} credits</div>
              {p.badge && <div className="badge badge-green mt-2 mx-auto">{p.badge}</div>}
            </button>
          ))}
        </div>
      )}

      {/* UPI */}
      {tab === 'upi' && !upiData && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {UPI_PACKAGES.map(p => (
            <button key={p.inr} onClick={() => buyUpi(p.inr)} disabled={loading}
              className="card hover:border-forge-500/50 transition-colors text-center cursor-pointer disabled:opacity-50">
              <div className="text-2xl font-bold text-forge-500">{p.label}</div>
              <div className="text-sm mt-1">{p.credits.toLocaleString()} credits</div>
              {p.badge && <div className="badge badge-green mt-2 mx-auto">{p.badge}</div>}
            </button>
          ))}
        </div>
      )}

      {tab === 'upi' && upiData && (
        <div className="card max-w-sm mx-auto text-center space-y-4">
          <h2 className="font-bold text-lg">Scan to Pay</h2>
          <img src={upiData.qrCode} alt="UPI QR" className="w-48 h-48 mx-auto rounded-lg" />
          <div>
            <div className="text-sm" style={{ color: 'rgb(var(--text-muted))' }}>Pay to</div>
            <div className="font-mono font-bold text-forge-500">{upiData.vpa}</div>
            <div className="font-bold text-2xl mt-1">₹{upiData.amountINR}</div>
            <div className="text-sm" style={{ color: 'rgb(var(--text-muted))' }}>= {upiData.creditsToGive} credits</div>
          </div>
          <div className="text-sm card bg-yellow-500/10 border-yellow-500/30 text-yellow-600 dark:text-yellow-400">
            After paying, enter your UPI transaction reference below
          </div>
          <input className="input text-center" placeholder="UPI Reference / UTR number"
            value={upiRef} onChange={e => setUpiRef(e.target.value)} />
          <div className="flex gap-2">
            <button onClick={() => setUpiData(null)} className="btn-secondary flex-1">Cancel</button>
            <button onClick={verifyUpi} disabled={verifying} className="btn-primary flex-1">
              {verifying ? 'Submitting...' : 'Submit'}
            </button>
          </div>
        </div>
      )}

      {/* Coin Store */}
      {tab === 'coins' && (
        <div className="space-y-3">
          <div className="text-sm card border-forge-500/30 bg-forge-500/5">
            💡 Spend your coins to upgrade server resources. Coins are earned from daily rewards and referrals.
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {COIN_ITEMS.map(c => (
              <div key={c.item} className="card flex items-center justify-between">
                <div>
                  <div className="font-semibold">{c.label}</div>
                  <div className="text-sm" style={{ color: 'rgb(var(--text-muted))' }}>+{c.unit}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-forge-500">{c.coinsEach} 🪙</div>
                  <button onClick={() => buyCoins(c.item, c.amount)}
                    disabled={user?.coins < c.coinsEach}
                    className="btn-primary text-xs mt-1 py-1 px-3">Buy</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transaction history */}
      <div>
        <h2 className="font-semibold mb-3">Transaction History</h2>
        {txs.length === 0 ? (
          <div className="card text-center py-8 text-sm" style={{ color: 'rgb(var(--text-muted))' }}>No transactions yet</div>
        ) : (
          <div className="space-y-2">
            {txs.map(tx => (
              <div key={tx.uuid} className="card flex items-center justify-between text-sm">
                <div>
                  <div className="font-medium">{tx.description}</div>
                  <div style={{ color: 'rgb(var(--text-muted))' }}>{new Date(tx.created_at).toLocaleString()}</div>
                </div>
                <div className="text-right">
                  {statusBadge(tx.status)}
                  {tx.credits_given > 0 && <div className="text-green-500 font-bold mt-1">+{tx.credits_given} credits</div>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
