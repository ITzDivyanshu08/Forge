import { useEffect, useState } from 'react';
import api from '../../lib/api';
import { Link2, Copy, Check, Users, Coins } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function Referral() {
  const [data, setData] = useState(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/referral').then(r => setData(r.data)).finally(() => setLoading(false));
  }, []);

  const copy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  const refLink = `${window.location.origin}/auth/register?ref=${data?.code}`;

  return (
    <div className="max-w-lg space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Referrals</h1>
        <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>
          Invite friends and earn coins when they join
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="card text-center">
          <Users size={20} className="mx-auto mb-1 text-forge-500" />
          <div className="text-2xl font-bold">{data?.count || 0}</div>
          <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>Total Referrals</div>
        </div>
        <div className="card text-center">
          <div className="text-2xl font-bold text-forge-500">{data?.totalCoins?.toLocaleString() || 0}</div>
          <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>🪙 Coins Earned</div>
        </div>
      </div>

      <div className="card space-y-3">
        <h2 className="font-semibold">Your Referral Link</h2>
        <div className="flex gap-2">
          <input className="input font-mono text-xs" readOnly value={refLink} />
          <button onClick={() => copy(refLink)} className="btn-secondary shrink-0 px-3">
            {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
          </button>
        </div>
        <div className="flex gap-2">
          <div className="flex-1 card bg-forge-500/5 border-forge-500/20 text-center py-3">
            <div className="font-bold text-forge-500">200 🪙</div>
            <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>You earn per referral</div>
          </div>
          <div className="flex-1 card bg-green-500/5 border-green-500/20 text-center py-3">
            <div className="font-bold text-green-500">100 🪙</div>
            <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>They earn on signup</div>
          </div>
        </div>
      </div>

      {data?.referrals?.length > 0 && (
        <div className="card space-y-3">
          <h2 className="font-semibold">Referral History</h2>
          <div className="space-y-2">
            {data.referrals.map(r => (
              <div key={r.id} className="flex items-center justify-between text-sm">
                <div>
                  <div className="font-medium">{r.username}</div>
                  <div style={{ color: 'rgb(var(--text-muted))' }}>{new Date(r.joined_at).toLocaleDateString()}</div>
                </div>
                <div className="badge badge-yellow">+{r.coins_given} 🪙</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
