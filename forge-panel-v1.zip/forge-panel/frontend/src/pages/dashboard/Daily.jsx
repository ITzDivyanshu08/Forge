// Daily.jsx
import { useEffect, useState } from 'react';
import api from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { Gift, Flame, Star } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function Daily() {
  const { user, refresh } = useAuth();
  const [info, setInfo] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    Promise.all([
      api.get('/daily/info').then(r => setInfo(r.data)),
    ]).finally(() => setLoading(false));
  }, []);

  const claim = async () => {
    setClaiming(true); setMsg('');
    try {
      const r = await api.post('/daily/claim');
      await refresh();
      setInfo(d => ({ ...d, can: false, streak: r.data.streak }));
      setMsg(`🎉 Claimed ${r.data.coinsEarned} coins! ${r.data.streak}-day streak!`);
    } catch (e) {
      setMsg(e.response?.data?.error || 'Failed');
    } finally { setClaiming(false); }
  };

  const formatTime = (mins) => {
    if (!mins) return '';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  const streakDays = [1,2,3,4,5,6,7,14,30];

  return (
    <div className="max-w-lg space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Daily Reward</h1>
        <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>
          Claim every day to build your streak and earn bonus coins
        </p>
      </div>

      {/* Streak card */}
      <div className="card text-center space-y-4">
        <div className="flex items-center justify-center gap-2 text-4xl font-bold">
          <Flame className="text-forge-500" size={36} />
          <span>{info?.streak || 0}</span>
        </div>
        <div style={{ color: 'rgb(var(--text-muted))' }}>Day Streak</div>

        {info?.multiplier > 1 && (
          <div className="badge badge-yellow mx-auto text-sm py-1 px-4">{info.multiplier}x bonus active!</div>
        )}

        <div className="text-lg font-semibold">Next reward: <span className="text-forge-500">{info?.nextReward} 🪙</span></div>

        {info?.can ? (
          <button onClick={claim} disabled={claiming} className="btn-primary w-full justify-center py-3 text-base">
            <Gift size={18} /> {claiming ? 'Claiming...' : 'Claim Daily Reward'}
          </button>
        ) : (
          <div className="card bg-forge-500/5 border-forge-500/20 text-center">
            <div className="text-sm" style={{ color: 'rgb(var(--text-muted))' }}>Next claim in</div>
            <div className="text-2xl font-bold text-forge-500">{formatTime(info?.nextIn)}</div>
          </div>
        )}

        {msg && <div className={`text-sm ${msg.startsWith('🎉') ? 'text-green-500' : 'text-red-500'}`}>{msg}</div>}
      </div>

      {/* Streak milestones */}
      <div className="card space-y-3">
        <h2 className="font-semibold">Streak Milestones</h2>
        <div className="space-y-2">
          {[
            { days: 7,  mult: '1.5x', label: '7-day streak', coins: Math.floor(25 * 1.5) },
            { days: 14, mult: '2x',   label: '14-day streak', coins: Math.floor(25 * 2) },
            { days: 30, mult: '3x',   label: '30-day streak', coins: Math.floor(25 * 3) },
          ].map(m => {
            const reached = (info?.streak || 0) >= m.days;
            return (
              <div key={m.days} className={`flex items-center justify-between p-3 rounded-lg border ${reached ? 'border-forge-500/30 bg-forge-500/5' : ''}`}
                style={{ borderColor: reached ? undefined : 'rgb(var(--border))' }}>
                <div className="flex items-center gap-2">
                  <Star size={16} className={reached ? 'text-forge-500' : ''} style={{ color: reached ? undefined : 'rgb(var(--text-muted))' }} />
                  <span className="text-sm font-medium">{m.label}</span>
                </div>
                <div className="text-right">
                  <div className="badge badge-yellow">{m.mult} bonus</div>
                  <div className="text-xs mt-0.5" style={{ color: 'rgb(var(--text-muted))' }}>{m.coins} coins/day</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
