import { useEffect, useState } from 'react';
import api from '../../lib/api';
import { Globe, Plus, Trash2, X } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function Subdomains() {
  const [data, setData] = useState({ subdomains: [], domains: [] });
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ serverId: '', subdomain: '', domain: '', target: '' });
  const [msg, setMsg] = useState('');

  const load = () => {
    Promise.all([
      api.get('/subdomains').then(r => setData(r.data)),
      api.get('/servers').then(r => setServers(r.data)),
    ]).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const create = async e => {
    e.preventDefault(); setMsg('');
    try {
      await api.post('/subdomains', form);
      setShowForm(false);
      load();
    } catch (e) { setMsg(e.response?.data?.error || 'Failed'); }
  };

  const del = async (id) => {
    if (!confirm('Delete this subdomain?')) return;
    await api.delete(`/subdomains/${id}`).catch(() => {});
    load();
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Subdomains</h1>
          <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>Manage Cloudflare subdomains for your servers</p>
        </div>
        {data.domains.length > 0 && (
          <button onClick={() => setShowForm(s => !s)} className="btn-primary">
            <Plus size={14} /> Add
          </button>
        )}
      </div>

      {data.domains.length === 0 && (
        <div className="card text-center py-8">
          <Globe size={32} className="mx-auto mb-2 opacity-40" />
          <div className="font-medium">Cloudflare not configured</div>
          <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>Enable Cloudflare in config.toml to use subdomains</p>
        </div>
      )}

      {showForm && (
        <form onSubmit={create} className="card space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">New Subdomain</h2>
            <button type="button" onClick={() => setShowForm(false)}><X size={16} /></button>
          </div>
          {msg && <div className="badge badge-red w-full justify-center py-2">{msg}</div>}
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="text-sm font-medium block mb-1">Server</label>
              <select className="input" value={form.serverId} onChange={e => setForm(f => ({ ...f, serverId: e.target.value }))} required>
                <option value="">Select server...</option>
                {servers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium block mb-1">Domain</label>
              <select className="input" value={form.domain} onChange={e => setForm(f => ({ ...f, domain: e.target.value }))} required>
                <option value="">Select domain...</option>
                {data.domains.map(d => <option key={d.domain} value={d.domain}>{d.domain}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium block mb-1">Subdomain</label>
              <input className="input" placeholder="myserver" value={form.subdomain}
                onChange={e => setForm(f => ({ ...f, subdomain: e.target.value }))} required />
            </div>
            <div>
              <label className="text-sm font-medium block mb-1">Target (CNAME)</label>
              <input className="input" placeholder="node1.example.com" value={form.target}
                onChange={e => setForm(f => ({ ...f, target: e.target.value }))} required />
            </div>
          </div>
          <button type="submit" className="btn-primary w-full justify-center">Create Subdomain</button>
        </form>
      )}

      <div className="space-y-2">
        {data.subdomains.map(s => (
          <div key={s.id} className="card flex items-center justify-between">
            <div>
              <div className="font-medium font-mono text-sm">{s.subdomain}.{s.domain}</div>
              <div className="text-xs mt-0.5" style={{ color: 'rgb(var(--text-muted))' }}>→ {s.target}</div>
            </div>
            <button onClick={() => del(s.id)} className="p-2 text-red-500 hover:opacity-70"><Trash2 size={14} /></button>
          </div>
        ))}
        {data.subdomains.length === 0 && data.domains.length > 0 && (
          <div className="card text-center py-8 text-sm" style={{ color: 'rgb(var(--text-muted))' }}>
            No subdomains yet. Click Add to create one.
          </div>
        )}
      </div>
    </div>
  );
}
