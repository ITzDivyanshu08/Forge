import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import api from '../../lib/api';
import { Server, Cpu, HardDrive, MemoryStick, Gift, CreditCard, Link2, Zap, AlertTriangle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import Spinner from '../../components/ui/Spinner';

function StatCard({ icon: Icon, label, value, sub, color = 'forge' }) {
  const colors = {
    forge: 'text-forge-500 bg-forge-500/10',
    green: 'text-green-500 bg-green-500/10',
    blue: 'text-blue-500 bg-blue-500/10',
    purple: 'text-purple-500 bg-purple-500/10',
  };
  return (
    <div className="card flex items-center gap-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colors[color]}`}>
        <Icon size={18} />
      </div>
      <div>
        <div className="text-xl font-bold">{value}</div>
        <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>{label}</div>
        {sub && <div className="text-xs text-forge-500 mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user, refresh } = useAuth();
  const [servers, setServers] = useState([]);
  const [daily, setDaily] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/servers').then(r => setServers(r.data)),
      api.get('/daily/info').then(r => setDaily(r.data)),
    ]).finally(() => setLoading(false));
  }, []);

  const claimDaily = async () => {
    try {
      const r = await api.post('/daily/claim');
      await refresh();
      setDaily(d => ({ ...d, can: false, streak: r.data.streak }));
      alert(`🎉 Claimed ${r.data.coinsEarned} coins! (${r.data.streak} day streak)`);
    } catch (e) {
      alert(e.response?.data?.error || 'Failed to claim');
    }
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  const runningServers = servers.filter(s => s.stats?.current_state === 'running').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">
          Welcome back, {user?.username} 👋
        </h1>
        <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>
          Here's what's happening with your servers
        </p>
      </div>

      {/* Daily reward banner */}
      {daily?.can && (
        <div className="card border-forge-500/30 bg-forge-500/5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-forge-500/20 rounded-lg flex items-center justify-center text-forge-500">
              <Gift size={20} />
            </div>
            <div>
              <div className="font-semibold">Daily reward available!</div>
              <div className="text-sm" style={{ color: 'rgb(var(--text-muted))' }}>
                Claim {daily.nextReward} coins • {daily.streak}-day streak
                {daily.multiplier > 1 && <span className="ml-1 badge badge-yellow">{daily.multiplier}x bonus</span>}
              </div>
            </div>
          </div>
          <button onClick={claimDaily} className="btn-primary shrink-0">
            <Gift size={14} /> Claim
          </button>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={Server} label="Total Servers" value={servers.length} sub={`${runningServers} running`} color="forge" />
        <StatCard icon={MemoryStick} label="RAM Limit" value={`${user?.ram >= 1024 ? (user.ram / 1024).toFixed(1) + ' GB' : user?.ram + ' MB'}`} color="blue" />
        <StatCard icon={HardDrive} label="Disk Limit" value={`${user?.disk >= 1024 ? (user.disk / 1024).toFixed(1) + ' GB' : user?.disk + ' MB'}`} color="green" />
        <StatCard icon={Cpu} label="CPU Limit" value={`${user?.cpu}%`} color="purple" />
      </div>

      {/* Balance cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="card text-center">
          <div className="text-3xl font-bold text-forge-500">{user?.coins?.toLocaleString()}</div>
          <div className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>🪙 Coins</div>
          <Link to="/daily" className="btn-secondary mt-3 text-xs justify-center">Earn more</Link>
        </div>
        <div className="card text-center">
          <div className="text-3xl font-bold text-green-500">{user?.credits?.toLocaleString()}</div>
          <div className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>💳 Credits</div>
          <Link to="/billing" className="btn-secondary mt-3 text-xs justify-center">Top up</Link>
        </div>
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="font-semibold mb-3">Quick actions</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { to: '/servers', icon: Server, label: 'New Server', color: 'bg-forge-500' },
            { to: '/billing', icon: CreditCard, label: 'Top Up', color: 'bg-green-500' },
            { to: '/daily', icon: Gift, label: 'Daily Reward', color: 'bg-yellow-500' },
            { to: '/referral', icon: Link2, label: 'Referrals', color: 'bg-purple-500' },
          ].map(({ to, icon: Icon, label, color }) => (
            <Link key={to} to={to} className="card hover:scale-[1.02] transition-transform text-center">
              <div className={`w-10 h-10 ${color} rounded-lg flex items-center justify-center mx-auto mb-2`}>
                <Icon size={18} className="text-white" />
              </div>
              <div className="text-sm font-medium">{label}</div>
            </Link>
          ))}
        </div>
      </div>

      {/* Servers list */}
      {servers.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Your Servers</h2>
            <Link to="/servers" className="text-sm text-forge-500 hover:underline">View all</Link>
          </div>
          <div className="space-y-2">
            {servers.slice(0, 5).map(s => {
              const state = s.stats?.current_state || 'unknown';
              const expiry = s.expires_at ? new Date(s.expires_at) : null;
              const daysLeft = expiry ? Math.floor((expiry - Date.now()) / 86400000) : null;
              return (
                <Link key={s.uuid} to={`/servers/${s.uuid}/console`}
                  className="card flex items-center justify-between hover:border-forge-500/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${state === 'running' ? 'bg-green-500' : state === 'offline' ? 'bg-red-500' : 'bg-yellow-500'}`} />
                    <div>
                      <div className="font-medium text-sm">{s.name}</div>
                      <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>
                        {s.ram}MB RAM • {s.disk}MB Disk • {s.cpu}% CPU
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`badge ${state === 'running' ? 'badge-green' : state === 'offline' ? 'badge-red' : 'badge-yellow'}`}>
                      {state}
                    </div>
                    {daysLeft !== null && daysLeft <= 3 && (
                      <div className="badge badge-red mt-1">
                        <AlertTriangle size={10} /> {daysLeft}d left
                      </div>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      )}

      {servers.length === 0 && (
        <div className="card text-center py-12">
          <Server size={40} className="mx-auto mb-3 text-forge-500 opacity-50" />
          <div className="font-semibold">No servers yet</div>
          <p className="text-sm mt-1 mb-4" style={{ color: 'rgb(var(--text-muted))' }}>Create your first game server to get started</p>
          <Link to="/servers" className="btn-primary">Create Server</Link>
        </div>
      )}
    </div>
  );
}
