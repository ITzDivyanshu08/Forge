import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../../lib/api';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function AdminTx() {
  const [params] = useSearchParams();
  const [txs, setTxs] = useState([]);
  const [filter, setFilter] = useState(params.get('status') || '');
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    api.get(`/admin/transactions${filter ? `?status=${filter}` : ''}`).then(r => setTxs(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [filter]);

  const confirm = async (uuid) => {
    try {
      await api.post(`/admin/transactions/${uuid}/confirm`);
      setMsg('✅ Payment confirmed and credits added');
      load();
      setTimeout(() => setMsg(''), 3000);
    } catch (e) { setMsg(e.response?.data?.error || 'Failed'); }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Transactions</h1>
      {msg && <div className="card text-sm py-2 text-center text-green-500">{msg}</div>}

      <div className="flex gap-2 flex-wrap">
        {['', 'pending', 'verifying', 'completed', 'failed'].map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter === s ? 'bg-forge-500 text-white' : 'btn-secondary'}`}>
            {s || 'All'}
          </button>
        ))}
      </div>

      {loading ? <div className="flex justify-center py-10"><Spinner size={24} /></div> : (
        <div className="space-y-2">
          {txs.map(tx => (
            <div key={tx.uuid} className="card flex items-center justify-between gap-3 flex-wrap">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm">{tx.username}</span>
                  <span className="badge badge-blue">{tx.gateway}</span>
                  {tx.status === 'verifying' && <span className="badge badge-yellow"><AlertCircle size={10} /> Needs Review</span>}
                  {tx.status === 'completed' && <span className="badge badge-green"><CheckCircle size={10} /> Done</span>}
                  {tx.status === 'pending' && <span className="badge badge-blue"><Clock size={10} /> Pending</span>}
                </div>
                <div className="text-xs mt-1" style={{ color: 'rgb(var(--text-muted))' }}>
                  {tx.description} • {new Date(tx.created_at).toLocaleString()}
                </div>
                {tx.upi_ref && <div className="text-xs font-mono mt-0.5 text-forge-500">UPI Ref: {tx.upi_ref}</div>}
              </div>
              <div className="text-right shrink-0">
                <div className="font-bold">{tx.currency} {tx.amount}</div>
                <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>+{tx.credits_given} credits</div>
                {tx.status === 'verifying' && (
                  <button onClick={() => confirm(tx.uuid)} className="btn-primary text-xs py-1 mt-1">
                    Confirm
                  </button>
                )}
              </div>
            </div>
          ))}
          {txs.length === 0 && (
            <div className="card text-center py-8 text-sm" style={{ color: 'rgb(var(--text-muted))' }}>No transactions found</div>
          )}
        </div>
      )}
    </div>
  );
}
