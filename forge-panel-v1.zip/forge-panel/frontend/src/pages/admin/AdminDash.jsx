// AdminDash.jsx
import { useEffect, useState } from 'react';
import api from '../../lib/api';
import { Users, Server, DollarSign, AlertCircle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function AdminDash() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get('/admin/stats').then(r => setStats(r.data));
  }, []);

  if (!stats) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { icon: Users,        label: 'Total Users',   value: stats.users,     color: 'text-blue-500 bg-blue-500/10' },
          { icon: Server,       label: 'Total Servers', value: stats.servers,   color: 'text-forge-500 bg-forge-500/10' },
          { icon: AlertCircle,  label: 'Suspended',     value: stats.suspended, color: 'text-red-500 bg-red-500/10' },
          { icon: DollarSign,   label: 'Revenue',       value: `₹${stats.revenue?.toFixed(0)}`, color: 'text-green-500 bg-green-500/10' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="card flex items-center gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}><Icon size={18} /></div>
            <div>
              <div className="text-xl font-bold">{value}</div>
              <div className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {stats.pendingUpi > 0 && (
        <div className="card border-yellow-500/30 bg-yellow-500/5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-yellow-600 dark:text-yellow-400">
            <AlertCircle size={16} />
            <span className="font-medium">{stats.pendingUpi} UPI payment(s) awaiting verification</span>
          </div>
          <a href="/admin/transactions?status=verifying" className="btn-secondary text-xs py-1">Review</a>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card space-y-3">
          <h2 className="font-semibold">Recent Users</h2>
          <div className="space-y-2">
            {stats.recentUsers.map(u => (
              <div key={u.id} className="flex items-center justify-between text-sm">
                <div>
                  <div className="font-medium">{u.username}</div>
                  <div style={{ color: 'rgb(var(--text-muted))' }}>{u.email}</div>
                </div>
                <div className="text-right text-xs" style={{ color: 'rgb(var(--text-muted))' }}>
                  {new Date(u.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card space-y-3">
          <h2 className="font-semibold">Recent Activity</h2>
          <div className="space-y-2">
            {stats.recentActivity.map(a => (
              <div key={a.id} className="text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs badge badge-blue">{a.action}</span>
                  <span className="text-xs" style={{ color: 'rgb(var(--text-muted))' }}>{new Date(a.created_at).toLocaleTimeString()}</span>
                </div>
                {a.details && <div className="text-xs mt-0.5 truncate" style={{ color: 'rgb(var(--text-muted))' }}>{a.details}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
