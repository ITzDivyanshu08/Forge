// AdminUsers.jsx
import { useEffect, useState } from 'react';
import api from '../../lib/api';
import { Search, Edit2, Check, X } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [msg, setMsg] = useState('');

  const load = (q = '') => {
    setLoading(true);
    api.get(`/admin/users${q ? `?search=${q}` : ''}`).then(r => setUsers(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const startEdit = (u) => { setEditing(u.id); setEditForm({ coins: u.coins, credits: u.credits, ram: u.ram, disk: u.disk, cpu: u.cpu, servers: u.servers, is_admin: u.is_admin, is_banned: u.is_banned }); };

  const save = async (id) => {
    try {
      await api.patch(`/admin/users/${id}`, editForm);
      setMsg('✅ Saved'); setEditing(null); load(search);
      setTimeout(() => setMsg(''), 2000);
    } catch (e) { setMsg(e.response?.data?.error || 'Failed'); }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Users</h1>
      {msg && <div className="card text-sm py-2 text-center text-green-500">{msg}</div>}

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'rgb(var(--text-muted))' }} />
          <input className="input pl-8" placeholder="Search users..."
            value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && load(search)} />
        </div>
        <button onClick={() => load(search)} className="btn-primary px-4">Search</button>
      </div>

      {loading ? <div className="flex justify-center py-10"><Spinner size={24} /></div> : (
        <div className="space-y-2">
          {users.map(u => (
            <div key={u.id} className="card space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-medium flex items-center gap-2">
                    {u.username}
                    {u.is_admin ? <span className="badge badge-red">Admin</span> : null}
                    {u.is_banned ? <span className="badge badge-red">Banned</span> : null}
                    {u.discord_id ? <span className="badge badge-blue">Discord</span> : null}
                  </div>
                  <div className="text-xs mt-0.5" style={{ color: 'rgb(var(--text-muted))' }}>{u.email} • #{u.id}</div>
                </div>
                {editing === u.id ? (
                  <div className="flex gap-1">
                    <button onClick={() => save(u.id)} className="p-1.5 text-green-500 hover:opacity-70"><Check size={14} /></button>
                    <button onClick={() => setEditing(null)} className="p-1.5 text-red-500 hover:opacity-70"><X size={14} /></button>
                  </div>
                ) : (
                  <button onClick={() => startEdit(u)} className="p-1.5 hover:opacity-70"><Edit2 size={14} /></button>
                )}
              </div>

              {editing === u.id ? (
                <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
                  {['coins','credits','ram','disk','cpu','servers'].map(field => (
                    <div key={field}>
                      <label className="text-xs block mb-1 capitalize">{field}</label>
                      <input className="input text-xs py-1" type="number" value={editForm[field]}
                        onChange={e => setEditForm(f => ({ ...f, [field]: +e.target.value }))} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-wrap gap-2 text-xs">
                  <span className="badge badge-yellow">{u.coins} 🪙</span>
                  <span className="badge badge-green">{u.credits} 💳</span>
                  <span className="badge badge-blue">{u.ram}MB RAM</span>
                  <span className="badge badge-blue">{u.disk}MB Disk</span>
                  <span className="badge badge-blue">{u.cpu}% CPU</span>
                  <span className="badge badge-blue">{u.servers} servers</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
