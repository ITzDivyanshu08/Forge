import { useEffect, useRef, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../../lib/api';
import { Terminal, Play, Square, RotateCcw, Files, HardDrive, ArrowLeft } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function Console() {
  const { uuid } = useParams();
  const termRef = useRef(null);
  const fitRef = useRef(null);
  const wsRef = useRef(null);
  const termInstanceRef = useRef(null);
  const [server, setServer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cmd, setCmd] = useState('');
  const [status, setStatus] = useState('connecting');

  useEffect(() => {
    api.get('/servers').then(r => {
      const s = r.data.find(s => s.uuid === uuid);
      setServer(s);
    }).finally(() => setLoading(false));
  }, [uuid]);

  useEffect(() => {
    if (!server || !termRef.current) return;
    let term, fitAddon;

    const initTerm = async () => {
      const { Terminal } = await import('xterm');
      const { FitAddon } = await import('xterm-addon-fit');
      await import('xterm/css/xterm.css');

      term = new Terminal({
        theme: { background: '#0a0a0a', foreground: '#e5e7eb', cursor: '#f97316' },
        fontFamily: 'JetBrains Mono, Fira Code, monospace',
        fontSize: 13,
        lineHeight: 1.4,
        scrollback: 5000,
      });
      fitAddon = new FitAddon();
      term.loadAddon(fitAddon);
      term.open(termRef.current);
      fitAddon.fit();
      termInstanceRef.current = term;
      fitRef.current = fitAddon;

      term.writeln('\x1b[33m⚒ Forge Panel — Connecting to server console...\x1b[0m');

      try {
        const r = await api.get(`/servers/${uuid}/ws`);
        const { socket, token } = r.data;
        const ws = new WebSocket(socket);
        wsRef.current = ws;

        ws.onopen = () => {
          ws.send(JSON.stringify({ event: 'auth', args: [token] }));
          setStatus('connected');
          term.writeln('\x1b[32m✓ Connected\x1b[0m');
        };

        ws.onmessage = ({ data }) => {
          try {
            const msg = JSON.parse(data);
            if (msg.event === 'console output') {
              msg.args.forEach(line => term.writeln(line));
            } else if (msg.event === 'status') {
              setStatus(msg.args[0]);
            }
          } catch {}
        };

        ws.onerror = () => {
          setStatus('error');
          term.writeln('\x1b[31m✗ WebSocket error\x1b[0m');
        };

        ws.onclose = () => {
          setStatus('disconnected');
          term.writeln('\x1b[33m⚠ Disconnected\x1b[0m');
        };
      } catch (e) {
        term.writeln(`\x1b[31m✗ Failed to get WebSocket credentials: ${e.message}\x1b[0m`);
        setStatus('error');
      }
    };

    initTerm();

    const ro = new ResizeObserver(() => fitRef.current?.fit());
    ro.observe(termRef.current);

    return () => {
      wsRef.current?.close();
      termInstanceRef.current?.dispose();
      ro.disconnect();
    };
  }, [server]);

  const sendCmd = async () => {
    if (!cmd.trim()) return;
    try {
      await api.post(`/servers/${uuid}/power`, { action: 'send_command' }).catch(() => {});
      // Try via WebSocket first
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ event: 'send command', args: [cmd] }));
      }
    } catch {}
    setCmd('');
  };

  const power = async (action) => {
    await api.post(`/servers/${uuid}/power`, { action }).catch(() => {});
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;
  if (!server) return <div className="card text-center py-12">Server not found</div>;

  const statusColor = {
    connected: 'badge-green', connecting: 'badge-yellow',
    disconnected: 'badge-red', error: 'badge-red',
  }[status] || 'badge-yellow';

  return (
    <div className="space-y-4 h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 flex-wrap">
        <Link to="/servers" className="btn-secondary py-1.5 px-3 text-xs"><ArrowLeft size={12} /> Back</Link>
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-bold truncate">{server.name}</h1>
        </div>
        <div className={`badge ${statusColor}`}>{status}</div>
        <div className="flex gap-2">
          <button onClick={() => power('start')} className="btn-secondary py-1.5 px-3 text-green-500 text-xs"><Play size={12} /> Start</button>
          <button onClick={() => power('restart')} className="btn-secondary py-1.5 px-3 text-yellow-500 text-xs"><RotateCcw size={12} /> Restart</button>
          <button onClick={() => power('stop')} className="btn-secondary py-1.5 px-3 text-red-500 text-xs"><Square size={12} /> Stop</button>
        </div>
        <Link to={`/servers/${uuid}/files`} className="btn-secondary py-1.5 px-3 text-xs"><Files size={12} /> Files</Link>
      </div>

      {/* Terminal */}
      <div className="flex-1 card p-0 overflow-hidden min-h-[400px]">
        <div ref={termRef} className="w-full h-full" style={{ minHeight: 400 }} />
      </div>

      {/* Command input */}
      <div className="flex gap-2">
        <input className="input font-mono text-sm"
          placeholder="Enter command and press Enter..."
          value={cmd}
          onChange={e => setCmd(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendCmd()} />
        <button onClick={sendCmd} className="btn-primary px-4 shrink-0">Send</button>
      </div>
    </div>
  );
}
