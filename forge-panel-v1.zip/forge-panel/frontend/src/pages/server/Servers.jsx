// Servers.jsx - full server list with create modal
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { Server, Plus, Play, Square, RotateCcw, Trash2, RefreshCw, X, AlertTriangle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

function CreateModal({ onClose, onCreated }) {
  const { user } = useAuth();
  const [eggs, setEggs] = useState([]);
  const [nodes, setNodes] = useState([]);
  const [form, setForm] = useState({ name: '', egg: '', node: '', ram: 1024, disk: 5120, cpu: 100 });
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      api.get('/eggs').then(r => setEggs(r.data)),
      api.get('/nodes').then(r => setNodes(r.data)),
    ]).finally(() => setFetching(false));
  }, []);

  const submit = async e => {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      await api.post('/servers', form);
      onCreated();
      onClose();
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to create server');
    } finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="card w-full max-w-md max-h-[90vh] overflow-y-auto space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-lg">Create Server</h2>
          <button onClick={onClose} className="p-1 hover:opacity-70"><X size={18} /></button>
        </div>

        {fetching ? <div className="flex justify-center py-8"><Spinner /></div> : (
          <form onSubmit={submit} className="space-y-4">
            {error && <div className="badge badge-red w-full justify-center py-2">{error}</div>}

            <div>
              <label className="text-sm font-medium block mb-1">Server Name</label>
              <input className="input" placeholder="My Minecraft Server" value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
            </div>

            <div>
              <label className="text-sm font-medium block mb-1">Game / Egg</label>
              <select className="input" value={form.egg} onChange={e => setForm(f => ({ ...f, egg: e.target.value }))} required>
                <option value="">Select game...</option>
                {eggs.map(egg => <option key={egg.id} value={egg.id}>{egg.name}</option>)}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium block mb-1">Node</label>
              <select className="input" value={form.node} onChange={e => setForm(f => ({ ...f, node: e.target.value }))}>
                <option value="">Auto-select</option>
                {nodes.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
              </select>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-sm font-medium block mb-1">RAM (MB)</label>
                <input className="input" type="number" min="512" max={user?.ram} step="512"
                  value={form.ram} onChange={e => setForm(f => ({ ...f, ram: +e.target.value }))} />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1">Disk (MB)</label>
                <input className="input" type="number" min="1024" max={user?.disk} step="1024"
                  value={form.disk} onChange={e => setForm(f => ({ ...f, disk: +e.target.value }))} />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1">CPU (%)</label>
                <input className="input" type="number" min="10" max={user?.cpu} step="10"
                  value={form.cpu} onChange={e => setForm(f => ({ ...f, cpu: +e.target.value }))} />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" disabled={loading} className="btn-primary flex-1">
                {loading ? 'Creating...' : 'Create Server'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default function Servers() {
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [actionMsg, setActionMsg] = useState('');

  const load = () => {
    setLoading(true);
    api.get('/servers').then(r => setServers(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const power = async (uuid, action) => {
    try {
      await api.post(`/servers/${uuid}/power`, { action });
      setActionMsg(`${action} sent`);
      setTimeout(() => setActionMsg(''), 2000);
    } catch (e) { setActionMsg(e.response?.data?.error || 'Failed'); }
  };

  const del = async (uuid, name) => {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
    try {
      await api.delete(`/servers/${uuid}`);
      load();
    } catch (e) { alert(e.response?.data?.error || 'Failed'); }
  };

  const renew = async (uuid) => {
    try {
      const r = await api.post(`/servers/${uuid}/renew`);
      alert(`✅ Renewed for ${r.data.cost} credits (+${r.data.days} days)`);
      load();
    } catch (e) { alert(e.response?.data?.error || 'Failed'); }
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={32} /></div>;

  return (
    <div className="space-y-6">
      {showCreate && <CreateModal onClose={() => setShowCreate(false)} onCreated={load} />}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Servers</h1>
          <p className="text-sm mt-1" style={{ color: 'rgb(var(--text-muted))' }}>{servers.length} server{servers.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="btn-secondary"><RefreshCw size={14} /></button>
          <button onClick={() => setShowCreate(true)} className="btn-primary"><Plus size={14} /> New Server</button>
        </div>
      </div>

      {actionMsg && <div className="card text-sm text-center py-2 border-forge-500/30 text-forge-500">{actionMsg}</div>}

      {servers.length === 0 ? (
        <div className="card text-center py-16">
          <Server size={48} className="mx-auto mb-4 text-forge-500 opacity-40" />
          <div className="font-semibold text-lg">No servers yet</div>
          <p className="text-sm mt-2 mb-6" style={{ color: 'rgb(var(--text-muted))' }}>Create your first server to get started</p>
          <button onClick={() => setShowCreate(true)} className="btn-primary mx-auto">
            <Plus size={14} /> Create Server
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {servers.map(s => {
            const state = s.stats?.current_state || 'offline';
            const expiry = s.expires_at ? new Date(s.expires_at) : null;
            const daysLeft = expiry ? Math.floor((expiry - Date.now()) / 86400000) : null;
            const mem = s.stats?.resources?.memory_bytes;
            const memPct = mem ? Math.round(mem / 1024 / 1024 / s.ram * 100) : 0;
            const cpu = s.stats?.resources?.cpu_absolute;

            return (
              <div key={s.uuid} className="card space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{s.name}</div>
                    <div className="text-xs mt-0.5" style={{ color: 'rgb(var(--text-muted))' }}>
                      {s.ram}MB · {s.disk}MB · {s.cpu}%
                    </div>
                  </div>
                  <div className={`badge ml-2 shrink-0 ${state === 'running' ? 'badge-green' : state === 'starting' ? 'badge-yellow' : 'badge-red'}`}>
                    {state}
                  </div>
                </div>

                {daysLeft !== null && daysLeft <= 5 && (
                  <div className={`badge w-full justify-center py-1 ${daysLeft <= 0 ? 'badge-red' : 'badge-yellow'}`}>
                    <AlertTriangle size={10} />
                    {daysLeft <= 0 ? 'Expired' : `Expires in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}`}
                  </div>
                )}

                {state === 'running' && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs" style={{ color: 'rgb(var(--text-muted))' }}>
                      <span>RAM</span><span>{memPct}%</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgb(var(--border))' }}>
                      <div className="h-full bg-forge-500 rounded-full transition-all" style={{ width: `${memPct}%` }} />
                    </div>
                    <div className="flex justify-between text-xs" style={{ color: 'rgb(var(--text-muted))' }}>
                      <span>CPU</span><span>{cpu?.toFixed(1)}%</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgb(var(--border))' }}>
                      <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${Math.min(cpu || 0, 100)}%` }} />
                    </div>
                  </div>
                )}

                <div className="flex gap-2 flex-wrap">
                  <Link to={`/servers/${s.uuid}/console`} className="btn-secondary flex-1 text-xs justify-center py-1.5">Console</Link>
                  <Link to={`/servers/${s.uuid}/files`} className="btn-secondary flex-1 text-xs justify-center py-1.5">Files</Link>
                </div>

                <div className="flex gap-1">
                  <button onClick={() => power(s.uuid, 'start')} disabled={state === 'running'} title="Start"
                    className="btn-secondary flex-1 justify-center py-1.5 text-green-500 disabled:opacity-30"><Play size={12} /></button>
                  <button onClick={() => power(s.uuid, 'restart')} title="Restart"
                    className="btn-secondary flex-1 justify-center py-1.5 text-yellow-500"><RotateCcw size={12} /></button>
                  <button onClick={() => power(s.uuid, 'stop')} disabled={state === 'offline'} title="Stop"
                    className="btn-secondary flex-1 justify-center py-1.5 text-red-500 disabled:opacity-30"><Square size={12} /></button>
                  <button onClick={() => renew(s.uuid)} title="Renew"
                    className="btn-secondary flex-1 justify-center py-1.5 text-forge-500"><RefreshCw size={12} /></button>
                  <button onClick={() => del(s.uuid, s.name)} title="Delete"
                    className="btn-secondary flex-1 justify-center py-1.5 text-red-500"><Trash2 size={12} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
