// Files.jsx
import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../../lib/api';
import { ArrowLeft, Folder, File, ArrowUp } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';

export default function Files() {
  const { uuid } = useParams();
  const [files, setFiles] = useState([]);
  const [dir, setDir] = useState('/');
  const [loading, setLoading] = useState(true);

  const load = (path) => {
    setLoading(true);
    api.get(`/servers/${uuid}/files?dir=${encodeURIComponent(path || dir)}`)
      .then(r => { setFiles(r.data); setDir(path || dir); })
      .catch(() => setFiles([]))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load('/'); }, [uuid]);

  const navigate = (f) => {
    if (f.is_file) return;
    load(dir.endsWith('/') ? dir + f.name : dir + '/' + f.name);
  };

  const goUp = () => {
    const parts = dir.split('/').filter(Boolean);
    parts.pop();
    load('/' + parts.join('/') || '/');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Link to={`/servers/${uuid}/console`} className="btn-secondary py-1.5 px-3 text-xs"><ArrowLeft size={12} /> Console</Link>
        <h1 className="font-bold text-lg">Files</h1>
        <code className="text-xs px-2 py-1 rounded" style={{ background: 'rgb(var(--border))' }}>{dir}</code>
      </div>
      <div className="card divide-y" style={{ divideColor: 'rgb(var(--border))' }}>
        {dir !== '/' && (
          <button onClick={goUp} className="w-full flex items-center gap-3 p-3 text-sm hover:bg-forge-500/5 transition-colors text-left">
            <ArrowUp size={16} style={{ color: 'rgb(var(--text-muted))' }} />
            <span style={{ color: 'rgb(var(--text-muted))' }}>..</span>
          </button>
        )}
        {loading ? (
          <div className="flex justify-center py-8"><Spinner /></div>
        ) : files.length === 0 ? (
          <div className="text-center py-8 text-sm" style={{ color: 'rgb(var(--text-muted))' }}>Empty directory</div>
        ) : files.map(f => (
          <button key={f.name} onClick={() => navigate(f)}
            className="w-full flex items-center gap-3 p-3 text-sm hover:bg-forge-500/5 transition-colors text-left">
            {f.is_file ? <File size={16} style={{ color: 'rgb(var(--text-muted))' }} /> : <Folder size={16} className="text-forge-500" />}
            <span className="flex-1 truncate">{f.name}</span>
            {f.is_file && <span className="text-xs shrink-0" style={{ color: 'rgb(var(--text-muted))' }}>{(f.size / 1024).toFixed(1)} KB</span>}
          </button>
        ))}
      </div>
    </div>
  );
}
