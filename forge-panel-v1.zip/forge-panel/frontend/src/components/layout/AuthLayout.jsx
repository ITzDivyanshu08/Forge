import { Outlet } from 'react-router-dom';
import { useTheme } from '../../hooks/useTheme';
import { Sun, Moon, Hammer } from 'lucide-react';

export default function AuthLayout() {
  const { theme, toggle } = useTheme();
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4" style={{ background: 'rgb(var(--bg))' }}>
      <button onClick={toggle} className="fixed top-4 right-4 p-2 rounded-lg card">
        {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
      </button>
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-10 h-10 bg-forge-500 rounded-xl flex items-center justify-center">
            <Hammer size={20} className="text-white" />
          </div>
          <span className="text-2xl font-bold">Forge Panel</span>
        </div>
        <Outlet />
      </div>
    </div>
  );
}
