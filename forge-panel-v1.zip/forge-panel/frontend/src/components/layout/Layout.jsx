import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useTheme } from '../../hooks/useTheme';
import {
  LayoutDashboard, Server, CreditCard, Gift, Link2,
  Globe, Users, Receipt, LogOut, Moon, Sun, Menu, X,
  Hammer, Shield, Zap,
} from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/servers', icon: Server, label: 'Servers' },
  { to: '/billing', icon: CreditCard, label: 'Billing' },
  { to: '/daily', icon: Gift, label: 'Daily Reward' },
  { to: '/referral', icon: Link2, label: 'Referrals' },
  { to: '/subdomains', icon: Globe, label: 'Subdomains' },
];

const adminItems = [
  { to: '/admin', icon: Shield, label: 'Overview' },
  { to: '/admin/users', icon: Users, label: 'Users' },
  { to: '/admin/transactions', icon: Receipt, label: 'Transactions' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);

  const avatar = user?.discord_avatar
    ? `https://cdn.discordapp.com/avatars/${user.discord_id}/${user.discord_avatar}.png?size=64`
    : `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.username || 'U')}&background=f97316&color=fff&size=64`;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile overlay */}
      {open && <div className="fixed inset-0 bg-black/50 z-20 lg:hidden" onClick={() => setOpen(false)} />}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-30 w-64 flex flex-col border-r transition-transform duration-200
        ${open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `} style={{ background: 'rgb(var(--bg-sidebar))', borderColor: 'rgb(var(--border))' }}>

        {/* Logo */}
        <div className="flex items-center gap-2 px-4 py-4 border-b" style={{ borderColor: 'rgb(var(--border))' }}>
          <div className="w-8 h-8 bg-forge-500 rounded-lg flex items-center justify-center">
            <Hammer size={16} className="text-white" />
          </div>
          <span className="font-bold text-lg">Forge Panel</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <Icon size={16} />
              <span>{label}</span>
            </NavLink>
          ))}

          {user?.is_admin && (
            <>
              <div className="mt-4 mb-2 px-3 text-xs font-semibold uppercase tracking-wider" style={{ color: 'rgb(var(--text-muted))' }}>
                Admin
              </div>
              {adminItems.map(({ to, icon: Icon, label }) => (
                <NavLink key={to} to={to} end className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
                  <Icon size={16} />
                  <span>{label}</span>
                </NavLink>
              ))}
            </>
          )}
        </nav>

        {/* User info */}
        <div className="p-3 border-t space-y-2" style={{ borderColor: 'rgb(var(--border))' }}>
          {/* Balances */}
          <div className="flex gap-2 text-xs">
            <div className="flex-1 card py-2 px-3 text-center">
              <div className="font-bold text-forge-500">{user?.coins?.toLocaleString()}</div>
              <div style={{ color: 'rgb(var(--text-muted))' }}>Coins</div>
            </div>
            <div className="flex-1 card py-2 px-3 text-center">
              <div className="font-bold text-green-500">{user?.credits?.toLocaleString()}</div>
              <div style={{ color: 'rgb(var(--text-muted))' }}>Credits</div>
            </div>
          </div>

          {/* User row */}
          <div className="flex items-center gap-2">
            <img src={avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{user?.username}</div>
              <div className="text-xs truncate" style={{ color: 'rgb(var(--text-muted))' }}>{user?.email}</div>
            </div>
            <button onClick={toggle} className="p-1.5 rounded-lg hover:bg-forge-500/10 transition-colors">
              {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
            </button>
            <button onClick={logout} className="p-1.5 rounded-lg hover:bg-red-500/10 text-red-500 transition-colors">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: 'rgb(var(--border))' }}>
          <button onClick={() => setOpen(true)} className="p-2 rounded-lg hover:bg-forge-500/10">
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-forge-500 rounded flex items-center justify-center">
              <Hammer size={12} className="text-white" />
            </div>
            <span className="font-bold">Forge Panel</span>
          </div>
          <div className="flex gap-2 text-xs">
            <span className="badge badge-yellow">{user?.coins} 🪙</span>
            <span className="badge badge-green">{user?.credits} 💳</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
