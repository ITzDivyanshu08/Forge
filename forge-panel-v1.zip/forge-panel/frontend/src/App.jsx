import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './hooks/useTheme';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Layout from './components/layout/Layout';
import AuthLayout from './components/layout/AuthLayout';
import Spinner from './components/ui/Spinner';
import './styles/globals.css';

// Lazy pages
const Login       = lazy(() => import('./pages/auth/Login'));
const Register    = lazy(() => import('./pages/auth/Register'));
const Dashboard   = lazy(() => import('./pages/dashboard/Dashboard'));
const Servers     = lazy(() => import('./pages/server/Servers'));
const Console     = lazy(() => import('./pages/server/Console'));
const Files       = lazy(() => import('./pages/server/Files'));
const Backups     = lazy(() => import('./pages/server/Backups'));
const Billing     = lazy(() => import('./pages/billing/Billing'));
const BillingSuccess = lazy(() => import('./pages/billing/Success'));
const Daily       = lazy(() => import('./pages/dashboard/Daily'));
const Referral    = lazy(() => import('./pages/dashboard/Referral'));
const Subdomains  = lazy(() => import('./pages/dashboard/Subdomains'));
const AdminDash   = lazy(() => import('./pages/admin/AdminDash'));
const AdminUsers  = lazy(() => import('./pages/admin/AdminUsers'));
const AdminTx     = lazy(() => import('./pages/admin/AdminTx'));

function ProtectedRoute({ children, adminOnly = false }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex h-screen items-center justify-center"><Spinner size={32} /></div>;
  if (!user) return <Navigate to="/auth/login" replace />;
  if (adminOnly && !user.is_admin) return <Navigate to="/dashboard" replace />;
  return children;
}

function GuestRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex h-screen items-center justify-center"><Spinner size={32} /></div>;
  if (user) return <Navigate to="/dashboard" replace />;
  return children;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Suspense fallback={<div className="flex h-screen items-center justify-center"><Spinner size={32} /></div>}>
            <Routes>
              {/* Auth */}
              <Route path="/auth" element={<AuthLayout />}>
                <Route path="login" element={<GuestRoute><Login /></GuestRoute>} />
                <Route path="register" element={<GuestRoute><Register /></GuestRoute>} />
              </Route>

              {/* Main app */}
              <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
                <Route index element={<Navigate to="/dashboard" replace />} />
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="servers" element={<Servers />} />
                <Route path="servers/:uuid/console" element={<Console />} />
                <Route path="servers/:uuid/files" element={<Files />} />
                <Route path="servers/:uuid/backups" element={<Backups />} />
                <Route path="billing" element={<Billing />} />
                <Route path="billing/success" element={<BillingSuccess />} />
                <Route path="daily" element={<Daily />} />
                <Route path="referral" element={<Referral />} />
                <Route path="subdomains" element={<Subdomains />} />
              </Route>

              {/* Admin */}
              <Route path="/admin" element={<ProtectedRoute adminOnly><Layout /></ProtectedRoute>}>
                <Route index element={<AdminDash />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="transactions" element={<AdminTx />} />
              </Route>

              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </Suspense>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
