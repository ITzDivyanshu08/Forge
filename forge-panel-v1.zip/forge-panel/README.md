# ⚒ Forge Panel

A game server management panel built on top of Wings (Pterodactyl/Pelican) and Skyportd, with billing, Discord OAuth, daily rewards, referrals, and more.

## Features

- **Dual Daemon Support** — Wings (Pterodactyl/Pelican) + Skyportd
- **Discord OAuth** — Sign up/login with Discord, auto-creates game panel account
- **Billing** — Stripe (card) + UPI (QR code), admin confirms UPI manually
- **Dual Currency** — Coins (earned) + Credits (purchased)
- **Daily Rewards** — Streak system with up to 3x multiplier
- **Referrals** — Earn coins when friends sign up
- **Subdomains** — Cloudflare CNAME records per server
- **Renewals** — Auto-suspend and delete expired servers
- **Dark/Light theme** — System preference + toggle
- **Mobile responsive** — Works on all screen sizes
- **Admin panel** — Users, transactions, UPI verification, activity log

## Quick Install

```bash
# Upload the forge-panel folder to your server, then:
cd forge-panel
chmod +x install.sh
bash install.sh
```

## Manual Setup (Dev)

```bash
# Backend
cd backend
npm install
cp ../config.toml.example config.toml
# Edit config.toml
node app.js

# Frontend (separate terminal)
cd frontend
npm install
npm run dev
```

## Configuration

Edit `backend/config.toml` — all settings are documented inside.

Key settings to update after install:
- `[panel].domain` — your public URL
- `[pterodactyl]` — Wings panel API keys
- `[discord]` — OAuth app credentials
- `[stripe]` — payment keys
- `[upi].vpa` — your UPI ID
- `[cloudflare]` — for subdomain management

## Tech Stack

- **Backend** — Node.js + Express + better-sqlite3
- **Frontend** — React + Vite + Tailwind CSS
- **Auth** — Session-based + Discord OAuth2
- **Terminal** — xterm.js + Pterodactyl WebSocket
- **Payments** — Stripe Checkout + UPI QR

## Directory Structure

```
forge-panel/
├── backend/
│   ├── app.js              # Express entry point
│   ├── db.js               # SQLite schema
│   ├── config.toml         # Configuration
│   ├── handlers/           # Middleware
│   │   ├── auth.js         # Auth middleware
│   │   └── config.js       # Config loader
│   ├── modules/            # Feature modules
│   │   ├── pterodactyl.js  # Wings API wrapper
│   │   ├── skyport.js      # Skyportd API wrapper
│   │   ├── billing.js      # Stripe + UPI
│   │   ├── daily.js        # Daily rewards
│   │   ├── referral.js     # Referral system
│   │   ├── renewal.js      # Auto-renewal/suspend
│   │   ├── subdomain.js    # Cloudflare subdomains
│   │   └── logger.js       # Activity + webhook logs
│   └── routes/
│       ├── auth.js         # Login/register/Discord
│       └── api.js          # All API endpoints
└── frontend/
    └── src/
        ├── App.jsx
        ├── pages/
        │   ├── auth/       # Login, Register
        │   ├── dashboard/  # Dashboard, Daily, Referral, Subdomains
        │   ├── server/     # Servers, Console, Files
        │   ├── billing/    # Billing, Success
        │   └── admin/      # AdminDash, AdminUsers, AdminTx
        ├── components/     # Layout, UI components
        ├── hooks/          # useAuth, useTheme
        └── lib/            # API client
```
