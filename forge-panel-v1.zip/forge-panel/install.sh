#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════
#                  Forge Panel Installer v1.0.0
#  Wings (Pterodactyl/Pelican) + Skyportd dual daemon support
#  Discord OAuth • Stripe + UPI • Daily Rewards • Referrals
# ═══════════════════════════════════════════════════════════════

INSTALL_DIR="/opt/forge-panel"
SERVICE_USER="forge"
LOG_FILE="/tmp/forge-install.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ORANGE='\033[38;2;240;90;36m'
WHITE='\033[1;37m'
GRAY='\033[38;2;120;120;120m'
RED='\033[38;2;220;50;50m'
GREEN='\033[38;2;80;200;120m'
RESET='\033[0m'
DIM='\033[2m'

banner()  { clear 2>/dev/null||true; echo ""; echo -e "  ${ORANGE}⚒  Forge Panel${RESET} ${GRAY}— ${DIM}$1${RESET}"; echo ""; }
info()    { echo -e "  ${GRAY}›${RESET} $1"; }
success() { echo -e "  ${GREEN}✓${RESET} $1"; }
error()   { echo -e "  ${RED}✗${RESET} ${RED}$1${RESET}"; }
step()    { echo ""; echo -e "  ${ORANGE}─── ${WHITE}$1${RESET}"; echo ""; }

ask() {
    local prompt="$1" default="${2:-}" __result
    if [[ -n "$default" ]]; then
        echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET} [${default}]: " >&2
    else
        echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET}: " >&2
    fi
    read -r __result || true
    echo "${__result:-$default}"
}

ask_yn() {
    local prompt="$1" default="${2:-y}" r
    echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET} [Y/n]: " >&2
    read -r r || true
    [[ "${r:-$default}" =~ ^[Yy] ]]
}

spinner() {
    local pid=$1 label="$2" frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏') i=0
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r  ${ORANGE}%s${RESET} ${GRAY}%s${RESET}  " "${frames[$i]}" "$label" >&2
        i=$(( (i + 1) % 10 ))
        sleep 0.1
    done
    wait "$pid"; local code=$?
    printf "\r"
    [[ $code -eq 0 ]] && success "$label" || error "$label failed — check $LOG_FILE"
    return $code
}

run_step() {
    local label="$1"; shift
    echo "=== $label ===" >> "$LOG_FILE"
    "$@" >> "$LOG_FILE" 2>&1 &
    spinner $! "$label"
}

check_root() { [[ $EUID -eq 0 ]] || { error "Run as root"; exit 1; }; }
> "$LOG_FILE"

banner "Installer v1.0.0"
check_root

# ── Gather config ──────────────────────────────────────────────
step "Configuration"

DOMAIN=$(ask "Panel domain" "https://forge.example.com")
PORT=$(ask "Port" "3000")
SECRET=$(openssl rand -hex 32)

USE_PTERO=false
USE_SKYPORT=false

if ask_yn "Connect to Pterodactyl / Pelican (Wings)?"; then
    USE_PTERO=true
    PTERO_DOMAIN=$(ask "Pterodactyl panel URL" "https://ptero.example.com")
    PTERO_KEY=$(ask "Admin API key")
    PTERO_CLIENT_KEY=$(ask "Client API key (admin account)")
fi

if ask_yn "Connect to Skyportd?"; then
    USE_SKYPORT=true
    SKYPORT_DOMAIN=$(ask "Skyport panel URL" "https://sky.example.com")
    SKYPORT_KEY=$(ask "Skyport API key")
fi

USE_DISCORD=false
if ask_yn "Enable Discord OAuth?"; then
    USE_DISCORD=true
    DISCORD_CLIENT_ID=$(ask "Discord Client ID")
    DISCORD_CLIENT_SECRET=$(ask "Discord Client Secret")
    DISCORD_BOT_TOKEN=$(ask "Discord Bot Token (optional, press Enter to skip)" "")
fi

USE_STRIPE=false
if ask_yn "Enable Stripe payments?"; then
    USE_STRIPE=true
    STRIPE_KEY=$(ask "Stripe Secret Key")
    STRIPE_WEBHOOK=$(ask "Stripe Webhook Secret")
fi

UPI_VPA=$(ask "UPI VPA (payment ID)" "abcd@fam")

ADMIN_EMAIL=$(ask "Admin email")
ADMIN_PASS=$(ask "Admin password")

# ── Install system deps ────────────────────────────────────────
step "System dependencies"

install_deps() {
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y curl gnupg2 ca-certificates git build-essential

    # Node.js 22
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs

    # nginx
    apt-get install -y nginx

    node --version >> "$LOG_FILE"
    npm --version  >> "$LOG_FILE"
}
run_step "Installing Node.js 22 + nginx" install_deps

# ── Copy source ────────────────────────────────────────────────
step "Setting up Forge Panel"

setup_source() {
    [[ -d "$INSTALL_DIR" ]] && rm -rf "$INSTALL_DIR"
    cp -r "$SCRIPT_DIR" "$INSTALL_DIR"
    id -u "$SERVICE_USER" &>/dev/null || useradd -r -s /bin/false "$SERVICE_USER"
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
}
run_step "Copying panel source" setup_source

# ── Write config ───────────────────────────────────────────────
write_config() {
    cat > "$INSTALL_DIR/backend/config.toml" <<TOML
[panel]
name = "Forge Panel"
version = "1.0.0"
port = ${PORT}
domain = "${DOMAIN}"
secret = "${SECRET}"
database = "forge.db"

[pterodactyl]
enabled = ${USE_PTERO}
domain = "${PTERO_DOMAIN:-}"
key = "${PTERO_KEY:-}"
client_key = "${PTERO_CLIENT_KEY:-}"

[skyport]
enabled = ${USE_SKYPORT}
domain = "${SKYPORT_DOMAIN:-}"
key = "${SKYPORT_KEY:-}"

[discord]
enabled = ${USE_DISCORD}
client_id = "${DISCORD_CLIENT_ID:-}"
client_secret = "${DISCORD_CLIENT_SECRET:-}"
bot_token = "${DISCORD_BOT_TOKEN:-}"
signup_bonus = 100

[email]
enabled = false
host = "smtp.gmail.com"
port = 587
user = ""
pass = ""
from = "noreply@example.com"

[stripe]
enabled = ${USE_STRIPE}
secret_key = "${STRIPE_KEY:-}"
webhook_secret = "${STRIPE_WEBHOOK:-}"

[upi]
enabled = true
vpa = "${UPI_VPA}"
name = "Forge Panel"

[currency]
coins_name = "Coins"
credits_name = "Credits"
credits_per_usd = 100
credits_per_inr = 10

[daily]
enabled = true
base_coins = 25
streak_bonus_day7 = 1.5
streak_bonus_day14 = 2.0
streak_bonus_day30 = 3.0

[renewal]
enabled = true
period_days = 30
warning_days = 3
auto_delete_after_days = 7
check_interval_minutes = 30

[referral]
enabled = true
referrer_coins = 200
referee_coins = 100

[cloudflare]
enabled = false
api_token = ""
max_per_server = 2

[[cloudflare.domains]]
enabled = false
name = "main"
domain = "example.com"
zone_id = ""
is_default = true

[packages]
[packages.default]
ram = 2048
disk = 5120
cpu = 100
servers = 1

[store]
ram_per_coin = 0.5
disk_per_coin = 1.0
cpu_per_coin = 0.2
server_cost_coins = 500

[logging]
enabled = false
webhook = ""
log_logins = true
log_registrations = true
log_payments = true
log_server_actions = true
log_admin_actions = true

[security]
allow_registration = true
require_email_verify = false
max_login_attempts = 5
lockout_minutes = 15
TOML
}
run_step "Writing config.toml" write_config

# ── Install npm deps & build frontend ──────────────────────────
install_backend() {
    cd "$INSTALL_DIR/backend"
    npm install --production
}

build_frontend() {
    cd "$INSTALL_DIR/frontend"
    npm install
    npm run build
}

run_step "Installing backend dependencies" install_backend
run_step "Building frontend (React + Vite)" build_frontend

# ── Create admin user ──────────────────────────────────────────
create_admin() {
    cd "$INSTALL_DIR/backend"
    node -e "
const { getDb } = require('./db');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const db = getDb();
const hash = bcrypt.hashSync('${ADMIN_PASS}', 12);
const uuid = uuidv4();
const ref = Math.random().toString(36).slice(2,10).toUpperCase();
try {
    db.prepare(\`INSERT INTO users (uuid, username, email, password, is_admin, referral_code, coins, credits, ram, disk, cpu, servers)
        VALUES (?, 'admin', ?, ?, 1, ?, 9999, 9999, 32768, 102400, 1000, 99)\`).run(uuid, '${ADMIN_EMAIL}', hash, ref);
    console.log('Admin created');
} catch(e) { console.log('Admin may already exist:', e.message); }
"
}
run_step "Creating admin account" create_admin

# ── Nginx ──────────────────────────────────────────────────────
setup_nginx() {
    cat > /etc/nginx/sites-available/forge-panel.conf <<NGINX
server {
    listen 80;
    server_name _;
    client_max_body_size 256m;
    location / {
        proxy_pass http://127.0.0.1:${PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_buffering off;
        proxy_read_timeout 300s;
    }
}
NGINX
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/forge-panel.conf /etc/nginx/sites-enabled/forge-panel.conf
    nginx -t
    systemctl restart nginx
}
run_step "Configuring nginx" setup_nginx

# ── Systemd ────────────────────────────────────────────────────
setup_service() {
    cat > /etc/systemd/system/forge-panel.service <<SVC
[Unit]
Description=Forge Panel
After=network.target
[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}/backend
ExecStart=/usr/bin/node app.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production
StandardOutput=journal
StandardError=journal
[Install]
WantedBy=multi-user.target
SVC
    systemctl daemon-reload
    systemctl enable forge-panel
    systemctl restart forge-panel
}
run_step "Setting up systemd service" setup_service

# ── Done ───────────────────────────────────────────────────────
step "Installation complete!"
echo ""
echo -e "  ${ORANGE}╔══════════════════════════════════════════════╗${RESET}"
echo -e "  ${ORANGE}║${RESET}        ${WHITE}⚒  Forge Panel is running!${RESET}             ${ORANGE}║${RESET}"
echo -e "  ${ORANGE}╠══════════════════════════════════════════════╣${RESET}"
echo -e "  ${ORANGE}║${RESET}  URL:    ${ORANGE}${DOMAIN}${RESET}"
echo -e "  ${ORANGE}║${RESET}  Admin:  ${ORANGE}${ADMIN_EMAIL}${RESET}"
echo -e "  ${ORANGE}║${RESET}  Port:   ${ORANGE}${PORT}${RESET}"
echo -e "  ${ORANGE}║${RESET}  Logs:   ${DIM}journalctl -u forge-panel -f${RESET}"
echo -e "  ${ORANGE}╚══════════════════════════════════════════════╝${RESET}"
echo ""
info "If using Cloudflare Tunnel, point it to: http://localhost:${PORT}"
info "Edit config: ${INSTALL_DIR}/backend/config.toml"
echo ""
