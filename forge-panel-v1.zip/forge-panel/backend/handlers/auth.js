const { getDb } = require('../db');

function requireAuth(req, res, next) {
    if (!req.session?.userId) {
        if (req.path.startsWith('/api/')) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        return res.redirect('/auth/login');
    }
    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
    if (!user) {
        req.session.destroy();
        return res.redirect('/auth/login');
    }
    if (user.is_banned) {
        req.session.destroy();
        if (req.path.startsWith('/api/')) {
            return res.status(403).json({ error: 'Account banned', reason: user.ban_reason });
        }
        return res.redirect('/auth/banned?reason=' + encodeURIComponent(user.ban_reason || ''));
    }
    req.user = user;
    next();
}

function requireAdmin(req, res, next) {
    requireAuth(req, res, () => {
        if (!req.user.is_admin) {
            if (req.path.startsWith('/api/')) {
                return res.status(403).json({ error: 'Forbidden' });
            }
            return res.redirect('/dashboard');
        }
        next();
    });
}

function requireGuest(req, res, next) {
    if (req.session?.userId) return res.redirect('/dashboard');
    next();
}

module.exports = { requireAuth, requireAdmin, requireGuest };
