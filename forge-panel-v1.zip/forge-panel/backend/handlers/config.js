const fs = require('fs');
const path = require('path');
const toml = require('toml');

let _config = null;

function loadConfig() {
    if (_config) return _config;
    const configPath = path.resolve(__dirname, '../config.toml');
    if (!fs.existsSync(configPath)) {
        console.error('❌ config.toml not found. Copy config.toml.example and fill it in.');
        process.exit(1);
    }
    _config = toml.parse(fs.readFileSync(configPath, 'utf-8'));
    return _config;
}

module.exports = { loadConfig };
