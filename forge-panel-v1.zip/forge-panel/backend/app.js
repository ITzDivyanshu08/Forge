const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');

const { loadConfig } = require('./handlers/config');
const { getDb } = require('./db');
const { startRenewalCron } = require('./modules/renewal');

const config = loadConfig();
const app = express();

// ── Security ───────────────────────────────────────────────────
app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
}));
app.use(cors({
    origin: config.panel.domain,
    credentials: true,
}));
app.set('trust proxy', 1);

// ── Rate Limiting ──────────────────────────────────────────────
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true });
app.use('/api/', limiter);
app.use('/auth/', authLimiter);

// ── Body Parsing ───────────────────────────────────────────────
// Raw body for Stripe webhooks
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json' }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Sessions ───────────────────────────────────────────────────
const SQLiteStore = require('connect-sqlite3')(session);
app.use(session({
    store: new SQLiteStore({ db: config.panel.database || 'forge.db', dir: './' }),
    secret: config.panel.secret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: config.panel.domain.startsWith('https'),
        httpOnly: true,
        maxAge: 7 * 24 * 60 * 60 * 1000,
        sameSite: 'lax',
    },
}));

// ── Routes ─────────────────────────────────────────────────────
app.use('/auth', require('./routes/auth'));
app.use('/api', require('./routes/api'));

// ── Frontend ───────────────────────────────────────────────────
const frontendDist = path.resolve(__dirname, '../frontend/dist');
app.use(express.static(frontendDist));

// All non-API routes → React SPA
app.get('*', (req, res) => {
    if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) {
        return res.status(404).json({ error: 'Not found' });
    }
    res.sendFile(path.join(frontendDist, 'index.html'));
});

// ── Error Handler ──────────────────────────────────────────────
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    if (req.path.startsWith('/api/')) {
        return res.status(500).json({ error: 'Internal server error' });
    }
    res.status(500).send('Internal server error');
});

// ── Start ──────────────────────────────────────────────────────
const PORT = config.panel.port || 3000;

// Init DB
getDb();

// Start renewal cron
startRenewalCron();

app.listen(PORT, () => {
    console.log(`
╔══════════════════════════════════════════╗
║          ⚒  Forge Panel v1.0.0           ║
╠══════════════════════════════════════════╣
║  Running on: http://localhost:${PORT}        ║
║  Domain:     ${config.panel.domain.padEnd(30)}║
╚══════════════════════════════════════════╝
    `);
});

module.exports = app;
