const express = require('express');
const { getDb } = require('../db');
const { requireAuth, requireAdmin } = require('../handlers/auth');
const { loadConfig } = require('../handlers/config');
const { logActivity, getActivityLog } = require('../modules/logger');
const daily = require('../modules/daily');
const billing = require('../modules/billing');
const referral = require('../modules/referral');
const subdomain = require('../modules/subdomain');
const renewal = require('../modules/renewal');
const ptero = require('../modules/pterodactyl');
const skyport = require('../modules/skyport');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();
const config = loadConfig();

// ── User Info ──────────────────────────────────────────────────

router.get('/user', requireAuth, (req, res) => {
    const db = getDb();
    const user = { ...req.user };
    delete user.password;
    const serverCount = db.prepare('SELECT COUNT(*) as c FROM servers WHERE user_id = ?').get(user.id).c;
    res.json({ user, serverCount });
});

// ── Daily Rewards ──────────────────────────────────────────────

router.get('/daily/info', requireAuth, (req, res) => {
    try {
        const info = daily.getStreakInfo(req.user.id);
        res.json(info);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/daily/claim', requireAuth, (req, res) => {
    try {
        const result = daily.claim(req.user.id);
        res.json({ success: true, ...result });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// ── Servers ────────────────────────────────────────────────────

router.get('/servers', requireAuth, async (req, res) => {
    try {
        const db = getDb();
        const servers = db.prepare('SELECT * FROM servers WHERE user_id = ?').all(req.user.id);
        const enriched = await Promise.all(servers.map(async s => {
            let stats = null;
            try {
                if (s.daemon_type === 'pterodactyl' && s.pterodactyl_id) {
                    stats = await ptero.getServerResources(s.uuid);
                } else if (s.daemon_type === 'skyport' && s.skyport_id) {
                    stats = await skyport.getServerStats(s.skyport_id);
                }
            } catch {}
            return { ...s, stats };
        }));
        res.json(enriched);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/servers', requireAuth, async (req, res) => {
    try {
        const db = getDb();
        const { name, egg, node, ram, disk, cpu, daemonType, variables } = req.body;
        const user = req.user;

        const currentServers = db.prepare('SELECT COUNT(*) as c FROM servers WHERE user_id = ?').get(user.id).c;
        if (currentServers >= user.servers) return res.status(400).json({ error: 'Server limit reached' });
        if (ram > user.ram || disk > user.disk || cpu > user.cpu) return res.status(400).json({ error: 'Resource limit exceeded' });

        let serverData, serverUuid;

        if ((daemonType || 'pterodactyl') === 'pterodactyl' && config.pterodactyl.enabled) {
            const nodes = await ptero.getNodes();
            const targetNode = node ? nodes.find(n => n.id == node) : nodes[0];
            if (!targetNode) return res.status(400).json({ error: 'No available nodes' });

            const allocations = await ptero.getAllocations(targetNode.id);
            const freeAlloc = allocations.find(a => !a.assigned);
            if (!freeAlloc) return res.status(400).json({ error: 'No free allocations' });

            serverData = await ptero.createServer({
                name, userId: user.pterodactyl_id, egg,
                ram, disk, cpu, allocationId: freeAlloc.id, variables,
            });
            serverUuid = serverData.uuid;

            const expiry = new Date();
            expiry.setDate(expiry.getDate() + (config.renewal.period_days || 30));

            db.prepare(`
                INSERT INTO servers (uuid, name, user_id, pterodactyl_id, daemon_type, ram, disk, cpu, expires_at)
                VALUES (?, ?, ?, ?, 'pterodactyl', ?, ?, ?, ?)
            `).run(serverUuid, name, user.id, serverData.id, ram, disk, cpu, expiry.toISOString());
        } else if (daemonType === 'skyport' && config.skyport.enabled) {
            serverData = await skyport.createServer({ name, userId: user.skyport_id, node, image: egg, ram, disk, cpu });
            serverUuid = uuidv4();

            const expiry = new Date();
            expiry.setDate(expiry.getDate() + (config.renewal.period_days || 30));

            db.prepare(`
                INSERT INTO servers (uuid, name, user_id, skyport_id, daemon_type, ram, disk, cpu, expires_at)
                VALUES (?, ?, ?, ?, 'skyport', ?, ?, ?, ?)
            `).run(serverUuid, name, user.id, serverData.id, ram, disk, cpu, expiry.toISOString());
        } else {
            return res.status(400).json({ error: 'No daemon available' });
        }

        logActivity(user.id, 'server_created', `Created server "${name}"`);
        res.json({ success: true, uuid: serverUuid });
    } catch (e) {
        console.error(e);
        res.status(500).json({ error: e.message });
    }
});

router.post('/servers/:uuid/power', requireAuth, async (req, res) => {
    try {
        const db = getDb();
        const server = db.prepare('SELECT * FROM servers WHERE uuid = ? AND user_id = ?').get(req.params.uuid, req.user.id);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        if (server.suspended) return res.status(403).json({ error: 'Server is suspended' });

        const { action } = req.body;
        if (!['start','stop','restart','kill'].includes(action)) return res.status(400).json({ error: 'Invalid action' });

        await ptero.sendPowerAction(server.uuid, action);
        logActivity(req.user.id, 'server_power', `${action} on server ${server.uuid}`);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/servers/:uuid/renew', requireAuth, async (req, res) => {
    try {
        const db = getDb();
        const server = db.prepare('SELECT * FROM servers WHERE uuid = ? AND user_id = ?').get(req.params.uuid, req.user.id);
        if (!server) return res.status(404).json({ error: 'Server not found' });

        const result = await renewal.renewServer(req.user.id, server.id);
        res.json({ success: true, ...result });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

router.delete('/servers/:uuid', requireAuth, async (req, res) => {
    try {
        const db = getDb();
        const server = db.prepare('SELECT * FROM servers WHERE uuid = ? AND user_id = ?').get(req.params.uuid, req.user.id);
        if (!server) return res.status(404).json({ error: 'Server not found' });

        if (server.daemon_type === 'pterodactyl' && server.pterodactyl_id) {
            await ptero.deleteServer(server.pterodactyl_id);
        } else if (server.daemon_type === 'skyport' && server.skyport_id) {
            await skyport.deleteServer(server.skyport_id);
        }

        db.prepare('DELETE FROM servers WHERE id = ?').run(server.id);
        logActivity(req.user.id, 'server_deleted', `Deleted server ${server.uuid}`);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/servers/:uuid/ws', requireAuth, async (req, res) => {
    try {
        const db = getDb();
        const server = db.prepare('SELECT * FROM servers WHERE uuid = ? AND user_id = ?').get(req.params.uuid, req.user.id);
        if (!server) return res.status(404).json({ error: 'Server not found' });

        const creds = await ptero.getServerWsCredentials(server.uuid);
        res.json(creds);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Billing ────────────────────────────────────────────────────

router.get('/billing/transactions', requireAuth, (req, res) => {
    const db = getDb();
    const txs = db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
    res.json(txs);
});

router.post('/billing/stripe', requireAuth, async (req, res) => {
    try {
        const { amount } = req.body;
        if (!amount || amount < 1) return res.status(400).json({ error: 'Minimum $1' });
        const result = await billing.createStripeSession(req.user.id, amount, `${amount} USD top-up`);
        res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/billing/stripe/verify', requireAuth, async (req, res) => {
    try {
        const { session_id } = req.query;
        const tx = await billing.verifyStripeSession(session_id, req.user.id);
        res.json(tx);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/billing/upi', requireAuth, async (req, res) => {
    try {
        const { amount } = req.body;
        if (!amount || amount < 10) return res.status(400).json({ error: 'Minimum ₹10' });
        const result = await billing.createUpiPayment(req.user.id, amount, `₹${amount} top-up`);
        res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/billing/upi/verify', requireAuth, async (req, res) => {
    try {
        const { txId, upiRef } = req.body;
        const result = await billing.verifyUpiPayment(txId, req.user.id, upiRef);
        res.json(result);
    } catch (e) { res.status(400).json({ error: e.message }); }
});

router.post('/billing/coins', requireAuth, (req, res) => {
    try {
        const { item, amount } = req.body;
        const result = billing.buyWithCoins(req.user.id, item, amount);
        res.json({ success: true, ...result });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// ── Referral ───────────────────────────────────────────────────

router.get('/referral', requireAuth, (req, res) => {
    const stats = referral.getStats(req.user.id);
    res.json(stats);
});

// ── Subdomains ─────────────────────────────────────────────────

router.get('/subdomains', requireAuth, (req, res) => {
    const subs = subdomain.getUserSubdomains(req.user.id);
    const domains = subdomain.getAvailableDomains();
    res.json({ subdomains: subs, domains });
});

router.post('/subdomains', requireAuth, async (req, res) => {
    try {
        const { serverId, subdomain: sub, domain, target } = req.body;
        const domainConfig = subdomain.getAvailableDomains().find(d => d.domain === domain);
        if (!domainConfig) return res.status(400).json({ error: 'Domain not available' });
        const result = await subdomain.createSubdomain(req.user.id, serverId, sub, domainConfig, target);
        res.json({ success: true, ...result });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

router.delete('/subdomains/:id', requireAuth, async (req, res) => {
    try {
        await subdomain.deleteSubdomain(req.params.id, req.user.id);
        res.json({ success: true });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// ── Admin Routes ───────────────────────────────────────────────

router.get('/admin/stats', requireAdmin, (req, res) => {
    const db = getDb();
    const stats = {
        users: db.prepare('SELECT COUNT(*) as c FROM users').get().c,
        servers: db.prepare('SELECT COUNT(*) as c FROM servers').get().c,
        suspended: db.prepare('SELECT COUNT(*) as c FROM servers WHERE suspended = 1').get().c,
        revenue: db.prepare("SELECT COALESCE(SUM(amount), 0) as t FROM transactions WHERE status = 'completed'").get().t,
        pendingUpi: db.prepare("SELECT COUNT(*) as c FROM transactions WHERE gateway = 'upi' AND status = 'verifying'").get().c,
        recentUsers: db.prepare('SELECT id, username, email, coins, credits, created_at FROM users ORDER BY created_at DESC LIMIT 10').all(),
        recentActivity: getActivityLog(null, 20),
    };
    res.json(stats);
});

router.get('/admin/users', requireAdmin, (req, res) => {
    const db = getDb();
    const { search } = req.query;
    let users;
    if (search) {
        users = db.prepare('SELECT * FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY created_at DESC LIMIT 50')
            .all(`%${search}%`, `%${search}%`);
    } else {
        users = db.prepare('SELECT * FROM users ORDER BY created_at DESC LIMIT 100').all();
    }
    users.forEach(u => delete u.password);
    res.json(users);
});

router.patch('/admin/users/:id', requireAdmin, (req, res) => {
    try {
        const db = getDb();
        const { coins, credits, ram, disk, cpu, servers, is_admin, is_banned, ban_reason } = req.body;
        const updates = [];
        const values = [];

        if (coins !== undefined) { updates.push('coins = ?'); values.push(coins); }
        if (credits !== undefined) { updates.push('credits = ?'); values.push(credits); }
        if (ram !== undefined) { updates.push('ram = ?'); values.push(ram); }
        if (disk !== undefined) { updates.push('disk = ?'); values.push(disk); }
        if (cpu !== undefined) { updates.push('cpu = ?'); values.push(cpu); }
        if (servers !== undefined) { updates.push('servers = ?'); values.push(servers); }
        if (is_admin !== undefined) { updates.push('is_admin = ?'); values.push(is_admin ? 1 : 0); }
        if (is_banned !== undefined) { updates.push('is_banned = ?'); values.push(is_banned ? 1 : 0); }
        if (ban_reason !== undefined) { updates.push('ban_reason = ?'); values.push(ban_reason); }

        if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
        values.push(req.params.id);
        db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
        logActivity(req.user.id, 'admin_user_edit', `Edited user #${req.params.id}`);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/admin/transactions', requireAdmin, (req, res) => {
    const db = getDb();
    const { status } = req.query;
    let txs;
    if (status) {
        txs = db.prepare('SELECT t.*, u.username FROM transactions t JOIN users u ON t.user_id = u.id WHERE t.status = ? ORDER BY t.created_at DESC LIMIT 100').all(status);
    } else {
        txs = db.prepare('SELECT t.*, u.username FROM transactions t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 100').all();
    }
    res.json(txs);
});

router.post('/admin/transactions/:uuid/confirm', requireAdmin, async (req, res) => {
    try {
        await billing.adminConfirmUpi(req.params.uuid);
        logActivity(req.user.id, 'admin_upi_confirm', `Confirmed UPI tx ${req.params.uuid}`);
        res.json({ success: true });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// Stripe webhook (raw body needed)
router.post('/webhooks/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
    try {
        await billing.handleStripeWebhook(req.body, req.headers['stripe-signature']);
        res.json({ received: true });
    } catch (e) {
        res.status(400).json({ error: e.message });
    }
});

// ── Eggs / Images ──────────────────────────────────────────────

router.get('/eggs', requireAuth, async (req, res) => {
    try {
        if (config.pterodactyl.enabled) {
            const nests = await ptero.getNests();
            const eggs = await Promise.all(nests.map(n => ptero.getEggs(n.id)));
            res.json(eggs.flat());
        } else if (config.skyport.enabled) {
            const images = await skyport.getImages();
            res.json(images);
        } else {
            res.json([]);
        }
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/nodes', requireAuth, async (req, res) => {
    try {
        if (config.pterodactyl.enabled) {
            const nodes = await ptero.getNodes();
            res.json(nodes);
        } else if (config.skyport.enabled) {
            const nodes = await skyport.getNodes();
            res.json(nodes);
        } else {
            res.json([]);
        }
    } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
