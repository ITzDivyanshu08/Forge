const express = require('express');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const { requireGuest, requireAuth } = require('../handlers/auth');
const { logActivity } = require('../modules/logger');
const { applyReferral, getOrCreateCode } = require('../modules/referral');
const ptero = require('../modules/pterodactyl');

const router = express.Router();
const config = loadConfig();

// ── Local Auth ────────────────────────────────────────────────

router.post('/register', requireGuest, async (req, res) => {
    try {
        const { username, email, password, referral_code } = req.body;
        if (!username || !email || !password) return res.status(400).json({ error: 'All fields required' });
        if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
        if (!config.security.allow_registration) return res.status(403).json({ error: 'Registration is currently disabled' });

        const db = getDb();
        const exists = db.prepare('SELECT id FROM users WHERE email = ? OR username = ?').get(email, username);
        if (exists) return res.status(409).json({ error: 'Email or username already taken' });

        const hash = await bcrypt.hash(password, 12);
        const uuid = uuidv4();

        // Create Pterodactyl user if enabled
        let pterodactylId = null;
        if (config.pterodactyl.enabled) {
            try {
                const ptUser = await ptero.createUser(email, username, username, 'User', password);
                pterodactylId = ptUser.id;
            } catch (e) {
                console.error('Failed to create Pterodactyl user:', e.message);
            }
        }

        const pkg = config.packages.default;
        const result = db.prepare(`
            INSERT INTO users (uuid, username, email, password, pterodactyl_id, coins, credits, ram, disk, cpu, servers)
            VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
        `).run(uuid, username, email, hash, pterodactylId, config.discord.signup_bonus || 0, pkg.ram, pkg.disk, pkg.cpu, pkg.servers);

        const userId = result.lastInsertRowid;
        getOrCreateCode(userId);

        if (referral_code) applyReferral(userId, referral_code);

        req.session.userId = userId;
        logActivity(userId, 'register', `New registration: ${username} (${email})`, req.ip);
        res.json({ success: true });
    } catch (e) {
        console.error(e);
        res.status(500).json({ error: 'Registration failed' });
    }
});

router.post('/login', requireGuest, async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

        const db = getDb();
        const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
        if (!user || !user.password) return res.status(401).json({ error: 'Invalid credentials' });

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

        if (user.is_banned) return res.status(403).json({ error: 'Account banned', reason: user.ban_reason });

        req.session.userId = user.id;
        logActivity(user.id, 'login', `Login from ${req.ip}`, req.ip);
        res.json({ success: true });
    } catch (e) {
        console.error(e);
        res.status(500).json({ error: 'Login failed' });
    }
});

router.post('/logout', requireAuth, (req, res) => {
    req.session.destroy(() => res.json({ success: true }));
});

// ── Discord OAuth ─────────────────────────────────────────────

router.get('/discord', (req, res) => {
    if (!config.discord.enabled) return res.redirect('/auth/login');
    const params = new URLSearchParams({
        client_id: config.discord.client_id,
        redirect_uri: `${config.panel.domain}/auth/discord/callback`,
        response_type: 'code',
        scope: 'identify email guilds',
    });
    res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

router.get('/discord/callback', async (req, res) => {
    try {
        const { code } = req.query;
        if (!code) return res.redirect('/auth/login?error=no_code');

        // Exchange code for token
        const tokenRes = await require('axios').post('https://discord.com/api/oauth2/token',
            new URLSearchParams({
                client_id: config.discord.client_id,
                client_secret: config.discord.client_secret,
                grant_type: 'authorization_code',
                code,
                redirect_uri: `${config.panel.domain}/auth/discord/callback`,
            }),
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );

        const { access_token } = tokenRes.data;
        const userRes = await require('axios').get('https://discord.com/api/users/@me', {
            headers: { Authorization: `Bearer ${access_token}` }
        });

        const discord = userRes.data;
        const db = getDb();

        // Find existing user
        let user = db.prepare('SELECT * FROM users WHERE discord_id = ?').get(discord.id);

        if (!user) {
            // Check if email matches existing account
            user = db.prepare('SELECT * FROM users WHERE email = ?').get(discord.email);
            if (user) {
                // Link Discord to existing account
                db.prepare('UPDATE users SET discord_id = ?, discord_username = ?, discord_avatar = ? WHERE id = ?')
                    .run(discord.id, discord.username, discord.avatar, user.id);
            } else {
                // Create new account
                const uuid = uuidv4();
                const username = discord.username.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
                let finalUsername = username;
                let suffix = 1;
                while (db.prepare('SELECT id FROM users WHERE username = ?').get(finalUsername)) {
                    finalUsername = `${username}_${suffix++}`;
                }

                let pterodactylId = null;
                if (config.pterodactyl.enabled) {
                    try {
                        const tempPass = uuidv4().slice(0, 16);
                        const ptUser = await ptero.createUser(discord.email || `${discord.id}@discord.forge`, finalUsername, finalUsername, 'User', tempPass);
                        pterodactylId = ptUser.id;
                    } catch (e) {
                        console.error('Ptero create failed:', e.message);
                    }
                }

                const pkg = config.packages.default;
                const signupBonus = config.discord.signup_bonus || 100;
                const result = db.prepare(`
                    INSERT INTO users (uuid, username, email, discord_id, discord_username, discord_avatar,
                        pterodactyl_id, coins, credits, ram, disk, cpu, servers)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
                `).run(uuid, finalUsername, discord.email || `${discord.id}@discord.forge`,
                    discord.id, discord.username, discord.avatar,
                    pterodactylId, signupBonus, pkg.ram, pkg.disk, pkg.cpu, pkg.servers);

                user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
                getOrCreateCode(user.id);

                const ref = req.session.pendingReferral;
                if (ref) { applyReferral(user.id, ref); delete req.session.pendingReferral; }

                logActivity(user.id, 'register_discord', `Discord signup: ${discord.username}`, req.ip);
            }
        }

        if (user.is_banned) return res.redirect('/auth/login?error=banned');

        req.session.userId = user.id;
        logActivity(user.id, 'login_discord', `Discord login: ${discord.username}`, req.ip);
        res.redirect('/dashboard');
    } catch (e) {
        console.error('Discord OAuth error:', e.message);
        res.redirect('/auth/login?error=discord_failed');
    }
});

module.exports = router;
