const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const { logActivity } = require('./logger');
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');

const config = loadConfig();

// ── Stripe ────────────────────────────────────────────────────

function getStripe() {
    if (!config.stripe?.enabled) return null;
    return require('stripe')(config.stripe.secret_key);
}

async function createStripeSession(userId, amountUSD, description) {
    const stripe = getStripe();
    if (!stripe) throw new Error('Stripe not enabled');

    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    const creditsToGive = Math.floor(amountUSD * (config.currency.credits_per_usd || 100));
    const txId = uuidv4();

    const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [{
            price_data: {
                currency: 'usd',
                product_data: { name: `${creditsToGive} Credits — Forge Panel` },
                unit_amount: Math.round(amountUSD * 100),
            },
            quantity: 1,
        }],
        mode: 'payment',
        success_url: `${config.panel.domain}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${config.panel.domain}/billing`,
        metadata: { userId: String(userId), txId, creditsToGive: String(creditsToGive) },
        customer_email: user.email,
    });

    db.prepare(`
        INSERT INTO transactions (uuid, user_id, type, amount, currency, credits_given, status, gateway, stripe_session_id, description)
        VALUES (?, ?, 'topup', ?, 'USD', ?, 'pending', 'stripe', ?, ?)
    `).run(txId, userId, amountUSD, creditsToGive, session.id, description || `${creditsToGive} Credits`);

    return { url: session.url, txId };
}

async function handleStripeWebhook(rawBody, signature) {
    const stripe = getStripe();
    if (!stripe) return;

    const event = stripe.webhooks.constructEvent(rawBody, signature, config.stripe.webhook_secret);
    if (event.type !== 'checkout.session.completed') return;

    const session = event.data.object;
    const { userId, txId, creditsToGive } = session.metadata;
    const db = getDb();

    const tx = db.prepare('SELECT * FROM transactions WHERE uuid = ?').get(txId);
    if (!tx || tx.status === 'completed') return;

    db.prepare(`
        UPDATE transactions SET status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE uuid = ?
    `).run(txId);

    db.prepare(`
        UPDATE users SET credits = credits + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).run(parseInt(creditsToGive), parseInt(userId));

    logActivity(parseInt(userId), 'stripe_payment', `Received ${creditsToGive} credits via Stripe`);
}

async function verifyStripeSession(sessionId, userId) {
    const stripe = getStripe();
    if (!stripe) return null;

    const db = getDb();
    const tx = db.prepare('SELECT * FROM transactions WHERE stripe_session_id = ? AND user_id = ?').get(sessionId, userId);
    if (!tx) return null;

    if (tx.status === 'completed') return tx;

    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if (session.payment_status === 'paid') {
        db.prepare(`UPDATE transactions SET status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE uuid = ?`).run(tx.uuid);
        db.prepare(`UPDATE users SET credits = credits + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(tx.credits_given, userId);
        logActivity(userId, 'stripe_payment', `Received ${tx.credits_given} credits via Stripe`);
        return { ...tx, status: 'completed' };
    }
    return tx;
}

// ── UPI ───────────────────────────────────────────────────────

async function createUpiPayment(userId, amountINR, description) {
    const db = getDb();
    const txId = uuidv4();
    const creditsToGive = Math.floor(amountINR * (config.currency.credits_per_inr || 10));

    db.prepare(`
        INSERT INTO transactions (uuid, user_id, type, amount, currency, credits_given, status, gateway, description)
        VALUES (?, ?, 'topup', ?, 'INR', ?, 'pending', 'upi', ?)
    `).run(txId, userId, amountINR, creditsToGive, description || `${creditsToGive} Credits via UPI`);

    const upiString = `upi://pay?pa=${config.upi.vpa}&pn=${encodeURIComponent(config.upi.name)}&am=${amountINR}&cu=INR&tn=${encodeURIComponent('Forge Panel - ' + txId.slice(0, 8))}`;
    const qrCode = await QRCode.toDataURL(upiString);

    return { txId, upiString, qrCode, creditsToGive, amountINR, vpa: config.upi.vpa };
}

async function verifyUpiPayment(txId, userId, upiRef) {
    const db = getDb();
    const tx = db.prepare('SELECT * FROM transactions WHERE uuid = ? AND user_id = ?').get(txId, userId);
    if (!tx) throw new Error('Transaction not found');
    if (tx.status === 'completed') return tx;

    // Mark as pending verification — admin must confirm
    db.prepare(`UPDATE transactions SET upi_ref = ?, status = 'verifying' WHERE uuid = ?`).run(upiRef, txId);
    logActivity(userId, 'upi_verify_request', `UPI ref ${upiRef} submitted for tx ${txId}`);
    return { ...tx, status: 'verifying' };
}

async function adminConfirmUpi(txId) {
    const db = getDb();
    const tx = db.prepare('SELECT * FROM transactions WHERE uuid = ?').get(txId);
    if (!tx) throw new Error('Transaction not found');
    if (tx.status === 'completed') return tx;

    db.prepare(`UPDATE transactions SET status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE uuid = ?`).run(txId);
    db.prepare(`UPDATE users SET credits = credits + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(tx.credits_given, tx.user_id);
    logActivity(tx.user_id, 'upi_payment_confirmed', `Admin confirmed ${tx.credits_given} credits`);
    return tx;
}

// ── Coin Store ────────────────────────────────────────────────

function buyWithCoins(userId, item, amount) {
    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    const store = config.store;

    const costs = {
        ram:    Math.ceil(amount / store.ram_per_coin),
        disk:   Math.ceil(amount / store.disk_per_coin),
        cpu:    Math.ceil(amount / store.cpu_per_coin),
        server: store.server_cost_coins,
    };

    const cost = costs[item];
    if (!cost) throw new Error('Invalid item');
    if (user.coins < cost) throw new Error(`Not enough coins (need ${cost})`);

    const updates = {
        ram:    () => db.prepare('UPDATE users SET ram = ram + ?, coins = coins - ? WHERE id = ?').run(amount, cost, userId),
        disk:   () => db.prepare('UPDATE users SET disk = disk + ?, coins = coins - ? WHERE id = ?').run(amount, cost, userId),
        cpu:    () => db.prepare('UPDATE users SET cpu = cpu + ?, coins = coins - ? WHERE id = ?').run(amount, cost, userId),
        server: () => db.prepare('UPDATE users SET servers = servers + 1, coins = coins - ? WHERE id = ?').run(cost, userId),
    };

    updates[item]();
    logActivity(userId, 'coin_purchase', `Bought ${item} (+${amount}) for ${cost} coins`);
    return { cost, item, amount };
}

module.exports = {
    createStripeSession, handleStripeWebhook, verifyStripeSession,
    createUpiPayment, verifyUpiPayment, adminConfirmUpi,
    buyWithCoins,
};
