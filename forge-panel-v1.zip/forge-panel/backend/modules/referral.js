const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const { logActivity } = require('./logger');
const crypto = require('crypto');

const config = loadConfig();

function generateCode() {
    return crypto.randomBytes(4).toString('hex').toUpperCase();
}

function getOrCreateCode(userId) {
    const db = getDb();
    const user = db.prepare('SELECT referral_code FROM users WHERE id = ?').get(userId);
    if (user.referral_code) return user.referral_code;
    const code = generateCode();
    db.prepare('UPDATE users SET referral_code = ? WHERE id = ?').run(code, userId);
    return code;
}

function applyReferral(newUserId, code) {
    if (!config.referral?.enabled) return false;
    const db = getDb();

    const referrer = db.prepare('SELECT * FROM users WHERE referral_code = ?').get(code);
    if (!referrer || referrer.id === newUserId) return false;

    const existing = db.prepare('SELECT * FROM referrals WHERE referee_id = ?').get(newUserId);
    if (existing) return false;

    const referrerCoins = config.referral.referrer_coins || 200;
    const refereeCoins = config.referral.referee_coins || 100;

    db.prepare('INSERT INTO referrals (referrer_id, referee_id, coins_given) VALUES (?, ?, ?)').run(referrer.id, newUserId, referrerCoins);
    db.prepare('UPDATE users SET coins = coins + ?, referred_by = ? WHERE id = ?').run(refereeCoins, referrer.id, newUserId);
    db.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').run(referrerCoins, referrer.id);

    logActivity(referrer.id, 'referral_reward', `Earned ${referrerCoins} coins — referred user #${newUserId}`);
    logActivity(newUserId, 'referral_bonus', `Earned ${refereeCoins} coins — used referral code`);
    return true;
}

function getStats(userId) {
    const db = getDb();
    const code = getOrCreateCode(userId);
    const referrals = db.prepare(`
        SELECT r.*, u.username, u.created_at as joined_at
        FROM referrals r JOIN users u ON r.referee_id = u.id
        WHERE r.referrer_id = ?
        ORDER BY r.created_at DESC
    `).all(userId);

    const totalCoins = referrals.reduce((s, r) => s + r.coins_given, 0);
    return { code, referrals, totalCoins, count: referrals.length };
}

module.exports = { generateCode, getOrCreateCode, applyReferral, getStats };
