const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const axios = require('axios');

const config = loadConfig();

const COLORS = {
    login: 0x5865F2,
    register: 0x57F287,
    payment: 0xFEE75C,
    server: 0xEB459E,
    admin: 0xED4245,
    default: 0x99AAB5,
};

function logActivity(userId, action, details, ip = null) {
    try {
        const db = getDb();
        db.prepare(`
            INSERT INTO activity_log (user_id, action, details, ip) VALUES (?, ?, ?, ?)
        `).run(userId, action, details, ip);

        if (config.logging?.enabled && config.logging?.webhook) {
            sendWebhook(userId, action, details).catch(() => {});
        }
    } catch (e) {
        console.error('Logger error:', e.message);
    }
}

async function sendWebhook(userId, action, details) {
    const cfg = config.logging;
    if (!cfg?.enabled || !cfg?.webhook) return;

    const skip = {
        login: !cfg.log_logins,
        register: !cfg.log_registrations,
        stripe_payment: !cfg.log_payments,
        upi_payment_confirmed: !cfg.log_payments,
    };
    if (skip[action]) return;

    const color = COLORS[action.includes('payment') ? 'payment' :
        action.includes('server') ? 'server' :
        action.includes('admin') ? 'admin' :
        action.includes('login') ? 'login' :
        action.includes('register') ? 'register' : 'default'];

    await axios.post(cfg.webhook, {
        embeds: [{
            title: `🔔 ${action.replace(/_/g, ' ').toUpperCase()}`,
            description: details,
            color,
            fields: [{ name: 'User ID', value: String(userId), inline: true }],
            timestamp: new Date().toISOString(),
            footer: { text: 'Forge Panel' },
        }]
    });
}

function getActivityLog(userId = null, limit = 50) {
    const db = getDb();
    if (userId) {
        return db.prepare('SELECT * FROM activity_log WHERE user_id = ? ORDER BY created_at DESC LIMIT ?').all(userId, limit);
    }
    return db.prepare('SELECT * FROM activity_log ORDER BY created_at DESC LIMIT ?').all(limit);
}

module.exports = { logActivity, getActivityLog };
