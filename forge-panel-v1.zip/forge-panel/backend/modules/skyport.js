const axios = require('axios');
const { loadConfig } = require('../handlers/config');

const config = loadConfig();

const skyport = axios.create({
    baseURL: config.skyport.domain + '/api',
    headers: {
        'Authorization': `Bearer ${config.skyport.key}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    },
    timeout: 15000,
});

async function getNodes() {
    const res = await skyport.get('/nodes');
    return res.data;
}

async function getImages() {
    const res = await skyport.get('/images');
    return res.data;
}

async function createUser(email, username, password) {
    const res = await skyport.post('/users', { email, username, password, admin: false });
    return res.data;
}

async function createServer({ name, userId, node, image, ram, disk, cpu, ports = [] }) {
    const res = await skyport.post('/servers', {
        name, userId, node, image,
        limits: { memory: ram, disk, cpu },
        ports,
    });
    return res.data;
}

async function getServer(serverId) {
    const res = await skyport.get(`/servers/${serverId}`);
    return res.data;
}

async function getUserServers(userId) {
    const res = await skyport.get(`/users/${userId}/servers`);
    return res.data;
}

async function suspendServer(serverId) {
    await skyport.post(`/servers/${serverId}/suspend`);
}

async function unsuspendServer(serverId) {
    await skyport.post(`/servers/${serverId}/unsuspend`);
}

async function deleteServer(serverId) {
    await skyport.delete(`/servers/${serverId}`);
}

async function getServerStats(serverId) {
    try {
        const res = await skyport.get(`/servers/${serverId}/stats`);
        return res.data;
    } catch {
        return null;
    }
}

module.exports = {
    getNodes, getImages, createUser, createServer,
    getServer, getUserServers, suspendServer, unsuspendServer,
    deleteServer, getServerStats,
};
