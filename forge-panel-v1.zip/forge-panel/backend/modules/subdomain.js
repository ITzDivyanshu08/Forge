const axios = require('axios');
const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const { logActivity } = require('./logger');

const config = loadConfig();

function getCfApi() {
    return axios.create({
        baseURL: 'https://api.cloudflare.com/client/v4',
        headers: {
            'Authorization': `Bearer ${config.cloudflare.api_token}`,
            'Content-Type': 'application/json',
        },
        timeout: 10000,
    });
}

async function createSubdomain(userId, serverId, subdomain, domainConfig, target) {
    if (!config.cloudflare?.enabled) throw new Error('Cloudflare not enabled');
    const db = getDb();
    const cf = getCfApi();

    const existing = db.prepare('SELECT COUNT(*) as c FROM subdomains WHERE server_id = ?').get(serverId);
    if (existing.c >= (config.cloudflare.max_per_server || 2)) {
        throw new Error('Maximum subdomains per server reached');
    }

    const fqdn = `${subdomain}.${domainConfig.domain}`;
    const existing2 = db.prepare('SELECT * FROM subdomains WHERE subdomain = ? AND domain = ?').get(subdomain, domainConfig.domain);
    if (existing2) throw new Error('Subdomain already taken');

    const res = await cf.post(`/zones/${domainConfig.zone_id}/dns_records`, {
        type: 'CNAME',
        name: fqdn,
        content: target,
        proxied: true,
        ttl: 1,
    });

    if (!res.data.success) throw new Error('Cloudflare API error: ' + res.data.errors[0]?.message);
    const recordId = res.data.result.id;

    db.prepare(`
        INSERT INTO subdomains (user_id, server_id, subdomain, domain, cf_record_id, target)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, serverId, subdomain, domainConfig.domain, recordId, target);

    logActivity(userId, 'subdomain_created', `Created ${fqdn} → ${target}`);
    return { fqdn, recordId };
}

async function deleteSubdomain(subdomainId, userId) {
    if (!config.cloudflare?.enabled) throw new Error('Cloudflare not enabled');
    const db = getDb();
    const cf = getCfApi();

    const record = db.prepare('SELECT * FROM subdomains WHERE id = ? AND user_id = ?').get(subdomainId, userId);
    if (!record) throw new Error('Subdomain not found');

    const domainConfig = config.cloudflare.domains.find(d => d.domain === record.domain);
    if (!domainConfig) throw new Error('Domain config not found');

    await cf.delete(`/zones/${domainConfig.zone_id}/dns_records/${record.cf_record_id}`).catch(() => {});
    db.prepare('DELETE FROM subdomains WHERE id = ?').run(subdomainId);

    logActivity(userId, 'subdomain_deleted', `Deleted ${record.subdomain}.${record.domain}`);
}

function getUserSubdomains(userId) {
    const db = getDb();
    return db.prepare('SELECT * FROM subdomains WHERE user_id = ? ORDER BY created_at DESC').all(userId);
}

function getAvailableDomains() {
    if (!config.cloudflare?.enabled) return [];
    return (config.cloudflare.domains || []).filter(d => d.enabled);
}

module.exports = { createSubdomain, deleteSubdomain, getUserSubdomains, getAvailableDomains };
