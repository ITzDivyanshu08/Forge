const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const { logActivity } = require('./logger');

const config = loadConfig();

function getStreakMultiplier(streak) {
    const { daily } = config;
    if (streak >= 30) return daily.streak_bonus_day30 || 3.0;
    if (streak >= 14) return daily.streak_bonus_day14 || 2.0;
    if (streak >= 7)  return daily.streak_bonus_day7  || 1.5;
    return 1.0;
}

function canClaim(userId) {
    const db = getDb();
    const last = db.prepare(`
        SELECT claimed_at, streak FROM daily_rewards
        WHERE user_id = ? ORDER BY claimed_at DESC LIMIT 1
    `).get(userId);

    if (!last) return { can: true, streak: 0, nextIn: null };

    const now = new Date();
    const lastClaim = new Date(last.claimed_at);
    const hoursSince = (now - lastClaim) / 1000 / 3600;

    if (hoursSince < 20) {
        const nextIn = Math.ceil((20 - hoursSince) * 60);
        return { can: false, streak: last.streak, nextIn };
    }

    // Streak resets if more than 48h since last claim
    const streakBroken = hoursSince > 48;
    return { can: true, streak: streakBroken ? 0 : last.streak, nextIn: null };
}

function claim(userId) {
    const db = getDb();
    const { can, streak } = canClaim(userId);
    if (!can) throw new Error('Already claimed today');

    const newStreak = streak + 1;
    const base = config.daily.base_coins || 25;
    const multiplier = getStreakMultiplier(newStreak);
    const coinsEarned = Math.floor(base * multiplier);

    db.prepare(`
        INSERT INTO daily_rewards (user_id, streak, coins_earned)
        VALUES (?, ?, ?)
    `).run(userId, newStreak, coinsEarned);

    db.prepare(`
        UPDATE users SET coins = coins + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).run(coinsEarned, userId);

    logActivity(userId, 'daily_claim', `Claimed ${coinsEarned} coins (streak: ${newStreak})`);

    return { coinsEarned, streak: newStreak, multiplier };
}

function getHistory(userId, limit = 7) {
    const db = getDb();
    return db.prepare(`
        SELECT * FROM daily_rewards WHERE user_id = ?
        ORDER BY claimed_at DESC LIMIT ?
    `).all(userId, limit);
}

function getStreakInfo(userId) {
    const db = getDb();
    const last = db.prepare(`
        SELECT streak, claimed_at FROM daily_rewards
        WHERE user_id = ? ORDER BY claimed_at DESC LIMIT 1
    `).get(userId);

    const { can, nextIn } = canClaim(userId);
    const streak = last?.streak || 0;
    const multiplier = getStreakMultiplier(streak + 1);
    const base = config.daily.base_coins || 25;
    const nextReward = Math.floor(base * multiplier);

    return { streak, can, nextIn, nextReward, multiplier };
}

module.exports = { canClaim, claim, getHistory, getStreakInfo };
