const { getDb } = require('../db');
const { loadConfig } = require('../handlers/config');
const { logActivity } = require('./logger');
const ptero = require('./pterodactyl');
const skyport = require('./skyport');
const cron = require('node-cron');

const config = loadConfig();

function getRenewalCost(server) {
    // Cost in credits based on server resources
    const ramCost  = Math.floor(server.ram / 512);
    const diskCost = Math.floor(server.disk / 1024);
    const cpuCost  = Math.floor(server.cpu / 50);
    return ramCost + diskCost + cpuCost;
}

function setExpiry(serverId, days) {
    const db = getDb();
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + days);
    db.prepare('UPDATE servers SET expires_at = ? WHERE id = ?').run(expiry.toISOString(), serverId);
    return expiry;
}

async function renewServer(userId, serverId) {
    const db = getDb();
    const server = db.prepare('SELECT * FROM servers WHERE id = ? AND user_id = ?').get(serverId, userId);
    if (!server) throw new Error('Server not found');

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    const cost = getRenewalCost(server);
    const days = config.renewal.period_days || 30;

    if (user.credits < cost) throw new Error(`Not enough credits (need ${cost})`);

    db.prepare('UPDATE users SET credits = credits - ? WHERE id = ?').run(cost, userId);

    const newExpiry = new Date(server.expires_at || new Date());
    newExpiry.setDate(newExpiry.getDate() + days);
    db.prepare('UPDATE servers SET expires_at = ?, suspended = 0 WHERE id = ?').run(newExpiry.toISOString(), serverId);

    // Unsuspend if it was suspended
    if (server.suspended) {
        try {
            if (server.daemon_type === 'pterodactyl' && server.pterodactyl_id) {
                await ptero.unsuspendServer(server.pterodactyl_id);
            } else if (server.daemon_type === 'skyport' && server.skyport_id) {
                await skyport.unsuspendServer(server.skyport_id);
            }
        } catch (e) {
            console.error('Failed to unsuspend server:', e.message);
        }
    }

    logActivity(userId, 'server_renewed', `Renewed server ${serverId} for ${cost} credits (+${days} days)`);
    return { cost, days, newExpiry };
}

async function checkRenewals() {
    if (!config.renewal?.enabled) return;
    const db = getDb();
    const now = new Date();
    const warnDays = config.renewal.warning_days || 3;
    const deleteDays = config.renewal.auto_delete_after_days || 7;

    const servers = db.prepare('SELECT * FROM servers WHERE expires_at IS NOT NULL AND suspended = 0').all();

    for (const server of servers) {
        const expiry = new Date(server.expires_at);
        const daysLeft = (expiry - now) / 1000 / 86400;

        if (daysLeft <= 0 && !server.suspended) {
            // Suspend expired servers
            try {
                if (server.daemon_type === 'pterodactyl' && server.pterodactyl_id) {
                    await ptero.suspendServer(server.pterodactyl_id);
                } else if (server.daemon_type === 'skyport' && server.skyport_id) {
                    await skyport.suspendServer(server.skyport_id);
                }
                db.prepare('UPDATE servers SET suspended = 1 WHERE id = ?').run(server.id);
                logActivity(server.user_id, 'server_suspended_expiry', `Server ${server.id} suspended — expired`);
            } catch (e) {
                console.error('Failed to suspend:', e.message);
            }
        }

        if (daysLeft <= -deleteDays) {
            // Delete servers past grace period
            try {
                if (server.daemon_type === 'pterodactyl' && server.pterodactyl_id) {
                    await ptero.deleteServer(server.pterodactyl_id);
                } else if (server.daemon_type === 'skyport' && server.skyport_id) {
                    await skyport.deleteServer(server.skyport_id);
                }
                db.prepare('DELETE FROM servers WHERE id = ?').run(server.id);
                logActivity(server.user_id, 'server_deleted_expiry', `Server ${server.id} deleted — past grace period`);
            } catch (e) {
                console.error('Failed to delete:', e.message);
            }
        }
    }
}

function startRenewalCron() {
    if (!config.renewal?.enabled) return;
    const interval = config.renewal.check_interval_minutes || 30;
    cron.schedule(`*/${interval} * * * *`, checkRenewals);
    console.log(`✅ Renewal checker running every ${interval} minutes`);
}

module.exports = { getRenewalCost, setExpiry, renewServer, checkRenewals, startRenewalCron };
