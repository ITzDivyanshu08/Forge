const axios = require('axios');
const { loadConfig } = require('../handlers/config');

const config = loadConfig();

const ptero = axios.create({
    baseURL: config.pterodactyl.domain + '/api',
    headers: {
        'Authorization': `Bearer ${config.pterodactyl.key}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    },
    timeout: 15000,
});

const pteroClient = axios.create({
    baseURL: config.pterodactyl.domain + '/api/client',
    headers: {
        'Authorization': `Bearer ${config.pterodactyl.client_key}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    },
    timeout: 15000,
});

// ── Application API (admin) ──────────────────────────────────

async function createUser(email, username, firstName, lastName, password) {
    const res = await ptero.post('/application/users', {
        email, username,
        first_name: firstName,
        last_name: lastName,
        password,
    });
    return res.data.attributes;
}

async function getUser(pterodactylId) {
    const res = await ptero.get(`/application/users/${pterodactylId}`);
    return res.data.attributes;
}

async function getUserByEmail(email) {
    const res = await ptero.get(`/application/users?filter[email]=${encodeURIComponent(email)}`);
    const users = res.data.data;
    return users.length > 0 ? users[0].attributes : null;
}

async function updateUserPassword(pterodactylId, email, username, firstName, lastName, password) {
    const res = await ptero.patch(`/application/users/${pterodactylId}`, {
        email, username,
        first_name: firstName,
        last_name: lastName,
        password,
        root_admin: false,
    });
    return res.data.attributes;
}

async function deleteUser(pterodactylId) {
    await ptero.delete(`/application/users/${pterodactylId}`);
}

async function getNodes() {
    const res = await ptero.get('/application/nodes');
    return res.data.data.map(n => n.attributes);
}

async function getNode(nodeId) {
    const res = await ptero.get(`/application/nodes/${nodeId}`);
    return res.data.attributes;
}

async function getAllocations(nodeId) {
    const res = await ptero.get(`/application/nodes/${nodeId}/allocations`);
    return res.data.data.map(a => a.attributes);
}

async function getEggs(nestId = 1) {
    const res = await ptero.get(`/application/nests/${nestId}/eggs?include=variables`);
    return res.data.data.map(e => e.attributes);
}

async function getNests() {
    const res = await ptero.get('/application/nests');
    return res.data.data.map(n => n.attributes);
}

async function createServer({ name, userId, egg, ram, disk, cpu, allocationId, variables = {}, startupCmd = null }) {
    const eggData = (await ptero.get(`/application/eggs/${egg}?include=variables`)).data.attributes;
    const envVars = {};
    eggData.relationships.variables.data.forEach(v => {
        const attr = v.attributes;
        envVars[attr.env_variable] = variables[attr.env_variable] || attr.default_value || '';
    });
    const body = {
        name,
        user: userId,
        egg,
        docker_image: eggData.docker_image,
        startup: startupCmd || eggData.startup,
        environment: envVars,
        limits: { memory: ram, swap: 0, disk, io: 500, cpu },
        feature_limits: { databases: 1, backups: 2, allocations: 1 },
        allocation: { default: allocationId },
    };
    const res = await ptero.post('/application/servers', body);
    return res.data.attributes;
}

async function suspendServer(serverId) {
    await ptero.post(`/application/servers/${serverId}/suspend`);
}

async function unsuspendServer(serverId) {
    await ptero.post(`/application/servers/${serverId}/unsuspend`);
}

async function deleteServer(serverId) {
    await ptero.delete(`/application/servers/${serverId}`);
}

async function getUserServers(pterodactylId) {
    const res = await ptero.get(`/application/users/${pterodactylId}?include=servers`);
    const servers = res.data.attributes.relationships?.servers?.data || [];
    return servers.map(s => s.attributes);
}

async function getServer(serverId) {
    const res = await ptero.get(`/application/servers/${serverId}`);
    return res.data.attributes;
}

// ── Client API ────────────────────────────────────────────────

async function getServerResources(serverIdentifier) {
    try {
        const res = await pteroClient.get(`/servers/${serverIdentifier}/resources`);
        return res.data.attributes;
    } catch {
        return null;
    }
}

async function sendPowerAction(serverIdentifier, action) {
    await pteroClient.post(`/servers/${serverIdentifier}/power`, { signal: action });
}

async function sendCommand(serverIdentifier, command) {
    await pteroClient.post(`/servers/${serverIdentifier}/command`, { command });
}

async function getServerWsCredentials(serverIdentifier) {
    const res = await pteroClient.get(`/servers/${serverIdentifier}/websocket`);
    return res.data.data;
}

async function getFiles(serverIdentifier, directory = '/') {
    const res = await pteroClient.get(`/servers/${serverIdentifier}/files/list?directory=${encodeURIComponent(directory)}`);
    return res.data.data.map(f => f.attributes);
}

async function getFileContents(serverIdentifier, file) {
    const res = await pteroClient.get(`/servers/${serverIdentifier}/files/contents?file=${encodeURIComponent(file)}`);
    return res.data;
}

async function writeFile(serverIdentifier, file, contents) {
    await pteroClient.post(`/servers/${serverIdentifier}/files/write?file=${encodeURIComponent(file)}`, contents, {
        headers: { 'Content-Type': 'text/plain' }
    });
}

async function getBackups(serverIdentifier) {
    const res = await pteroClient.get(`/servers/${serverIdentifier}/backups`);
    return res.data.data.map(b => b.attributes);
}

async function createBackup(serverIdentifier) {
    const res = await pteroClient.post(`/servers/${serverIdentifier}/backups`);
    return res.data.attributes;
}

module.exports = {
    createUser, getUser, getUserByEmail, updateUserPassword, deleteUser,
    getNodes, getNode, getAllocations, getEggs, getNests,
    createServer, suspendServer, unsuspendServer, deleteServer,
    getUserServers, getServer,
    getServerResources, sendPowerAction, sendCommand, getServerWsCredentials,
    getFiles, getFileContents, writeFile, getBackups, createBackup,
};
