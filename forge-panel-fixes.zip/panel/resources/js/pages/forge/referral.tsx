import { Head } from '@inertiajs/react';
import { Copy, Check, Link2, Users } from 'lucide-react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';

interface Referral { id: number; coins_given: number; referee: { name: string; created_at: string }; }
interface Props { code: string; referrals: Referral[]; total_coins: number; referrer_coins: number; referee_coins: number; }

export default function Referral({ code, referrals, total_coins, referrer_coins, referee_coins }: Props) {
    const [copied, setCopied] = useState(false);
    const link = `${window.location.origin}/register?ref=${code}`;

    const copy = (text: string) => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Referrals', href: '/referral' }]}>
            <Head title="Referrals" />
            <div className="flex flex-col gap-6 p-6 max-w-lg">
                <div>
                    <h1 className="text-2xl font-bold">Referrals</h1>
                    <p className="text-muted-foreground text-sm mt-1">Earn coins when friends sign up with your link</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl border border-border bg-card p-4 text-center">
                        <Users size={20} className="mx-auto mb-1 text-brand" />
                        <p className="text-2xl font-bold">{referrals.length}</p>
                        <p className="text-xs text-muted-foreground">Referrals</p>
                    </div>
                    <div className="rounded-xl border border-border bg-card p-4 text-center">
                        <p className="text-2xl font-bold text-brand">{total_coins.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">🪙 Total Earned</p>
                    </div>
                </div>
                <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                    <h2 className="font-semibold">Your Referral Link</h2>
                    <div className="flex gap-2">
                        <input readOnly value={link} className="flex-1 rounded-lg border border-border bg-sidebar px-3 py-2 text-xs font-mono" />
                        <button onClick={() => copy(link)} className="px-3 rounded-lg border border-border hover:opacity-70">
                            {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                        </button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                        <div className="rounded-lg bg-brand/5 border border-brand/20 p-3 text-center">
                            <p className="font-bold text-brand">{referrer_coins.toLocaleString()} 🪙</p>
                            <p className="text-xs text-muted-foreground">You earn</p>
                        </div>
                        <div className="rounded-lg bg-green-500/5 border border-green-500/20 p-3 text-center">
                            <p className="font-bold text-green-500">{referee_coins.toLocaleString()} 🪙</p>
                            <p className="text-xs text-muted-foreground">They earn</p>
                        </div>
                    </div>
                </div>
                {referrals.length > 0 && (
                    <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                        <h2 className="font-semibold">History</h2>
                        {referrals.map(r => (
                            <div key={r.id} className="flex items-center justify-between text-sm">
                                <div>
                                    <p className="font-medium">{r.referee.name}</p>
                                    <p className="text-xs text-muted-foreground">{new Date(r.referee.created_at).toLocaleDateString()}</p>
                                </div>
                                <span className="font-bold text-brand">+{r.coins_given} 🪙</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
