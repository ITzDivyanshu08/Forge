import { Head } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '@/layouts/app-layout';
import { Globe, Trash2, Plus, ExternalLink } from 'lucide-react';

interface Subdomain {
    id: number;
    subdomain: string;
    domain: string;
    target: string;
    server: { id: number; name: string } | null;
    created_at: string;
}

interface Server {
    id: number;
    name: string;
}

interface Props {
    subdomains: Subdomain[];
    domains: string[];
    servers?: Server[];
}

export default function Subdomains({ subdomains, domains, servers = [] }: Props) {
    const [form, setForm] = useState({ server_id: '', subdomain: '', domain: domains[0] ?? '', target: '' });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [showForm, setShowForm] = useState(false);
    const [list, setList] = useState<Subdomain[]>(subdomains);

    const csrf = () =>
        (document.querySelector('meta[name="csrf-token"]') as HTMLMetaElement)?.content ?? '';

    const create = async () => {
        setError('');
        if (!form.server_id || !form.subdomain || !form.domain || !form.target) {
            setError('All fields are required.');
            return;
        }
        setLoading(true);
        try {
            const res = await fetch('/subdomains', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), Accept: 'application/json' },
                body: JSON.stringify(form),
            });
            const data = await res.json();
            if (!res.ok) {
                setError(data.error ?? 'Failed to create subdomain.');
            } else {
                // Refresh subdomains list
                window.location.reload();
            }
        } catch {
            setError('Network error. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const remove = async (id: number) => {
        if (!confirm('Delete this subdomain? This will remove the Cloudflare DNS record.')) return;
        try {
            const res = await fetch(`/subdomains/${id}`, {
                method: 'DELETE',
                headers: { 'X-CSRF-TOKEN': csrf(), Accept: 'application/json' },
            });
            if (res.ok) {
                setList(list.filter(s => s.id !== id));
            }
        } catch {
            alert('Failed to delete subdomain.');
        }
    };

    return (
        <AppLayout breadcrumbs={[{ title: 'Subdomains', href: '/subdomains' }]}>
            <Head title="Subdomains" />
            <div className="flex flex-col gap-6 p-6 max-w-2xl">

                {/* Header */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold">Subdomains</h1>
                        <p className="text-muted-foreground text-sm mt-1">
                            Manage Cloudflare CNAME records for your servers
                        </p>
                    </div>
                    <button
                        onClick={() => setShowForm(v => !v)}
                        className="flex items-center gap-2 rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90 transition-opacity"
                    >
                        <Plus size={15} />
                        New Subdomain
                    </button>
                </div>

                {/* Create form */}
                {showForm && (
                    <div className="rounded-xl border border-border bg-card p-5 space-y-4">
                        <h2 className="font-semibold text-sm">Create Subdomain</h2>

                        {error && (
                            <p className="rounded-lg bg-red-500/10 border border-red-500/20 px-3 py-2 text-sm text-red-500">
                                {error}
                            </p>
                        )}

                        <div className="grid grid-cols-2 gap-3">
                            <div className="col-span-2">
                                <label className="text-xs text-muted-foreground mb-1 block">Server</label>
                                <select
                                    value={form.server_id}
                                    onChange={e => setForm({ ...form, server_id: e.target.value })}
                                    className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                >
                                    <option value="">Select a server…</option>
                                    {servers.map(s => (
                                        <option key={s.id} value={s.id}>{s.name}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Subdomain</label>
                                <input
                                    value={form.subdomain}
                                    onChange={e => setForm({ ...form, subdomain: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') })}
                                    placeholder="myserver"
                                    className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm font-mono"
                                />
                            </div>

                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Domain</label>
                                <select
                                    value={form.domain}
                                    onChange={e => setForm({ ...form, domain: e.target.value })}
                                    className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm"
                                >
                                    {domains.filter(Boolean).map(d => (
                                        <option key={d} value={d}>{d}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="col-span-2">
                                <label className="text-xs text-muted-foreground mb-1 block">Target (IP or hostname)</label>
                                <input
                                    value={form.target}
                                    onChange={e => setForm({ ...form, target: e.target.value })}
                                    placeholder="node.example.com or 1.2.3.4"
                                    className="w-full rounded-lg border border-border bg-sidebar px-3 py-2 text-sm font-mono"
                                />
                            </div>
                        </div>

                        {form.subdomain && form.domain && (
                            <p className="text-xs text-muted-foreground font-mono">
                                → <span className="text-brand">{form.subdomain}.{form.domain}</span> will CNAME to <span className="text-brand">{form.target || '…'}</span>
                            </p>
                        )}

                        <div className="flex gap-2 justify-end">
                            <button
                                onClick={() => { setShowForm(false); setError(''); }}
                                className="rounded-lg border border-border px-4 py-2 text-sm hover:opacity-70"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={create}
                                disabled={loading}
                                className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-50"
                            >
                                {loading ? 'Creating…' : 'Create'}
                            </button>
                        </div>
                    </div>
                )}

                {/* Subdomain list */}
                {list.length === 0 ? (
                    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border p-12 text-center gap-3">
                        <Globe size={32} className="text-muted-foreground/40" />
                        <div>
                            <p className="font-medium">No subdomains yet</p>
                            <p className="text-sm text-muted-foreground mt-1">
                                Create a subdomain to get a custom URL for your server
                            </p>
                        </div>
                        <button
                            onClick={() => setShowForm(true)}
                            className="mt-2 rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90"
                        >
                            Create your first subdomain
                        </button>
                    </div>
                ) : (
                    <div className="rounded-xl border border-border bg-card divide-y divide-border overflow-hidden">
                        {list.map(sub => (
                            <div key={sub.id} className="flex items-center justify-between px-4 py-3 gap-4">
                                <div className="flex items-center gap-3 min-w-0">
                                    <Globe size={16} className="text-brand shrink-0" />
                                    <div className="min-w-0">
                                        <div className="flex items-center gap-1.5">
                                            <span className="font-mono text-sm font-medium truncate">
                                                {sub.subdomain}.{sub.domain}
                                            </span>
                                            <a
                                                href={`https://${sub.subdomain}.${sub.domain}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="text-muted-foreground hover:text-brand shrink-0"
                                            >
                                                <ExternalLink size={11} />
                                            </a>
                                        </div>
                                        <p className="text-xs text-muted-foreground truncate">
                                            → {sub.target}
                                            {sub.server && (
                                                <span className="ml-2 text-brand/70">({sub.server.name})</span>
                                            )}
                                        </p>
                                    </div>
                                </div>
                                <button
                                    onClick={() => remove(sub.id)}
                                    className="shrink-0 rounded-lg p-1.5 text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors"
                                    title="Delete subdomain"
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
