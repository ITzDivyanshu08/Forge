<?php

namespace App\Actions\Fortify;

use App\Concerns\PasswordValidationRules;
use App\Concerns\ProfileValidationRules;
use App\Models\User;
use App\Services\ReferralService;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules, ProfileValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
    public function create(array $input): User
    {
        Validator::make($input, [
            ...$this->profileRules(),
            'password' => $this->passwordRules(),
        ])->validate();

        $user = User::query()->create([
            'name'          => $input['name'],
            'email'         => $input['email'],
            'password'      => $input['password'],
            'referral_code' => ReferralService::generateCode(),
        ]);

        // Apply referral if a ref code was passed (e.g. /register?ref=XXXX)
        if (! empty($input['referral_code'])) {
            app(ReferralService::class)->apply($user, $input['referral_code']);
        }

        return $user;
    }
}
