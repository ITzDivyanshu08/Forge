<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Announcement;
use App\Models\ForgeNotification;
use App\Models\RedeemCode;
use App\Models\Server;
use App\Models\Ticket;
use App\Models\TicketMessage;
use App\Models\Transaction;
use App\Models\User;
use App\Services\BillingService;
use App\Services\NotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

// ── Admin Billing ─────────────────────────────────────────────

class AdminBillingController extends Controller
{
    public function index(): Response
    {
        $transactions = Transaction::with('user:id,name,email')
            ->latest()->paginate(50);
        $pendingUpi = Transaction::where('gateway', 'upi')->where('status', 'verifying')->count();
        $totalRevenue = Transaction::where('status', 'completed')->sum('amount');

        return Inertia::render('admin/forge/billing', compact('transactions', 'pendingUpi', 'totalRevenue'));
    }

    public function confirmUpi(string $uuid): JsonResponse
    {
        try {
            $tx = app(BillingService::class)->confirmUpi($uuid);
            return response()->json(['success' => true, 'coins' => $tx->coins_given]);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }

    public function rejectUpi(string $uuid): JsonResponse
    {
        $tx = Transaction::where('uuid', $uuid)->where('status', 'verifying')->firstOrFail();
        $tx->update(['status' => 'failed']);
        app(NotificationService::class)->notifyAll(
            $tx->user, 'payment',
            'UPI Payment Rejected',
            "Your UPI payment of ₹{$tx->amount} was rejected. Contact support if you believe this is an error."
        );
        return response()->json(['success' => true]);
    }
}

// ── Admin Redeem Codes ─────────────────────────────────────────

class AdminRedeemController extends Controller
{
    public function index(): Response
    {
        $codes = RedeemCode::with('creator:id,name')->withCount('codeUses')->latest()->paginate(30);
        return Inertia::render('admin/forge/redeem-codes', compact('codes'));
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'coins'       => 'required|integer|min:1',
            'max_uses'    => 'required|integer|min:1',
            'description' => 'nullable|string|max:200',
            'expires_at'  => 'nullable|date',
            'code'        => 'nullable|string|max:30|alpha_dash',
        ]);

        $code = strtoupper($request->code ?: Str::random(10));
        if (RedeemCode::where('code', $code)->exists()) {
            return response()->json(['error' => 'Code already exists'], 400);
        }

        $redeemCode = RedeemCode::create([
            'code'        => $code,
            'coins'       => $request->coins,
            'max_uses'    => $request->max_uses,
            'description' => $request->description,
            'expires_at'  => $request->expires_at,
            'created_by'  => auth()->id(),
            'active'      => true,
        ]);

        return response()->json(['success' => true, 'code' => $redeemCode->code]);
    }

    public function toggle(int $id): JsonResponse
    {
        $code = RedeemCode::findOrFail($id);
        $code->update(['active' => ! $code->active]);
        return response()->json(['success' => true, 'active' => $code->active]);
    }

    public function destroy(int $id): JsonResponse
    {
        RedeemCode::findOrFail($id)->delete();
        return response()->json(['success' => true]);
    }
}

// ── Admin Announcements ────────────────────────────────────────

class AdminAnnouncementController extends Controller
{
    public function index(): Response
    {
        $announcements = Announcement::with('creator:id,name')->latest()->get();
        return Inertia::render('admin/forge/announcements', compact('announcements'));
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'title'      => 'required|string|max:200',
            'content'    => 'required|string|max:2000',
            'type'       => 'required|in:info,warning,danger,success',
            'expires_at' => 'nullable|date',
        ]);

        $ann = Announcement::create([
            'title'      => $request->title,
            'content'    => $request->content,
            'type'       => $request->type,
            'active'     => true,
            'expires_at' => $request->expires_at,
            'created_by' => auth()->id(),
        ]);

        return response()->json(['success' => true, 'id' => $ann->id]);
    }

    public function toggle(int $id): JsonResponse
    {
        $ann = Announcement::findOrFail($id);
        $ann->update(['active' => ! $ann->active]);
        return response()->json(['success' => true, 'active' => $ann->active]);
    }

    public function destroy(int $id): JsonResponse
    {
        Announcement::findOrFail($id)->delete();
        return response()->json(['success' => true]);
    }
}

// ── Admin Tickets ──────────────────────────────────────────────

class AdminTicketController extends Controller
{
    public function index(): Response
    {
        $tickets = Ticket::with(['user:id,name,email', 'messages' => fn($q) => $q->latest()->limit(1)])
            ->latest()->paginate(30);
        return Inertia::render('admin/forge/tickets', compact('tickets'));
    }

    public function show(int $id): Response
    {
        $ticket = Ticket::with(['messages.user', 'user'])->findOrFail($id);
        return Inertia::render('admin/forge/ticket-show', compact('ticket'));
    }

    public function reply(Request $request, int $id): RedirectResponse
    {
        $request->validate(['message' => 'required|string|max:5000']);
        $ticket = Ticket::findOrFail($id);

        TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id'   => auth()->id(),
            'message'   => $request->message,
            'is_staff'  => true,
        ]);

        $ticket->update(['status' => 'in_progress', 'updated_at' => now()]);

        app(NotificationService::class)->notifyAll(
            $ticket->user,
            'ticket',
            'Ticket Reply',
            "Staff replied to your ticket: \"{$ticket->subject}\""
        );

        return back();
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $request->validate(['status' => 'required|in:open,in_progress,closed']);
        Ticket::findOrFail($id)->update(['status' => $request->status]);
        return response()->json(['success' => true]);
    }
}

// ── Admin Users (Forge additions) ─────────────────────────────

class AdminUserForgeController extends Controller
{
    public function gift(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'coins' => 'nullable|integer|min:0',
            'ram'   => 'nullable|integer|min:0',
            'disk'  => 'nullable|integer|min:0',
            'cpu'   => 'nullable|integer|min:0',
        ]);

        $user = User::findOrFail($id);

        if ($request->coins)  $user->increment('coins', $request->coins);
        if ($request->ram)    $user->increment('ram_limit', $request->ram);
        if ($request->disk)   $user->increment('disk_limit', $request->disk);
        if ($request->cpu)    $user->increment('cpu_limit', $request->cpu);

        $giftDetails = collect($request->only('coins','ram','disk','cpu'))
            ->filter()->map(fn ($v, $k) => "+{$v} {$k}")->join(', ');

        app(NotificationService::class)->notifyAll(
            $user, 'gift',
            'Admin Gift!',
            "An admin gifted you: {$giftDetails}"
        );

        return response()->json(['success' => true]);
    }

    public function leaderboard(): Response
    {
        $byCoins    = User::orderByDesc('coins')->limit(10)->get(['id','name','coins','badge']);
        $byServers  = User::withCount('servers')->orderByDesc('servers_count')->limit(10)->get(['id','name','badge']);
        $byReferrals = User::withCount('referrals')->orderByDesc('referrals_count')->limit(10)->get(['id','name','badge']);

        return Inertia::render('forge/leaderboard', compact('byCoins', 'byServers', 'byReferrals'));
    }

    public function profile(int $id): Response
    {
        $user = User::withCount(['servers','referrals','tickets'])->findOrFail($id);
        $servers = Server::where('user_id', $id)->select('id','name','status','created_at')->get();
        return Inertia::render('forge/profile', compact('user', 'servers'));
    }
}

// ── Admin Maintenance ─────────────────────────────────────────

class AdminMaintenanceController extends Controller
{
    public function toggle(Request $request, int $serverId): JsonResponse
    {
        $request->validate(['message' => 'nullable|string|max:500']);
        $server = Server::findOrFail($serverId);
        $server->update([
            'maintenance_mode'    => ! $server->maintenance_mode,
            'maintenance_message' => $request->message ?? 'This server is under maintenance.',
        ]);
        return response()->json(['success' => true, 'maintenance' => $server->maintenance_mode]);
    }
}
