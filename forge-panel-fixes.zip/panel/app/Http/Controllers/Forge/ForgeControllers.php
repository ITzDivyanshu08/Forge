<?php

namespace App\Http\Controllers\Forge;

use App\Http\Controllers\Controller;
use App\Models\Announcement;
use App\Models\ForgeNotification;
use App\Models\RedeemCode;
use App\Models\Subdomain;
use App\Models\Ticket;
use App\Models\TicketMessage;
use App\Models\Transaction;
use App\Services\BillingService;
use App\Services\DailyRewardService;
use App\Services\NotificationService;
use App\Services\RedeemService;
use App\Services\ReferralService;
use App\Services\RenewalService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

// ── Daily ─────────────────────────────────────────────────────

class DailyController extends Controller
{
    public function show(): Response
    {
        $user = auth()->user();
        $info = app(DailyRewardService::class)->getInfo($user);
        $history = $user->dailyRewards()->latest()->limit(14)->get();
        return Inertia::render('forge/daily', compact('info', 'history'));
    }

    public function claim(): JsonResponse
    {
        try {
            $result = app(DailyRewardService::class)->claim(auth()->user());
            return response()->json(['success' => true, ...$result]);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }
}

// ── Billing ───────────────────────────────────────────────────

class BillingController extends Controller
{
    public function show(): Response
    {
        $user = auth()->user();
        $transactions = Transaction::where('user_id', $user->id)->latest()->limit(20)->get();
        return Inertia::render('forge/billing', compact('transactions'));
    }

    public function stripeCheckout(Request $request): JsonResponse
    {
        $request->validate(['amount' => 'required|numeric|min:10']);
        try {
            $result = app(BillingService::class)->createStripeSession(auth()->user(), $request->amount);
            return response()->json($result);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function stripeSuccess(Request $request): Response
    {
        $tx = null;
        if ($request->session_id) {
            $tx = app(BillingService::class)->verifyStripeSession($request->session_id, auth()->user());
        }
        return Inertia::render('forge/billing-success', ['transaction' => $tx]);
    }

    public function stripeWebhook(Request $request): JsonResponse
    {
        try {
            app(BillingService::class)->handleStripeWebhook(
                $request->getContent(),
                $request->header('Stripe-Signature', '')
            );
            return response()->json(['received' => true]);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }

    public function upiCreate(Request $request): JsonResponse
    {
        $request->validate(['amount' => 'required|numeric|min:10']);
        try {
            $result = app(BillingService::class)->createUpiPayment(auth()->user(), $request->amount);
            return response()->json($result);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function upiSubmitRef(Request $request): JsonResponse
    {
        $request->validate(['tx_id' => 'required|string', 'upi_ref' => 'required|string']);
        try {
            $tx = app(BillingService::class)->submitUpiRef($request->tx_id, auth()->user(), $request->upi_ref);
            return response()->json(['success' => true, 'status' => $tx->status]);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }
}

// ── Shop ──────────────────────────────────────────────────────

class ShopController extends Controller
{
    public function show(): Response
    {
        $user = auth()->user();
        $items = [
            ['id' => 'ram',    'label' => 'RAM',    'unit' => '512 MB',  'amount' => 512,  'cost' => (int) config('forge.shop.ram_cost', 10)],
            ['id' => 'disk',   'label' => 'Disk',   'unit' => '1 GB',    'amount' => 1024, 'cost' => (int) config('forge.shop.disk_cost', 5)],
            ['id' => 'cpu',    'label' => 'CPU',    'unit' => '10%',     'amount' => 10,   'cost' => (int) config('forge.shop.cpu_cost', 20)],
            ['id' => 'server', 'label' => 'Server Slot', 'unit' => '+1', 'amount' => 1,    'cost' => (int) config('forge.shop.server_cost', 500)],
        ];
        return Inertia::render('forge/shop', ['items' => $items, 'user' => $user]);
    }

    public function buy(Request $request): JsonResponse
    {
        $request->validate(['item' => 'required|in:ram,disk,cpu,server', 'amount' => 'required|integer|min:1']);
        $user = auth()->user();
        $item = $request->item;
        $amount = $request->amount;

        $costs = [
            'ram'    => (int) config('forge.shop.ram_cost', 10),
            'disk'   => (int) config('forge.shop.disk_cost', 5),
            'cpu'    => (int) config('forge.shop.cpu_cost', 20),
            'server' => (int) config('forge.shop.server_cost', 500),
        ];

        $unitAmounts = ['ram' => 512, 'disk' => 1024, 'cpu' => 10, 'server' => 1];
        $totalCost = $costs[$item] * $amount;

        if ($user->coins < $totalCost) {
            return response()->json(['error' => "Not enough coins (need {$totalCost})"], 400);
        }

        $user->decrement('coins', $totalCost);

        match ($item) {
            'ram'    => $user->increment('ram_limit', $unitAmounts['ram'] * $amount),
            'disk'   => $user->increment('disk_limit', $unitAmounts['disk'] * $amount),
            'cpu'    => $user->increment('cpu_limit', $unitAmounts['cpu'] * $amount),
            'server' => $user->increment('server_limit', 1),
        };

        Transaction::create([
            'user_id'     => $user->id,
            'type'        => 'shop',
            'gateway'     => 'coins',
            'amount'      => 0,
            'coins_given' => -$totalCost,
            'status'      => 'completed',
            'completed_at'=> now(),
            'description' => "Bought {$amount}x {$item} for {$totalCost} coins",
        ]);

        return response()->json(['success' => true, 'cost' => $totalCost, 'item' => $item]);
    }
}

// ── Referral ──────────────────────────────────────────────────

class ReferralController extends Controller
{
    public function show(): Response
    {
        $stats = app(ReferralService::class)->getStats(auth()->user());
        return Inertia::render('forge/referral', $stats);
    }
}

// ── Redeem ────────────────────────────────────────────────────

class RedeemController extends Controller
{
    public function show(): Response
    {
        return Inertia::render('forge/redeem');
    }

    public function redeem(Request $request): JsonResponse
    {
        $request->validate(['code' => 'required|string|max:50']);
        try {
            $result = app(RedeemService::class)->redeem(auth()->user(), $request->code);
            return response()->json(['success' => true, ...$result]);
        } catch (\Throwable $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }
}

// ── Tickets ───────────────────────────────────────────────────

class TicketController extends Controller
{
    public function index(): Response
    {
        $tickets = Ticket::with(['messages' => fn($q) => $q->latest()->limit(1)])
            ->where('user_id', auth()->id())->latest()->get();
        return Inertia::render('forge/tickets', compact('tickets'));
    }

    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'subject'  => 'required|string|max:200',
            'message'  => 'required|string|max:5000',
            'priority' => 'in:low,normal,high,urgent',
        ]);

        $ticket = Ticket::create([
            'user_id'  => auth()->id(),
            'subject'  => $request->subject,
            'priority' => $request->priority ?? 'normal',
        ]);

        TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id'   => auth()->id(),
            'message'   => $request->message,
            'is_staff'  => false,
        ]);

        return redirect()->route('forge.tickets.show', $ticket->uuid);
    }

    public function show(string $uuid): Response
    {
        $ticket = Ticket::with(['messages.user', 'user'])
            ->where('uuid', $uuid)
            ->where('user_id', auth()->id())->firstOrFail();
        return Inertia::render('forge/ticket-show', compact('ticket'));
    }

    public function reply(Request $request, string $uuid): RedirectResponse
    {
        $request->validate(['message' => 'required|string|max:5000']);
        $ticket = Ticket::where('uuid', $uuid)->where('user_id', auth()->id())->firstOrFail();

        TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id'   => auth()->id(),
            'message'   => $request->message,
            'is_staff'  => false,
        ]);

        $ticket->update(['updated_at' => now()]);
        app(NotificationService::class)->logWebhook('ticket_reply', "User replied to ticket #{$ticket->id}: {$ticket->subject}");

        return back();
    }
}

// ── Subdomains ────────────────────────────────────────────────

class SubdomainController extends Controller
{
    public function index(): Response
    {
        $subdomains = Subdomain::with('server:id,name')->where('user_id', auth()->id())->get();
        $domains    = array_filter(array_map('trim', explode(',', config('forge.cf.domain', ''))));
        $servers    = \App\Models\Server::where('user_id', auth()->id())
                        ->select('id', 'name')->get();
        return Inertia::render('forge/subdomains', compact('subdomains', 'domains', 'servers'));
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'server_id' => 'required|integer',
            'subdomain' => 'required|string|alpha_dash|max:50',
            'domain'    => 'required|string',
            'target'    => 'required|string',
        ]);

        if (! config('forge.cf.enabled')) {
            return response()->json(['error' => 'Cloudflare subdomains not enabled'], 400);
        }

        $exists = Subdomain::where('subdomain', $request->subdomain)->where('domain', $request->domain)->exists();
        if ($exists) return response()->json(['error' => 'Subdomain already taken'], 400);

        $apiToken = config('forge.cf.api_token');
        $zoneId   = config('forge.cf.zone_id');

        $cfRes = \Illuminate\Support\Facades\Http::withToken($apiToken)
            ->post("https://api.cloudflare.com/client/v4/zones/{$zoneId}/dns_records", [
                'type'    => 'CNAME',
                'name'    => "{$request->subdomain}.{$request->domain}",
                'content' => $request->target,
                'proxied' => true,
                'ttl'     => 1,
            ]);

        if (! $cfRes->json('success')) {
            return response()->json(['error' => 'Cloudflare API error: ' . ($cfRes->json('errors.0.message') ?? 'unknown')], 500);
        }

        $sub = Subdomain::create([
            'user_id'      => auth()->id(),
            'server_id'    => $request->server_id,
            'subdomain'    => $request->subdomain,
            'domain'       => $request->domain,
            'cf_record_id' => $cfRes->json('result.id'),
            'target'       => $request->target,
        ]);

        return response()->json(['success' => true, 'fqdn' => $sub->fqdn]);
    }

    public function destroy(int $id): JsonResponse
    {
        $sub = Subdomain::where('id', $id)->where('user_id', auth()->id())->firstOrFail();

        if ($sub->cf_record_id && config('forge.cf.enabled')) {
            \Illuminate\Support\Facades\Http::withToken(config('forge.cf.api_token'))
                ->delete("https://api.cloudflare.com/client/v4/zones/" . config('forge.cf.zone_id') . "/dns_records/{$sub->cf_record_id}");
        }

        $sub->delete();
        return response()->json(['success' => true]);
    }
}

// ── Notifications ──────────────────────────────────────────────

class NotificationController extends Controller
{
    public function index(): JsonResponse
    {
        $notifications = ForgeNotification::where('user_id', auth()->id())
            ->latest()->limit(20)->get();
        return response()->json($notifications);
    }

    public function markRead(int $id): JsonResponse
    {
        ForgeNotification::where('id', $id)->where('user_id', auth()->id())->update(['read' => true]);
        return response()->json(['success' => true]);
    }

    public function markAllRead(): JsonResponse
    {
        ForgeNotification::where('user_id', auth()->id())->update(['read' => true]);
        return response()->json(['success' => true]);
    }
}
