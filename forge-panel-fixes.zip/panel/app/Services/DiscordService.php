<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class DiscordService
{
    public function getAuthUrl(): string
    {
        $params = http_build_query([
            'client_id'     => config('forge.discord.client_id'),
            'redirect_uri'  => config('forge.discord.redirect_uri'),
            'response_type' => 'code',
            'scope'         => 'identify email',
        ]);
        return "https://discord.com/api/oauth2/authorize?{$params}";
    }

    public function handleCallback(string $code): array
    {
        $tokenRes = Http::asForm()->post('https://discord.com/api/oauth2/token', [
            'client_id'     => config('forge.discord.client_id'),
            'client_secret' => config('forge.discord.client_secret'),
            'grant_type'    => 'authorization_code',
            'code'          => $code,
            'redirect_uri'  => config('forge.discord.redirect_uri'),
        ]);

        if (! $tokenRes->successful()) throw new \Exception('Discord token exchange failed');

        $token    = $tokenRes->json('access_token');
        $userRes  = Http::withToken($token)->get('https://discord.com/api/users/@me');

        if (! $userRes->successful()) throw new \Exception('Discord user fetch failed');

        return $userRes->json();
    }

    public function findOrCreateUser(array $discordUser, ?string $referralCode = null): User
    {
        // Try to find by discord_id
        $user = User::where('discord_id', $discordUser['id'])->first();

        if ($user) {
            // Update avatar if changed
            $user->update([
                'discord_username' => $discordUser['username'],
                'discord_avatar'   => $discordUser['avatar'],
            ]);
            return $user;
        }

        // Try to link to existing email account
        $user = User::where('email', $discordUser['email'] ?? null)->first();
        if ($user) {
            $user->update([
                'discord_id'       => $discordUser['id'],
                'discord_username' => $discordUser['username'],
                'discord_avatar'   => $discordUser['avatar'],
            ]);
            return $user;
        }

        // Create new account
        $username = $this->makeUsername($discordUser['username']);
        $email    = $discordUser['email'] ?? "{$discordUser['id']}@discord.forge";

        $user = User::create([
            'name'             => $discordUser['global_name'] ?? $username,
            'email'            => $email,
            'password'         => bcrypt(Str::random(32)),
            'discord_id'       => $discordUser['id'],
            'discord_username' => $discordUser['username'],
            'discord_avatar'   => $discordUser['avatar'],
            'referral_code'    => app(ReferralService::class)::generateCode(),
            'coins'            => (int) config('forge.discord.signup_bonus', 100),
        ]);

        if ($referralCode) {
            app(ReferralService::class)->apply($user, $referralCode);
        }

        app(NotificationService::class)->logWebhook(
            'new_registration',
            "Discord signup: **{$user->name}** ({$user->email})"
        );

        return $user;
    }

    private function makeUsername(string $discordUsername): string
    {
        $base = preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower($discordUsername));
        $name = $base;
        $i    = 1;
        while (User::where('name', $name)->exists()) {
            $name = "{$base}_{$i}";
            $i++;
        }
        return $name;
    }
}
