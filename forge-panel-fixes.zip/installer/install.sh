#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════
#                  Forge Panel Installer v1.0.1
#   Skyport fork — Wings + Skyportd, billing, Discord OAuth,
#   daily rewards, referrals, redeem codes, tickets + more
# ═══════════════════════════════════════════════════════════════

INSTALL_DIR="/var/www/forge"
LOG_FILE="/tmp/forge-install.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
PANEL_DIR="$SCRIPT_DIR/panel"

# ── Colours ───────────────────────────────────────────────────
BLUE='\033[38;2;7;24;217m'
BLUE_DARK='\033[38;2;4;16;143m'
GRAY='\033[38;2;120;120;120m'
GRAY_DARK='\033[38;2;55;55;55m'
WHITE='\033[1;37m'
DIM='\033[2m'
RESET='\033[0m'
RED='\033[38;2;220;50;50m'
GREEN='\033[38;2;80;200;120m'

banner() {
    clear 2>/dev/null || true
    echo ""
    echo -e "  ${BLUE}⚒  Forge Panel${RESET} ${GRAY}— ${DIM}$1${RESET}"
    echo ""
}
info()    { echo -e "  ${GRAY}›${RESET} $1"; }
success() { echo -e "  ${GREEN}✓${RESET} $1"; }
warn()    { echo -e "  ${BLUE_DARK}!${RESET} ${BLUE_DARK}$1${RESET}"; }
error()   { echo -e "  ${RED}✗${RESET} ${RED}$1${RESET}"; }
step()    { echo ""; echo -e "  ${BLUE}─── ${WHITE}$1${RESET}"; echo ""; }

ask() {
    local prompt="$1" default="${2:-}" r
    if [[ -n "$default" ]]; then
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${BLUE_DARK}${default}${GRAY_DARK}]${RESET}: " >&2
    else
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET}: " >&2
    fi
    read -r r || true
    echo "${r:-$default}"
}

ask_secret() {
    echo -ne "  ${BLUE}›${RESET} ${GRAY}$1${RESET}: " >&2
    read -rs r || true
    echo "" >&2
    echo "$r"
}

ask_yn() {
    local prompt="$1" default="${2:-y}" r
    if [[ "$default" == "y" ]]; then
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${BLUE_DARK}Y/n${GRAY_DARK}]${RESET}: " >&2
    else
        echo -ne "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${BLUE_DARK}y/N${GRAY_DARK}]${RESET}: " >&2
    fi
    read -r r || true
    [[ "${r:-$default}" =~ ^[Yy] ]]
}

ask_choice() {
    local prompt="$1"; shift
    local opts=("$@") i=1 r
    echo -e "  ${BLUE}›${RESET} ${GRAY}${prompt}${RESET}" >&2
    for o in "${opts[@]}"; do
        echo -e "    ${BLUE_DARK}${i})${RESET} ${GRAY}${o}${RESET}" >&2
        ((i++))
    done
    echo -ne "  ${BLUE}›${RESET} ${GRAY}Choice${RESET}: " >&2
    read -r r || true
    if [[ "$r" -ge 1 && "$r" -le "${#opts[@]}" ]] 2>/dev/null; then
        echo "$r"
    else
        echo "1"
    fi
}

spinner() {
    local pid=$1 label="$2"
    local frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏') i=0
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r  ${BLUE}%s${RESET} ${GRAY}%s${RESET}  " "${frames[$i]}" "$label" >&2
        i=$(( (i+1) % 10 ))
        sleep 0.1
    done
    wait "$pid"; local code=$?
    printf "\r"
    [[ $code -eq 0 ]] && success "$label" || error "$label — check $LOG_FILE"
    return $code
}

run_step() {
    local label="$1"; shift
    echo "=== [$(date '+%H:%M:%S')] $label ===" >> "$LOG_FILE"
    "$@" >> "$LOG_FILE" 2>&1 &
    spinner $! "$label"
}

abort() {
    echo ""
    error "$1"
    info "See $LOG_FILE for details."
    tail -15 "$LOG_FILE" 2>/dev/null | while IFS= read -r l; do
        echo -e "  ${GRAY_DARK}│${RESET} ${DIM}${l}${RESET}"
    done
    exit 1
}

# ── Root check ─────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && { error "Run as root (sudo bash install.sh)"; exit 1; }

trap 'abort "Installation failed unexpectedly at line $LINENO"' ERR
> "$LOG_FILE"

# ══════════════════════════════════════════════════════════════
#  PHASE 1 — GATHER ALL CONFIGURATION UPFRONT
# ══════════════════════════════════════════════════════════════

banner "Installer v1.0.1"

# ── Database ──────────────────────────────────────────────────
step "Database"
DB_CHOICE=$(ask_choice "Database engine" \
    "SQLite (recommended — zero setup)" \
    "MySQL / MariaDB")

if [[ "$DB_CHOICE" == "2" ]]; then
    DB_CONN="mysql"
    DB_HOST=$(ask "DB host" "127.0.0.1")
    DB_PORT_NUM=$(ask "DB port" "3306")
    DB_NAME=$(ask "DB name" "forge")
    DB_USER=$(ask "DB username" "forge")
    DB_PASS=$(ask_secret "DB password")
else
    DB_CONN="sqlite"
    DB_HOST=""
    DB_PORT_NUM=""
    DB_NAME="database/forge.db"
    DB_USER=""
    DB_PASS=""
fi

# ── Admin account ─────────────────────────────────────────────
step "Admin account"
ADMIN_NAME=$(ask "Admin name" "Admin")
ADMIN_EMAIL=$(ask "Admin email")
while [[ ! "$ADMIN_EMAIL" =~ ^[^@]+@[^@]+\.[^@]+$ ]]; do
    warn "Enter a valid email address."
    ADMIN_EMAIL=$(ask "Admin email")
done
ADMIN_PASS=$(ask_secret "Admin password (min 8 chars)")
while [[ ${#ADMIN_PASS} -lt 8 ]]; do
    warn "Password must be at least 8 characters."
    ADMIN_PASS=$(ask_secret "Admin password (min 8 chars)")
done

# ── SSL / Web setup ───────────────────────────────────────────
step "Web & SSL configuration"

USE_SSL=false
USE_CLOUDFLARE=false
CF_INSTALL=false
CF_TUNNEL_TOKEN=""
FQDN=""
APP_PORT="8080"
APP_URL=""

if ask_yn "Are you using SSL (HTTPS with Let's Encrypt)?"; then
    USE_SSL=true
    FQDN=$(ask "Your domain name" "panel.example.com")
    APP_URL="https://${FQDN}"
    APP_PORT="443"
    info "SSL enabled — Certbot will obtain a certificate for ${FQDN}."
else
    if ask_yn "Are you using Cloudflare Tunnel?"; then
        USE_CLOUDFLARE=true
        FQDN=$(ask "Your panel domain (e.g. panel.example.com)" "panel.example.com")
        # Cloudflare handles HTTPS publicly; internally we run plain HTTP
        APP_URL="https://${FQDN}"
        APP_PORT=$(ask "Internal HTTP port for Nginx" "8080")
        info "Cloudflare Tunnel mode — Nginx will listen on port ${APP_PORT} (HTTP only)."
        info "Cloudflare will proxy https://${FQDN} → http://127.0.0.1:${APP_PORT}"
        echo ""
        if ask_yn "Install and set up cloudflared now?"; then
            CF_INSTALL=true
            echo ""
            info "You will need a tunnel token from:"
            info "  Cloudflare Dashboard → Zero Trust → Networks → Tunnels"
            info "  → Create a tunnel → Copy the token shown."
            echo ""
            CF_TUNNEL_TOKEN=$(ask "Paste your Cloudflare Tunnel token (leave blank to skip)")
        else
            info "Skipping cloudflared install."
            info "Remember to point your tunnel to: http://127.0.0.1:${APP_PORT}"
        fi
    else
        APP_URL=$(ask "Panel URL (e.g. http://your-server-ip:8080)" "http://localhost:8080")
        APP_PORT=$(ask "Nginx listen port" "8080")
        info "Plain HTTP mode — no SSL, no tunnel."
    fi
fi

# ── Wings / Pterodactyl ───────────────────────────────────────
step "Wings / Pterodactyl (Pelican)"
WINGS_ENABLED=false
if ask_yn "Connect to Wings (Pterodactyl / Pelican)?"; then
    WINGS_ENABLED=true
fi

# ── Skyportd ──────────────────────────────────────────────────
step "Skyportd"
SKYPORT_ENABLED=false
SKYPORT_URL=""
SKYPORT_KEY=""
if ask_yn "Connect to Skyportd?" "n"; then
    SKYPORT_ENABLED=true
    SKYPORT_URL=$(ask "Skyportd panel URL")
    SKYPORT_KEY=$(ask "Skyportd API key")
fi

# ── Discord OAuth ─────────────────────────────────────────────
step "Discord OAuth"
DISCORD_CLIENT_ID=""
DISCORD_CLIENT_SECRET=""
DISCORD_BOT_TOKEN=""
if ask_yn "Enable Discord OAuth (login with Discord)?"; then
    DISCORD_CLIENT_ID=$(ask "Discord Client ID")
    DISCORD_CLIENT_SECRET=$(ask_secret "Discord Client Secret")
    DISCORD_BOT_TOKEN=$(ask_secret "Discord Bot Token (for DM notifications, leave blank to skip)")
fi

# ── Stripe ────────────────────────────────────────────────────
step "Stripe payments"
STRIPE_KEY=""
STRIPE_SECRET=""
STRIPE_WEBHOOK=""
if ask_yn "Enable Stripe card payments?" "n"; then
    STRIPE_KEY=$(ask "Stripe Publishable Key (pk_...)")
    STRIPE_SECRET=$(ask_secret "Stripe Secret Key (sk_...)")
    STRIPE_WEBHOOK=$(ask_secret "Stripe Webhook Secret (whsec_...)")
fi

# ── UPI ───────────────────────────────────────────────────────
step "UPI payments"
UPI_VPA=$(ask "Your UPI ID" "abcd@fam")
UPI_NAME=$(ask "UPI display name" "Forge Panel")

# ── Renewal ───────────────────────────────────────────────────
step "Server renewal system"
RENEWAL_ENABLED=false
RENEWAL_PERIOD="monthly"
RENEWAL_CUSTOM_DAYS=30
if ask_yn "Enable server renewals (auto-suspend on expiry)?"; then
    RENEWAL_ENABLED=true
    P=$(ask_choice "Renewal period" \
        "Daily (every 1 day)" \
        "Weekly (every 7 days)" \
        "Monthly (every 30 days)" \
        "Custom (specify days)")
    case "$P" in
        1) RENEWAL_PERIOD="daily" ;;
        2) RENEWAL_PERIOD="weekly" ;;
        3) RENEWAL_PERIOD="monthly" ;;
        4) RENEWAL_PERIOD="custom"
           RENEWAL_CUSTOM_DAYS=$(ask "How many days per renewal period?" "30") ;;
    esac
    success "Renewal: ${RENEWAL_PERIOD} (${RENEWAL_CUSTOM_DAYS} days if custom)"
fi

# ── Cloudflare Subdomains ─────────────────────────────────────
step "Cloudflare Subdomains (optional)"
CF_SUB_ENABLED=false
CF_API_TOKEN=""
CF_ZONE_ID=""
CF_DOMAIN=""
if ask_yn "Enable Cloudflare subdomain management?" "n"; then
    CF_SUB_ENABLED=true
    CF_API_TOKEN=$(ask_secret "Cloudflare API Token")
    CF_ZONE_ID=$(ask "Cloudflare Zone ID")
    CF_DOMAIN=$(ask "Domain (e.g. example.com)")
fi

# ── Discord webhook logging ───────────────────────────────────
step "Discord webhook logging (optional)"
DISCORD_LOG_WEBHOOK=""
if ask_yn "Enable Discord webhook logs?" "n"; then
    DISCORD_LOG_WEBHOOK=$(ask "Webhook URL")
fi

# ── Starter server ────────────────────────────────────────────
step "Starter server on signup (optional)"
STARTER_ENABLED=false
if ask_yn "Give every new user a free starter server?" "n"; then
    STARTER_ENABLED=true
fi

# ── Summary ───────────────────────────────────────────────────
step "Installation summary"
echo ""
info "Panel URL:   ${APP_URL}"
info "Database:    ${DB_CONN}"
info "Admin:       ${ADMIN_EMAIL}"
info "SSL:         ${USE_SSL}"
info "Cloudflare:  ${USE_CLOUDFLARE} (install: ${CF_INSTALL})"
info "Wings:       ${WINGS_ENABLED}"
info "Skyportd:    ${SKYPORT_ENABLED}"
info "Discord:     ${DISCORD_CLIENT_ID:+enabled (${DISCORD_CLIENT_ID})}"
info "Stripe:      ${STRIPE_KEY:+enabled}"
info "UPI:         ${UPI_VPA}"
info "Renewals:    ${RENEWAL_ENABLED} (${RENEWAL_PERIOD})"
echo ""
ask_yn "Begin installation?" || { info "Cancelled."; exit 0; }

# ══════════════════════════════════════════════════════════════
#  PHASE 2 — SYSTEM PACKAGES
# ══════════════════════════════════════════════════════════════
step "Installing system dependencies"

install_base() {
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y \
        curl gnupg2 ca-certificates lsb-release unzip git zip \
        nginx sqlite3 software-properties-common build-essential
}
run_step "Base packages" install_base

install_php() {
    source /etc/os-release
    if [[ "$ID" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php
    else
        curl -fsSL https://packages.sury.org/php/apt.gpg \
            | gpg --dearmor --yes -o /usr/share/keyrings/sury-php.gpg
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] \
            https://packages.sury.org/php/ $(lsb_release -sc) main" \
            > /etc/apt/sources.list.d/sury-php.list
    fi
    apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
        php8.4-cli php8.4-common php8.4-curl php8.4-mbstring \
        php8.4-xml php8.4-zip php8.4-bcmath php8.4-sqlite3 \
        php8.4-mysql php8.4-swoole php8.4-readline php8.4-gd \
        php8.4-intl
}
run_step "PHP 8.4 + Swoole" install_php

install_composer() {
    command -v composer &>/dev/null && return 0
    curl -fsSL --retry 3 https://getcomposer.org/installer -o /tmp/composer-setup.php
    php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
    rm -f /tmp/composer-setup.php
}
run_step "Composer" install_composer

install_bun() {
    command -v bun &>/dev/null && return 0
    curl -fsSL https://bun.sh/install | bash
    [[ -f "$HOME/.bun/bin/bun" ]] && ln -sf "$HOME/.bun/bin/bun" /usr/local/bin/bun || true
}
run_step "Bun (JS runtime)" install_bun
export PATH="/usr/local/bin:$HOME/.bun/bin:$PATH"

# ── cloudflared (if requested) ─────────────────────────────────
if $CF_INSTALL; then
    install_cloudflared() {
        curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
            | gpg --dearmor --yes -o /usr/share/keyrings/cloudflare-main.gpg
        echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] \
            https://pkg.cloudflare.com/cloudflared $(lsb_release -cs) main" \
            | tee /etc/apt/sources.list.d/cloudflared.list > /dev/null
        apt-get update -y
        apt-get install -y cloudflared
    }
    run_step "cloudflared" install_cloudflared
fi

# ── MySQL (if requested) ───────────────────────────────────────
if [[ "$DB_CONN" == "mysql" ]]; then
    install_mysql() {
        DEBIAN_FRONTEND=noninteractive apt-get install -y mariadb-server
        systemctl enable mariadb
        systemctl start mariadb
        mysql -e "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;"
        mysql -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
        mysql -e "GRANT ALL ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost'; FLUSH PRIVILEGES;"
    }
    run_step "MariaDB setup" install_mysql
fi

# ── Certbot (if SSL) ───────────────────────────────────────────
if $USE_SSL; then
    install_certbot() {
        DEBIAN_FRONTEND=noninteractive apt-get install -y certbot python3-certbot-nginx
    }
    run_step "Certbot" install_certbot
fi

# ══════════════════════════════════════════════════════════════
#  PHASE 3 — PANEL SOURCE
# ══════════════════════════════════════════════════════════════
step "Setting up Forge Panel source"

copy_panel() {
    # Validate source exists BEFORE starting background copy
    if [[ ! -d "$PANEL_DIR" ]]; then
        echo "ERROR: panel/ directory not found at $PANEL_DIR"
        echo "Make sure you run install.sh from INSIDE the forge-skyport/ directory:"
        echo "  cd forge-skyport && bash install.sh"
        return 1
    fi
    if [[ ! -f "$PANEL_DIR/artisan" ]]; then
        echo "ERROR: panel/artisan not found — panel source may be corrupt or incomplete"
        return 1
    fi
    [[ -d "$INSTALL_DIR" ]] && rm -rf "$INSTALL_DIR"
    cp -r "$PANEL_DIR" "$INSTALL_DIR"
    if [[ ! -f "$INSTALL_DIR/artisan" ]]; then
        echo "ERROR: artisan not found after copy — disk may be full or permissions wrong"
        return 1
    fi
}

# Preflight check (shown BEFORE spinner so user sees the error clearly)
if [[ ! -d "$PANEL_DIR" ]]; then
    echo ""
    error "Cannot find the panel source at: $PANEL_DIR"
    error "You must run this script from INSIDE the forge-skyport/ folder."
    error "Example:"
    info  "  cd ~/Forge/forge-skyport"
    info  "  bash install.sh"
    echo ""
    exit 1
fi

run_step "Copying panel files" copy_panel

# ── Write .env ─────────────────────────────────────────────────
write_env() {
    cd "$INSTALL_DIR"
    cp .env.example .env
    php artisan key:generate --no-interaction --force

    # Write all Forge-specific env vars
    # Use sed to replace existing keys and append missing ones cleanly
    set_env() {
        local key="$1" val="$2"
        if grep -q "^${key}=" .env 2>/dev/null; then
            sed -i "s|^${key}=.*|${key}=${val}|" .env
        else
            echo "${key}=${val}" >> .env
        fi
    }

    set_env APP_NAME            '"Forge Panel"'
    set_env APP_URL             "${APP_URL}"
    set_env ASSET_URL           "${APP_URL}"
    set_env TRUSTED_PROXIES     '*'
    set_env APP_VERSION         '1.0.0-alpha2'
    set_env OCTANE_SERVER       'swoole'
    set_env FORGE_LOGO_URL      'https://i.postimg.cc/K8ZkkhM9/file-000000001d5c72089d1c7d0792db739d.png'

    # Database
    set_env DB_CONNECTION   "${DB_CONN}"
    set_env DB_HOST         "${DB_HOST}"
    set_env DB_PORT         "${DB_PORT_NUM}"
    set_env DB_DATABASE     "${DB_NAME}"
    set_env DB_USERNAME     "${DB_USER}"
    set_env DB_PASSWORD     "${DB_PASS}"

    # Discord
    set_env DISCORD_CLIENT_ID      "${DISCORD_CLIENT_ID}"
    set_env DISCORD_CLIENT_SECRET  "${DISCORD_CLIENT_SECRET}"
    set_env DISCORD_BOT_TOKEN      "${DISCORD_BOT_TOKEN}"
    set_env DISCORD_REDIRECT_URI   "${APP_URL}/auth/discord/callback"
    set_env DISCORD_LOG_WEBHOOK    "${DISCORD_LOG_WEBHOOK}"
    set_env DISCORD_SIGNUP_BONUS   '100'

    # Stripe
    set_env STRIPE_KEY             "${STRIPE_KEY}"
    set_env STRIPE_SECRET          "${STRIPE_SECRET}"
    set_env STRIPE_WEBHOOK_SECRET  "${STRIPE_WEBHOOK}"

    # UPI
    set_env UPI_VPA   "${UPI_VPA}"
    set_env UPI_NAME  '"'"${UPI_NAME}"'"'

    # Coins
    set_env COINS_PER_INR '10'
    set_env COINS_PER_USD '100'

    # Daily rewards
    set_env DAILY_BASE_COINS      '25'
    set_env DAILY_STREAK_7_MULT   '1.5'
    set_env DAILY_STREAK_14_MULT  '2.0'
    set_env DAILY_STREAK_30_MULT  '3.0'

    # Renewals
    set_env RENEWAL_ENABLED      "${RENEWAL_ENABLED}"
    set_env RENEWAL_PERIOD       "${RENEWAL_PERIOD}"
    set_env RENEWAL_CUSTOM_DAYS  "${RENEWAL_CUSTOM_DAYS}"
    set_env RENEWAL_WARNING_DAYS '3'
    set_env RENEWAL_GRACE_DAYS   '7'

    # Referral
    set_env REFERRAL_ENABLED        'true'
    set_env REFERRAL_REFERRER_COINS '200'
    set_env REFERRAL_REFEREE_COINS  '100'

    # Shop
    set_env SHOP_RAM_COIN_COST    '10'
    set_env SHOP_DISK_COIN_COST   '5'
    set_env SHOP_CPU_COIN_COST    '20'
    set_env SHOP_SERVER_COIN_COST '500'

    # Cloudflare subdomains
    set_env CF_ENABLED    "${CF_SUB_ENABLED}"
    set_env CF_API_TOKEN  "${CF_API_TOKEN}"
    set_env CF_ZONE_ID    "${CF_ZONE_ID}"
    set_env CF_DOMAIN     "${CF_DOMAIN}"

    # Daemons
    set_env WINGS_ENABLED    "${WINGS_ENABLED}"
    set_env SKYPORT_ENABLED  "${SKYPORT_ENABLED}"
    set_env SKYPORT_URL      "${SKYPORT_URL}"
    set_env SKYPORT_KEY      "${SKYPORT_KEY}"

    # Starter server
    set_env STARTER_SERVER_ENABLED  "${STARTER_ENABLED}"
    set_env STARTER_SERVER_RAM      '512'
    set_env STARTER_SERVER_DISK     '2048'
    set_env STARTER_SERVER_CPU      '50'

    # SQLite DB file
    [[ "$DB_CONN" == "sqlite" ]] && touch database/forge.db && touch database/database.sqlite
}
run_step "Writing .env" write_env

# ══════════════════════════════════════════════════════════════
#  PHASE 4 — DEPENDENCIES & BUILD
# ══════════════════════════════════════════════════════════════
step "Installing application dependencies"

install_php_deps() {
    cd "$INSTALL_DIR"
    COMPOSER_ALLOW_SUPERUSER=1 composer install \
        --no-dev --no-interaction --optimize-autoloader --no-progress
}
run_step "PHP dependencies (Composer)" install_php_deps

install_js_deps() {
    cd "$INSTALL_DIR"
    bun install --frozen-lockfile 2>/dev/null || bun install
}
run_step "JS dependencies (Bun)" install_js_deps

build_assets() {
    cd "$INSTALL_DIR"
    bun run build:ssr
}
run_step "Building frontend assets" build_assets || abort "Frontend build failed — check $LOG_FILE"

# ══════════════════════════════════════════════════════════════
#  PHASE 5 — DATABASE
# ══════════════════════════════════════════════════════════════
step "Database setup"

run_migrations() {
    cd "$INSTALL_DIR"
    php artisan migrate --force --no-interaction
}
run_step "Running migrations" run_migrations || abort "Database migrations failed"

wayfinder_generate() {
    cd "$INSTALL_DIR"
    php artisan wayfinder:generate --with-form --no-interaction 2>/dev/null || true
}
run_step "Generating route bindings" wayfinder_generate

create_admin() {
    cd "$INSTALL_DIR"
    # Try the panel's built-in user:create command
    php artisan user:create \
        --name="$ADMIN_NAME" \
        --email="$ADMIN_EMAIL" \
        --password="$ADMIN_PASS" \
        --admin \
        --no-interaction 2>/dev/null || true
    # Set extra Forge resources on admin
    php artisan tinker --execute="
\$u = \App\Models\User::where('email', '$ADMIN_EMAIL')->first();
if (\$u) {
    \$u->coins       = 99999;
    \$u->ram_limit   = 32768;
    \$u->disk_limit  = 102400;
    \$u->cpu_limit   = 1000;
    \$u->server_limit = 99;
    if (!  \$u->referral_code) {
        \$u->referral_code = strtoupper(substr(md5('$ADMIN_EMAIL'), 0, 8));
    }
    \$u->save();
    echo 'Admin resources set.' . PHP_EOL;
}
" 2>/dev/null || true
}
run_step "Creating admin account" create_admin

# ══════════════════════════════════════════════════════════════
#  PHASE 6 — PERMISSIONS
# ══════════════════════════════════════════════════════════════
set_permissions() {
    cd "$INSTALL_DIR"
    chown -R www-data:www-data .
    chmod -R 755 storage bootstrap/cache
    if [[ "$DB_CONN" == "sqlite" ]]; then
        for f in database/forge.db database/database.sqlite; do
            [[ -f "$f" ]] && chown www-data:www-data "$f" && chmod 664 "$f"
        done
        chown www-data:www-data database
        chmod 775 database
    fi
}
run_step "Setting file permissions" set_permissions

# ══════════════════════════════════════════════════════════════
#  PHASE 7 — WEB SERVER
# ══════════════════════════════════════════════════════════════
step "Configuring web server"

# ── SSL certificate ────────────────────────────────────────────
if $USE_SSL; then
    obtain_cert() {
        systemctl stop nginx 2>/dev/null || true
        certbot certonly --standalone \
            -d "$FQDN" \
            --non-interactive \
            --agree-tos \
            --register-unsafely-without-email
        systemctl start nginx 2>/dev/null || true
    }
    run_step "Obtaining Let's Encrypt certificate for ${FQDN}" obtain_cert \
        || abort "Certbot failed. Ensure ${FQDN} resolves to this server and port 80 is open."
fi

# ── Nginx config ───────────────────────────────────────────────
configure_nginx() {
    if $USE_SSL; then
        # HTTPS with Let's Encrypt
        cat > /etc/nginx/sites-available/forge-panel.conf << NGINX
server {
    listen 80;
    server_name ${FQDN};
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${FQDN};

    ssl_certificate     /etc/letsencrypt/live/${FQDN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${FQDN}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;

    location / {
        proxy_pass         http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Upgrade           \$http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_buffering    off;
        proxy_read_timeout 300s;
    }
}
NGINX

    else
        # Plain HTTP — used by Cloudflare Tunnel or direct HTTP
        # Nginx listens on APP_PORT and proxies to Octane on 8000
        cat > /etc/nginx/sites-available/forge-panel.conf << NGINX
server {
    listen ${APP_PORT};
    server_name _;

    root ${INSTALL_DIR}/public;
    client_max_body_size 256m;

    location / {
        proxy_pass         http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Upgrade           \$http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_buffering    off;
        proxy_read_timeout 300s;
    }
}
NGINX
    fi

    rm -f /etc/nginx/sites-enabled/default
    ln -sf \
        /etc/nginx/sites-available/forge-panel.conf \
        /etc/nginx/sites-enabled/forge-panel.conf
    nginx -t
    systemctl restart nginx
}
run_step "Nginx configuration" configure_nginx

# ── Cloudflared tunnel setup ───────────────────────────────────
if $CF_INSTALL && [[ -n "$CF_TUNNEL_TOKEN" ]]; then
    setup_cloudflared() {
        # Install token-based tunnel (no config.yml needed)
        cloudflared service install "$CF_TUNNEL_TOKEN"
        systemctl enable cloudflared
        systemctl restart cloudflared
    }
    run_step "Setting up Cloudflare Tunnel service" setup_cloudflared
elif $CF_INSTALL && [[ -z "$CF_TUNNEL_TOKEN" ]]; then
    warn "No tunnel token provided — cloudflared installed but not configured."
    warn "Run manually: cloudflared service install <YOUR_TOKEN>"
fi

# ══════════════════════════════════════════════════════════════
#  PHASE 8 — SYSTEMD SERVICES
# ══════════════════════════════════════════════════════════════
step "Creating systemd services"

create_services() {
    cat > /etc/systemd/system/forge-panel.service << SVC
[Unit]
Description=Forge Panel (Octane/Swoole)
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan octane:start --server=swoole --host=127.0.0.1 --port=8000
ExecReload=/usr/bin/php artisan octane:reload
Restart=always
RestartSec=5
StartLimitBurst=5
StartLimitIntervalSec=60

[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/forge-queue.service << SVC
[Unit]
Description=Forge Panel Queue Worker
After=network.target forge-panel.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan queue:work --tries=3 --timeout=60
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/forge-ssr.service << SVC
[Unit]
Description=Forge Panel Inertia SSR
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan inertia:start-ssr
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVC

    cat > /etc/systemd/system/forge-scheduler.service << SVC
[Unit]
Description=Forge Panel Scheduler (renewals, etc)
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/php artisan schedule:work
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SVC

    systemctl daemon-reload
    systemctl enable forge-panel forge-queue forge-ssr forge-scheduler
    systemctl start  forge-panel forge-queue forge-ssr forge-scheduler
}
run_step "Creating and starting services" create_services

# ══════════════════════════════════════════════════════════════
#  PHASE 9 — FINAL URL FIX (prevents broken UI)
# ══════════════════════════════════════════════════════════════
final_env_fix() {
    cd "$INSTALL_DIR"

    # These sed commands are the definitive fix for broken UI / wrong redirects
    sed -i "s|APP_URL=.*|APP_URL=${APP_URL}|"     .env
    sed -i "s|ASSET_URL=.*|ASSET_URL=${APP_URL}|" .env 2>/dev/null || \
        echo "ASSET_URL=${APP_URL}" >> .env
    grep -q "^TRUSTED_PROXIES=" .env \
        && sed -i "s|TRUSTED_PROXIES=.*|TRUSTED_PROXIES=*|" .env \
        || echo "TRUSTED_PROXIES=*" >> .env
    grep -q "^APP_VERSION=" .env \
        && sed -i "s|APP_VERSION=.*|APP_VERSION=1.0.0-alpha2|" .env \
        || echo "APP_VERSION=1.0.0-alpha2" >> .env

    # Clear every cache Laravel has
    php artisan optimize:clear
    php artisan config:clear
    php artisan cache:clear
    php artisan route:clear
    php artisan view:clear

    # Give services a moment then restart
    sleep 3
    systemctl restart forge-panel forge-ssr forge-queue 2>/dev/null || true
}
run_step "Final .env fix + cache clear + restart" final_env_fix

# ══════════════════════════════════════════════════════════════
#  DONE
# ══════════════════════════════════════════════════════════════
trap - ERR

step "Installation complete!"
echo ""
echo -e "  ${BLUE}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${WHITE}⚒  Forge Panel is live!${RESET}                         ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}URL:${RESET}    ${BLUE}${APP_URL}${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}Admin:${RESET}  ${BLUE}${ADMIN_EMAIL}${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}DB:${RESET}     ${BLUE}${DB_CONN}${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"

if $USE_CLOUDFLARE; then
    echo -e "  ${BLUE}║${RESET}   ${GRAY}Cloudflare Tunnel:${RESET}                              ${BLUE}║${RESET}"
    echo -e "  ${BLUE}║${RESET}   ${DIM}  Public:   https://${FQDN}${RESET}"
    echo -e "  ${BLUE}║${RESET}   ${DIM}  Internal: http://127.0.0.1:${APP_PORT}${RESET}"
    if ! $CF_INSTALL; then
        echo -e "  ${BLUE}║${RESET}   ${BLUE_DARK}  → Point your tunnel to http://127.0.0.1:${APP_PORT}${RESET}"
    fi
elif ! $USE_SSL; then
    echo -e "  ${BLUE}║${RESET}   ${GRAY}Nginx listening on:${RESET} port ${APP_PORT}                  ${BLUE}║${RESET}"
fi

echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}Service logs:${RESET}                                   ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${DIM}  journalctl -u forge-panel -f${RESET}"
echo -e "  ${BLUE}║${RESET}   ${DIM}  journalctl -u forge-ssr -f${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${GRAY}To update .env later:${RESET}                           ${BLUE}║${RESET}"
echo -e "  ${BLUE}║${RESET}   ${DIM}  nano ${INSTALL_DIR}/.env${RESET}"
echo -e "  ${BLUE}║${RESET}   ${DIM}  cd ${INSTALL_DIR} && php artisan optimize:clear${RESET}"
echo -e "  ${BLUE}║${RESET}   ${DIM}  systemctl restart forge-panel forge-ssr forge-queue${RESET}"
echo -e "  ${BLUE}║${RESET}                                                      ${BLUE}║${RESET}"
echo -e "  ${BLUE}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""
