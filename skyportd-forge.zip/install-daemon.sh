#!/usr/bin/env bash
set -euo pipefail

# ──────────────────────────────────────────────────────────────
#  skyportd Daemon Installer (patched)
#  Fixes:
#   - ui.sh $2 unbound variable crash
#   - Version mismatch (1.0.0-dev vs 1.0.0-alpha2)
#   - WebSocket token panel version check
# ──────────────────────────────────────────────────────────────

INSTALL_DIR="/etc/skyportd"
DAEMON_USER="root"
LOG_FILE="/tmp/skyport-install.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Colours ───────────────────────────────────────────────────
ORANGE='\033[38;2;240;90;36m'
ORANGE_DARK='\033[38;2;217;36;0m'
GRAY='\033[38;2;120;120;120m'
GRAY_DARK='\033[38;2;55;55;55m'
WHITE='\033[1;37m'
DIM='\033[2m'
RESET='\033[0m'
RED='\033[38;2;220;50;50m'
GREEN='\033[38;2;80;200;120m'

# ── UI helpers ────────────────────────────────────────────────
banner()  { clear 2>/dev/null || true; echo ""; echo -e "  ${ORANGE}Skyport${RESET} ${GRAY}— ${DIM}$1${RESET}"; echo ""; }
info()    { echo -e "  ${GRAY}›${RESET} $1"; }
success() { echo -e "  ${ORANGE}✓${RESET} $1"; }
warn()    { echo -e "  ${ORANGE_DARK}!${RESET} ${ORANGE_DARK}$1${RESET}"; }
error()   { echo -e "  ${RED}✗${RESET} ${RED}$1${RESET}"; }
step()    { echo ""; echo -e "  ${ORANGE}─── ${WHITE}$1${RESET}"; echo ""; }

# Fixed: use ${2:-} instead of $2 to avoid unbound variable crash
ask() {
    local prompt="$1" default="${2:-}" __result
    if [[ -n "$default" ]]; then
        echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${ORANGE_DARK}${default}${GRAY_DARK}]${RESET}: " >&2
    else
        echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET}: " >&2
    fi
    read -r __result || true
    echo "${__result:-$default}"
}

ask_yes_no() {
    local prompt="$1" default="${2:-y}" __result
    if [[ "$default" == "y" ]]; then
        echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${ORANGE_DARK}Y/n${GRAY_DARK}]${RESET}: " >&2
    else
        echo -ne "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET} ${GRAY_DARK}[${ORANGE_DARK}y/N${GRAY_DARK}]${RESET}: " >&2
    fi
    read -r __result || true
    [[ "${__result:-$default}" =~ ^[Yy] ]]
}

ask_choice() {
    local prompt="$1"; shift; local options=("$@") i=1 __choice
    echo -e "  ${ORANGE}›${RESET} ${GRAY}${prompt}${RESET}" >&2
    for opt in "${options[@]}"; do
        echo -e "    ${ORANGE_DARK}${i})${RESET} ${GRAY}${opt}${RESET}" >&2
        ((i++))
    done
    echo -ne "  ${ORANGE}›${RESET} ${GRAY}Choice${RESET}: " >&2
    read -r __choice || true
    if [[ "$__choice" -ge 1 && "$__choice" -le "${#options[@]}" ]] 2>/dev/null; then
        echo "$__choice"
    else
        echo "1"
    fi
}

spinner() {
    local pid=$1 label="$2"
    local frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏') i=0
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r  ${ORANGE}%s${RESET} ${GRAY}%s${RESET}  " "${frames[$i]}" "$label" >&2
        i=$(( (i + 1) % ${#frames[@]} ))
        sleep 0.1
    done
    wait "$pid"; local exit_code=$?
    printf "\r" >&2
    if [[ $exit_code -eq 0 ]]; then
        success "$label"
    else
        error "$label — check $LOG_FILE for details"
    fi
    return $exit_code
}

run_step() {
    local label="$1"; shift
    echo "=== [$(date '+%H:%M:%S')] $label ===" >> "$LOG_FILE"
    "$@" >> "$LOG_FILE" 2>&1 &
    spinner $! "$label"
}

abort_with_log() {
    echo ""
    error "$1"
    error "See $LOG_FILE for full details."
    echo ""
    echo -e "  ${DIM}Last 15 lines of log:${RESET}"
    tail -15 "$LOG_FILE" 2>/dev/null | while IFS= read -r line; do
        echo -e "  ${GRAY_DARK}│${RESET} ${DIM}$line${RESET}"
    done
    echo ""
    exit 1
}

check_command() { command -v "$1" &>/dev/null; }

check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This installer must be run as root."
        exit 1
    fi
}

check_os() {
    if [[ ! -f /etc/os-release ]]; then
        error "Cannot detect operating system."
        exit 1
    fi
    source /etc/os-release
    case "$ID" in
        ubuntu) success "Detected $PRETTY_NAME" ;;
        debian) success "Detected $PRETTY_NAME" ;;
        *) warn "$PRETTY_NAME may not be fully supported. Continuing anyway." ;;
    esac
}

trap 'abort_with_log "Installation failed unexpectedly at line $LINENO."' ERR

> "$LOG_FILE"

# ── Preflight ─────────────────────────────────────────────────
banner "Daemon Installer (patched)"
check_root
check_os

# ── Architecture ──────────────────────────────────────────────
ARCH=$(uname -m)
case "$ARCH" in
    x86_64)  ARTIFACT="skyportd-linux-x86_64" ;;
    aarch64) ARTIFACT="skyportd-linux-aarch64" ;;
    riscv64) ARTIFACT="skyportd-linux-riscv64" ;;
    *)
        error "Unsupported architecture: $ARCH"
        exit 1 ;;
esac
success "Architecture: $ARCH"

# ── Existing installation ─────────────────────────────────────
if [[ -f "$INSTALL_DIR/skyportd" ]]; then
    warn "Existing skyportd found at $INSTALL_DIR."
    echo ""
    if ask_yes_no "Remove it and reinstall?" "n"; then
        systemctl stop skyportd 2>/dev/null || true
        rm -f "$INSTALL_DIR/skyportd"
        success "Removed existing binary."
    else
        error "Installation cancelled."
        exit 1
    fi
fi

# ── Docker ────────────────────────────────────────────────────
step "Docker"

if check_command docker; then
    local_docker_version=$(docker --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' || echo "unknown")
    success "Docker found: $local_docker_version"
else
    info "Docker is required for running game servers."
    echo ""
    if ask_yes_no "Install Docker?" "y"; then
        install_docker() { curl -fsSL --retry 3 https://get.docker.com | sh; }
        run_step "Installing Docker" install_docker
    else
        warn "Skipping Docker. skyportd will not be able to manage servers."
    fi
fi

# ── Install ───────────────────────────────────────────────────
step "Installing skyportd (patched build)"

install_daemon() {
    # Install Rust if needed
    if ! check_command cargo; then
        info "Installing Rust toolchain..." >&2
        DEBIAN_FRONTEND=noninteractive apt-get install -y build-essential pkg-config >> "$LOG_FILE" 2>&1
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y >> "$LOG_FILE" 2>&1
        source "$HOME/.cargo/env"
    fi

    local src_dir="$SCRIPT_DIR/skyportd-main"
    if [[ ! -d "$src_dir" ]]; then
        error "skyportd-main source directory not found next to installer."
        error "Make sure you extracted the full zip and run install-daemon.sh from inside it."
        exit 1
    fi

    cd "$src_dir"
    cargo build --release >> "$LOG_FILE" 2>&1
    mkdir -p "$INSTALL_DIR"
    cp target/release/skyportd "$INSTALL_DIR/skyportd"
    chmod +x "$INSTALL_DIR/skyportd"
    cd /
}

run_step "Building patched skyportd (takes 10-20 min)" install_daemon

if [[ ! -x "$INSTALL_DIR/skyportd" ]]; then
    abort_with_log "skyportd binary not found after build."
fi

# ── Config ────────────────────────────────────────────────────
setup_config() {
    mkdir -p "$INSTALL_DIR/config" "$INSTALL_DIR/volumes"
    if [[ ! -f "$INSTALL_DIR/config/default.toml" ]]; then
        cat > "$INSTALL_DIR/config/default.toml" <<'TOML'
[daemon]
name = "skyportd"
uuid = "00000000-0000-0000-0000-000000000000"
tick_interval = "5s"
shutdown_timeout = "30s"

[panel]
url = "http://127.0.0.1:8000"
configuration_token = ""

[logging]
level = "info"
format = "pretty"

[runtime]
worker_threads = 0
TOML
    fi
}

run_step "Setting up configuration" setup_config

# ── Systemd ───────────────────────────────────────────────────
step "Creating systemd service"

create_service() {
    cat > /etc/systemd/system/skyportd.service <<SERVICE
[Unit]
Description=skyportd — Skyport Daemon (patched)
After=docker.service network.target
Wants=docker.service

[Service]
User=${DAEMON_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/skyportd
Restart=always
RestartSec=5
StartLimitBurst=5
StartLimitIntervalSec=60
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SERVICE

    systemctl daemon-reload
    systemctl enable skyportd
}

run_step "Creating skyportd service" create_service

# ── Enroll ────────────────────────────────────────────────────
step "Daemon configuration"

info "skyportd needs a panel URL and configuration token to enroll."
echo ""

if ask_yes_no "Configure skyportd now?" "y"; then
    PANEL_URL=$(ask "Panel URL" "https://panel.example.com")
    CONFIG_TOKEN=$(ask "Configuration token (from panel)")

    if [[ -n "$PANEL_URL" && -n "$CONFIG_TOKEN" ]]; then
        cat > "$INSTALL_DIR/config/local.toml" <<TOML
[panel]
url = "${PANEL_URL}"
configuration_token = "${CONFIG_TOKEN}"
TOML
        success "Configuration saved."
        info "Starting skyportd..."
        systemctl start skyportd
        sleep 5

        if systemctl is-active --quiet skyportd; then
            success "skyportd is running!"
        else
            warn "skyportd may still be enrolling. Check with:"
            info "journalctl -u skyportd -f"
        fi
    else
        warn "Missing values. Edit $INSTALL_DIR/config/local.toml manually."
    fi
else
    info "Configure later: edit $INSTALL_DIR/config/local.toml"
fi

# ── Done ──────────────────────────────────────────────────────
trap - ERR

step "Done"
echo ""
echo -e "  ${ORANGE}╭──────────────────────────────────────────────────────╮${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${WHITE}skyportd is installed! (patched build)${RESET}            ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}Binary:${RESET}  ${ORANGE_DARK}${INSTALL_DIR}/skyportd${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}Config:${RESET}  ${ORANGE_DARK}${INSTALL_DIR}/config/${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}Volumes:${RESET} ${ORANGE_DARK}${INSTALL_DIR}/volumes/${RESET}"
echo -e "  ${ORANGE}│${RESET}                                                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}   ${GRAY}Commands:${RESET}                                           ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}systemctl status skyportd${RESET}                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}│${RESET}     ${DIM}journalctl -u skyportd -f${RESET}                      ${ORANGE}│${RESET}"
echo -e "  ${ORANGE}╰──────────────────────────────────────────────────────╯${RESET}"
echo ""
